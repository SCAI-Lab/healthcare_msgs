// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/EMGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/emg_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__EMGInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__EMGInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct EMGInfo_
{
  using Type = EMGInfo_<ContainerAllocator>;

  explicit EMGInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    filters(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
      this->signal_mode = 0;
    }
  }

  explicit EMGInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    filters(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
      this->signal_mode = 0;
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _units_type =
    uint8_t;
  _units_type units;
  using _electrode_placement_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_placement_type electrode_placement;
  using _electrode_type_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_type_type electrode_type;
  using _external_devices_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _external_devices_type external_devices;
  using _signal_mode_type =
    uint8_t;
  _signal_mode_type signal_mode;
  using _filters_type =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator>;
  _filters_type filters;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__units(
    const uint8_t & _arg)
  {
    this->units = _arg;
    return *this;
  }
  Type & set__electrode_placement(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_placement = _arg;
    return *this;
  }
  Type & set__electrode_type(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_type = _arg;
    return *this;
  }
  Type & set__external_devices(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->external_devices = _arg;
    return *this;
  }
  Type & set__signal_mode(
    const uint8_t & _arg)
  {
    this->signal_mode = _arg;
    return *this;
  }
  Type & set__filters(
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> & _arg)
  {
    this->filters = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t UNIT_UNKNOWN =
    0u;
  static constexpr uint8_t UNIT_MV =
    1u;
  static constexpr uint8_t UNIT_UV =
    2u;
  static constexpr uint8_t UNIT_COUNTS =
    3u;
  static constexpr uint8_t PLACEMENT_UNKNOWN =
    0u;
  static constexpr uint8_t PLACEMENT_BICEPS =
    1u;
  static constexpr uint8_t PLACEMENT_TRICEPS =
    2u;
  static constexpr uint8_t PLACEMENT_FOREARM =
    3u;
  static constexpr uint8_t PLACEMENT_CALF =
    4u;
  static constexpr uint8_t PLACEMENT_BACK =
    5u;
  static constexpr uint8_t PLACEMENT_ABDOMEN =
    6u;
  static constexpr uint8_t PLACEMENT_QUADRICEPS =
    7u;
  static constexpr uint8_t PLACEMENT_HAMSTRING =
    8u;
  static constexpr uint8_t PLACEMENT_FACE =
    9u;
  static constexpr uint8_t PLACEMENT_NECK =
    10u;
  static constexpr uint8_t PLACEMENT_CUSTOM =
    255u;
  static constexpr uint8_t ELECTRODE_UNKNOWN =
    0u;
  static constexpr uint8_t ELECTRODE_SURFACE =
    1u;
  static constexpr uint8_t ELECTRODE_NEEDLE =
    2u;
  static constexpr uint8_t ELECTRODE_WIRE =
    3u;
  static constexpr uint8_t ELECTRODE_INTERFERENTIAL =
    4u;
  static constexpr uint8_t ELECTRODE_CUSTOM =
    255u;
  static constexpr uint8_t DEVICE_UNKNOWN =
    0u;
  static constexpr uint8_t DEVICE_TENS =
    1u;
  static constexpr uint8_t DEVICE_FES =
    2u;
  static constexpr uint8_t DEVICE_EMG_TRIGGER =
    3u;
  static constexpr uint8_t DEVICE_CUSTOM =
    255u;
  static constexpr uint8_t MODE_UNKNOWN =
    0u;
  static constexpr uint8_t MODE_SURFACE =
    1u;
  static constexpr uint8_t MODE_INTRAMUSCULAR =
    2u;
  static constexpr uint8_t MODE_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::EMGInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::EMGInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EMGInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EMGInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__EMGInfo
    std::shared_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__EMGInfo
    std::shared_ptr<healthcare_msgs::msg::EMGInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EMGInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->units != other.units) {
      return false;
    }
    if (this->electrode_placement != other.electrode_placement) {
      return false;
    }
    if (this->electrode_type != other.electrode_type) {
      return false;
    }
    if (this->external_devices != other.external_devices) {
      return false;
    }
    if (this->signal_mode != other.signal_mode) {
      return false;
    }
    if (this->filters != other.filters) {
      return false;
    }
    return true;
  }
  bool operator!=(const EMGInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EMGInfo_

// alias to use template instance with default allocator
using EMGInfo =
  healthcare_msgs::msg::EMGInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::UNIT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::UNIT_MV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::UNIT_UV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::UNIT_COUNTS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_BICEPS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_TRICEPS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_FOREARM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_CALF;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_BACK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_ABDOMEN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_QUADRICEPS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_HAMSTRING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_FACE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_NECK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::PLACEMENT_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::ELECTRODE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::ELECTRODE_SURFACE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::ELECTRODE_NEEDLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::ELECTRODE_WIRE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::ELECTRODE_INTERFERENTIAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::ELECTRODE_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::DEVICE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::DEVICE_TENS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::DEVICE_FES;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::DEVICE_EMG_TRIGGER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::DEVICE_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::MODE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::MODE_SURFACE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::MODE_INTRAMUSCULAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EMGInfo_<ContainerAllocator>::MODE_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__STRUCT_HPP_
