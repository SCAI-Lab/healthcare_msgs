// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/EDA.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eda.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/eda__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const EDA & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: session_id
  {
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << ", ";
  }

  // member: sample_size
  {
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << ", ";
  }

  // member: scl
  {
    if (msg.scl.size() == 0) {
      out << "scl: []";
    } else {
      out << "scl: [";
      size_t pending_items = msg.scl.size();
      for (auto item : msg.scl) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: scr
  {
    if (msg.scr.size() == 0) {
      out << "scr: []";
    } else {
      out << "scr: [";
      size_t pending_items = msg.scr.size();
      for (auto item : msg.scr) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: eda
  {
    if (msg.eda.size() == 0) {
      out << "eda: []";
    } else {
      out << "eda: [";
      size_t pending_items = msg.eda.size();
      for (auto item : msg.eda) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: signal_quality
  {
    if (msg.signal_quality.size() == 0) {
      out << "signal_quality: []";
    } else {
      out << "signal_quality: [";
      size_t pending_items = msg.signal_quality.size();
      for (auto item : msg.signal_quality) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EDA & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: session_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << "\n";
  }

  // member: sample_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << "\n";
  }

  // member: scl
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.scl.size() == 0) {
      out << "scl: []\n";
    } else {
      out << "scl:\n";
      for (auto item : msg.scl) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: scr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.scr.size() == 0) {
      out << "scr: []\n";
    } else {
      out << "scr:\n";
      for (auto item : msg.scr) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: eda
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.eda.size() == 0) {
      out << "eda: []\n";
    } else {
      out << "eda:\n";
      for (auto item : msg.eda) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: signal_quality
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.signal_quality.size() == 0) {
      out << "signal_quality: []\n";
    } else {
      out << "signal_quality:\n";
      for (auto item : msg.signal_quality) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EDA & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::EDA & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::EDA & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::EDA>()
{
  return "healthcare_msgs::msg::EDA";
}

template<>
inline const char * name<healthcare_msgs::msg::EDA>()
{
  return "healthcare_msgs/msg/EDA";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::EDA>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::EDA>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::EDA>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA__TRAITS_HPP_
