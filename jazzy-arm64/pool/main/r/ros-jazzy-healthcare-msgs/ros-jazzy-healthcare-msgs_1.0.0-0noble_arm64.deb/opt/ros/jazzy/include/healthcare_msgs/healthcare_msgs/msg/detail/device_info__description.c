// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from healthcare_msgs:msg/DeviceInfo.idl
// generated code does not contain a copyright notice

#include "healthcare_msgs/msg/detail/device_info__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__DeviceInfo__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x4d, 0xc5, 0xe3, 0xb8, 0xd1, 0xf2, 0x32, 0xdc,
      0x47, 0x38, 0xf3, 0xb6, 0x95, 0x81, 0xb2, 0x54,
      0x04, 0xc1, 0x6b, 0xf2, 0x4a, 0x3d, 0x13, 0x43,
      0x93, 0x84, 0xd2, 0x8c, 0x39, 0x67, 0xc8, 0x37,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "builtin_interfaces/msg/detail/time__functions.h"
#include "builtin_interfaces/msg/detail/duration__functions.h"
#include "healthcare_msgs/msg/detail/medical_device_system__functions.h"
#include "std_msgs/msg/detail/header__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Duration__EXPECTED_HASH = {1, {
    0xe8, 0xd0, 0x09, 0xf6, 0x59, 0x81, 0x6f, 0x75,
    0x8b, 0x75, 0x33, 0x4e, 0xe1, 0xa9, 0xca, 0x5b,
    0x5c, 0x0b, 0x85, 0x98, 0x43, 0x26, 0x1f, 0x14,
    0xc7, 0xf9, 0x37, 0x34, 0x95, 0x99, 0xd9, 0x3b,
  }};
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__MedicalDeviceSystem__EXPECTED_HASH = {1, {
    0xda, 0xb7, 0x3b, 0x18, 0x28, 0x32, 0xc2, 0x93,
    0xe7, 0x0e, 0xf8, 0xbb, 0x7a, 0x8c, 0xc3, 0x39,
    0xcf, 0xcc, 0x44, 0x98, 0x7d, 0x22, 0xf4, 0xee,
    0x91, 0x09, 0x7e, 0x63, 0xae, 0xd3, 0xa6, 0xac,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char healthcare_msgs__msg__DeviceInfo__TYPE_NAME[] = "healthcare_msgs/msg/DeviceInfo";
static char builtin_interfaces__msg__Duration__TYPE_NAME[] = "builtin_interfaces/msg/Duration";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char healthcare_msgs__msg__MedicalDeviceSystem__TYPE_NAME[] = "healthcare_msgs/msg/MedicalDeviceSystem";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__header[] = "header";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__session_id[] = "session_id";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__mds[] = "mds";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_manufacturer[] = "device_manufacturer";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_name[] = "device_name";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_type[] = "device_type";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_serial_number[] = "device_serial_number";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__minimal_operation_temperature[] = "minimal_operation_temperature";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__maximal_operation_temperature[] = "maximal_operation_temperature";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__maximal_relative_humidity[] = "maximal_relative_humidity";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__minimal_atmospheric_pressure[] = "minimal_atmospheric_pressure";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__maximal_atmospheric_pressure[] = "maximal_atmospheric_pressure";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__measuring_unit[] = "measuring_unit";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__acquisition_rate_hz[] = "acquisition_rate_hz";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__gain[] = "gain";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__resolution[] = "resolution";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__adc_resolution[] = "adc_resolution";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__accuracy[] = "accuracy";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__max_range[] = "max_range";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__min_range[] = "min_range";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__window_size_samples[] = "window_size_samples";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__quality_window_size_samples[] = "quality_window_size_samples";
static char healthcare_msgs__msg__DeviceInfo__FIELD_NAME__stride_length[] = "stride_length";

static rosidl_runtime_c__type_description__Field healthcare_msgs__msg__DeviceInfo__FIELDS[] = {
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__session_id, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__mds, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {healthcare_msgs__msg__MedicalDeviceSystem__TYPE_NAME, 39, 39},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_manufacturer, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_name, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_type, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__device_serial_number, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__minimal_operation_temperature, 29, 29},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__maximal_operation_temperature, 29, 29},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__maximal_relative_humidity, 25, 25},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__minimal_atmospheric_pressure, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__maximal_atmospheric_pressure, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__measuring_unit, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__acquisition_rate_hz, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__gain, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__resolution, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__adc_resolution, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__accuracy, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__max_range, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__min_range, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__window_size_samples, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__quality_window_size_samples, 27, 27},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__FIELD_NAME__stride_length, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription healthcare_msgs__msg__DeviceInfo__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Duration__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__MedicalDeviceSystem__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__DeviceInfo__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {healthcare_msgs__msg__DeviceInfo__TYPE_NAME, 30, 30},
      {healthcare_msgs__msg__DeviceInfo__FIELDS, 23, 23},
    },
    {healthcare_msgs__msg__DeviceInfo__REFERENCED_TYPE_DESCRIPTIONS, 4, 4},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Duration__EXPECTED_HASH, builtin_interfaces__msg__Duration__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Duration__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__MedicalDeviceSystem__EXPECTED_HASH, healthcare_msgs__msg__MedicalDeviceSystem__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = healthcare_msgs__msg__MedicalDeviceSystem__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[3].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "std_msgs/Header header\n"
  "\n"
  "string session_id\n"
  "\n"
  "# Medical Device System\n"
  "MedicalDeviceSystem mds\n"
  "\n"
  "# Device identity\n"
  "string device_manufacturer       # Name of the device manufacturer\n"
  "string device_name               # Name of the device\n"
  "string device_type               # Type or purpose of the device (e.g., heart rate sensor, pressure mat)\n"
  "string device_serial_number      # Serial number for identification\n"
  "\n"
  "# Environmental requirements\n"
  "float32 minimal_operation_temperature    # Minimal operating temperature [\\xc2\\xb0C]\n"
  "float32 maximal_operation_temperature    # Maximal operating temperature [\\xc2\\xb0C]\n"
  "float32 maximal_relative_humidity        # Max tolerated humidity from 0 to 1 [%]\n"
  "float32 minimal_atmospheric_pressure     # Minimal tolerated pressure [atm]\n"
  "float32 maximal_atmospheric_pressure     # Max tolerated pressure [atm]\n"
  "\n"
  "# Measurement specs\n"
  "string  measuring_unit                   # Unit of measurement (e.g. bpm, mmHg)\n"
  "uint16  acquisition_rate_hz              # Sampling frequency in Hz\n"
  "float32 gain                             # Multiplicative factor; set to 1.0 if signal is already scaled\n"
  "float32 resolution                       # Resolution in the given unit\n"
  "uint8 adc_resolution                     # Bits (e.g., 12, 16)\n"
  "float32 accuracy                         # Accuracy of the signal [0\\xe2\\x80\\x931]\n"
  "float32 max_range                        # Max detectable value in the given unit\n"
  "float32 min_range                        # Min detectable value in the given unit\n"
  "uint32 window_size_samples               # Number of samples per msg\n"
  "uint32 quality_window_size_samples       # Number of samples per quality value\n"
  "float32 stride_length                    # Step size (in ms) by which the analysis window moves forward in time";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__DeviceInfo__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {healthcare_msgs__msg__DeviceInfo__TYPE_NAME, 30, 30},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1725, 1725},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__DeviceInfo__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[5];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 5, 5};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *healthcare_msgs__msg__DeviceInfo__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Duration__get_individual_type_description_source(NULL);
    sources[2] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[3] = *healthcare_msgs__msg__MedicalDeviceSystem__get_individual_type_description_source(NULL);
    sources[4] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
