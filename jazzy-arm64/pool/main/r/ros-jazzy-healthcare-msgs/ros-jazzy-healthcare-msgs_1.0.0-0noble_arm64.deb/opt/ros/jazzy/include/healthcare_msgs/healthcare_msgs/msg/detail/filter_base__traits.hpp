// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/FilterBase.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/filter_base.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'band_pass_filter'
#include "healthcare_msgs/msg/detail/band_pass_filter__traits.hpp"
// Member 'butter_worth_filter'
#include "healthcare_msgs/msg/detail/butter_worth_filter__traits.hpp"
// Member 'high_pass_filter'
#include "healthcare_msgs/msg/detail/high_pass_filter__traits.hpp"
// Member 'kalman_filter'
#include "healthcare_msgs/msg/detail/kalman_filter__traits.hpp"
// Member 'low_pass_filter'
#include "healthcare_msgs/msg/detail/low_pass_filter__traits.hpp"
// Member 'moving_average_filter'
#include "healthcare_msgs/msg/detail/moving_average_filter__traits.hpp"
// Member 'notch_filter'
#include "healthcare_msgs/msg/detail/notch_filter__traits.hpp"
// Member 'savitzky_golay_filter'
#include "healthcare_msgs/msg/detail/savitzky_golay_filter__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const FilterBase & msg,
  std::ostream & out)
{
  out << "{";
  // member: filters
  {
    if (msg.filters.size() == 0) {
      out << "filters: []";
    } else {
      out << "filters: [";
      size_t pending_items = msg.filters.size();
      for (auto item : msg.filters) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: band_pass_filter
  {
    out << "band_pass_filter: ";
    to_flow_style_yaml(msg.band_pass_filter, out);
    out << ", ";
  }

  // member: butter_worth_filter
  {
    out << "butter_worth_filter: ";
    to_flow_style_yaml(msg.butter_worth_filter, out);
    out << ", ";
  }

  // member: high_pass_filter
  {
    out << "high_pass_filter: ";
    to_flow_style_yaml(msg.high_pass_filter, out);
    out << ", ";
  }

  // member: kalman_filter
  {
    out << "kalman_filter: ";
    to_flow_style_yaml(msg.kalman_filter, out);
    out << ", ";
  }

  // member: low_pass_filter
  {
    out << "low_pass_filter: ";
    to_flow_style_yaml(msg.low_pass_filter, out);
    out << ", ";
  }

  // member: moving_average_filter
  {
    out << "moving_average_filter: ";
    to_flow_style_yaml(msg.moving_average_filter, out);
    out << ", ";
  }

  // member: notch_filter
  {
    out << "notch_filter: ";
    to_flow_style_yaml(msg.notch_filter, out);
    out << ", ";
  }

  // member: savitzky_golay_filter
  {
    out << "savitzky_golay_filter: ";
    to_flow_style_yaml(msg.savitzky_golay_filter, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const FilterBase & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: filters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.filters.size() == 0) {
      out << "filters: []\n";
    } else {
      out << "filters:\n";
      for (auto item : msg.filters) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: band_pass_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "band_pass_filter:\n";
    to_block_style_yaml(msg.band_pass_filter, out, indentation + 2);
  }

  // member: butter_worth_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "butter_worth_filter:\n";
    to_block_style_yaml(msg.butter_worth_filter, out, indentation + 2);
  }

  // member: high_pass_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "high_pass_filter:\n";
    to_block_style_yaml(msg.high_pass_filter, out, indentation + 2);
  }

  // member: kalman_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "kalman_filter:\n";
    to_block_style_yaml(msg.kalman_filter, out, indentation + 2);
  }

  // member: low_pass_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "low_pass_filter:\n";
    to_block_style_yaml(msg.low_pass_filter, out, indentation + 2);
  }

  // member: moving_average_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "moving_average_filter:\n";
    to_block_style_yaml(msg.moving_average_filter, out, indentation + 2);
  }

  // member: notch_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "notch_filter:\n";
    to_block_style_yaml(msg.notch_filter, out, indentation + 2);
  }

  // member: savitzky_golay_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "savitzky_golay_filter:\n";
    to_block_style_yaml(msg.savitzky_golay_filter, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const FilterBase & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::FilterBase & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::FilterBase & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::FilterBase>()
{
  return "healthcare_msgs::msg::FilterBase";
}

template<>
inline const char * name<healthcare_msgs::msg::FilterBase>()
{
  return "healthcare_msgs/msg/FilterBase";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::FilterBase>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::FilterBase>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::FilterBase>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__TRAITS_HPP_
