// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from healthcare_msgs:msg/ECGInfo.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "healthcare_msgs/msg/detail/ecg_info__functions.h"
#include "healthcare_msgs/msg/detail/ecg_info__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace healthcare_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ECGInfo_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) healthcare_msgs::msg::ECGInfo(_init);
}

void ECGInfo_fini_function(void * message_memory)
{
  auto typed_message = static_cast<healthcare_msgs::msg::ECGInfo *>(message_memory);
  typed_message->~ECGInfo();
}

size_t size_function__ECGInfo__electrode_placement(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ECGInfo__electrode_placement(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint8_t> *>(untyped_member);
  return &member[index];
}

void * get_function__ECGInfo__electrode_placement(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint8_t> *>(untyped_member);
  return &member[index];
}

void fetch_function__ECGInfo__electrode_placement(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__ECGInfo__electrode_placement(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__ECGInfo__electrode_placement(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__ECGInfo__electrode_placement(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__ECGInfo__electrode_placement(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint8_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ECGInfo__lead_type(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ECGInfo__lead_type(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint8_t> *>(untyped_member);
  return &member[index];
}

void * get_function__ECGInfo__lead_type(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint8_t> *>(untyped_member);
  return &member[index];
}

void fetch_function__ECGInfo__lead_type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__ECGInfo__lead_type(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__ECGInfo__lead_type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__ECGInfo__lead_type(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__ECGInfo__lead_type(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint8_t> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ECGInfo_message_member_array[5] = {
  {
    "device_info",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<healthcare_msgs::msg::DeviceInfo>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ECGInfo, device_info),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "units",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ECGInfo, units),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "electrode_placement",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ECGInfo, electrode_placement),  // bytes offset in struct
    nullptr,  // default value
    size_function__ECGInfo__electrode_placement,  // size() function pointer
    get_const_function__ECGInfo__electrode_placement,  // get_const(index) function pointer
    get_function__ECGInfo__electrode_placement,  // get(index) function pointer
    fetch_function__ECGInfo__electrode_placement,  // fetch(index, &value) function pointer
    assign_function__ECGInfo__electrode_placement,  // assign(index, value) function pointer
    resize_function__ECGInfo__electrode_placement  // resize(index) function pointer
  },
  {
    "lead_type",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ECGInfo, lead_type),  // bytes offset in struct
    nullptr,  // default value
    size_function__ECGInfo__lead_type,  // size() function pointer
    get_const_function__ECGInfo__lead_type,  // get_const(index) function pointer
    get_function__ECGInfo__lead_type,  // get(index) function pointer
    fetch_function__ECGInfo__lead_type,  // fetch(index, &value) function pointer
    assign_function__ECGInfo__lead_type,  // assign(index, value) function pointer
    resize_function__ECGInfo__lead_type  // resize(index) function pointer
  },
  {
    "filters",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<healthcare_msgs::msg::FilterBase>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ECGInfo, filters),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ECGInfo_message_members = {
  "healthcare_msgs::msg",  // message namespace
  "ECGInfo",  // message name
  5,  // number of fields
  sizeof(healthcare_msgs::msg::ECGInfo),
  false,  // has_any_key_member_
  ECGInfo_message_member_array,  // message members
  ECGInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  ECGInfo_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ECGInfo_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ECGInfo_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__ECGInfo__get_type_hash,
  &healthcare_msgs__msg__ECGInfo__get_type_description,
  &healthcare_msgs__msg__ECGInfo__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace healthcare_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<healthcare_msgs::msg::ECGInfo>()
{
  return &::healthcare_msgs::msg::rosidl_typesupport_introspection_cpp::ECGInfo_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, healthcare_msgs, msg, ECGInfo)() {
  return &::healthcare_msgs::msg::rosidl_typesupport_introspection_cpp::ECGInfo_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
