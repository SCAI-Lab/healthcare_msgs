// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eeg_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__EEGInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__EEGInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct EEGInfo_
{
  using Type = EEGInfo_<ContainerAllocator>;

  explicit EEGInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    filters(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->channel_size = 0;
      this->units = 0;
      this->montage_type = 0;
      this->signal_mode = 0;
    }
  }

  explicit EEGInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    filters(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->channel_size = 0;
      this->units = 0;
      this->montage_type = 0;
      this->signal_mode = 0;
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _channel_size_type =
    uint8_t;
  _channel_size_type channel_size;
  using _units_type =
    uint8_t;
  _units_type units;
  using _selected_preprocessing_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _selected_preprocessing_type selected_preprocessing;
  using _montage_type_type =
    uint8_t;
  _montage_type_type montage_type;
  using _bipolar_active_sites_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _bipolar_active_sites_type bipolar_active_sites;
  using _bipolar_reference_sites_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _bipolar_reference_sites_type bipolar_reference_sites;
  using _reference_sites_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _reference_sites_type reference_sites;
  using _placement_method_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _placement_method_type placement_method;
  using _electrode_sites_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_sites_type electrode_sites;
  using _electrode_physical_type_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_physical_type_type electrode_physical_type;
  using _signal_mode_type =
    uint8_t;
  _signal_mode_type signal_mode;
  using _filters_type =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator>;
  _filters_type filters;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__channel_size(
    const uint8_t & _arg)
  {
    this->channel_size = _arg;
    return *this;
  }
  Type & set__units(
    const uint8_t & _arg)
  {
    this->units = _arg;
    return *this;
  }
  Type & set__selected_preprocessing(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->selected_preprocessing = _arg;
    return *this;
  }
  Type & set__montage_type(
    const uint8_t & _arg)
  {
    this->montage_type = _arg;
    return *this;
  }
  Type & set__bipolar_active_sites(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->bipolar_active_sites = _arg;
    return *this;
  }
  Type & set__bipolar_reference_sites(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->bipolar_reference_sites = _arg;
    return *this;
  }
  Type & set__reference_sites(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->reference_sites = _arg;
    return *this;
  }
  Type & set__placement_method(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->placement_method = _arg;
    return *this;
  }
  Type & set__electrode_sites(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_sites = _arg;
    return *this;
  }
  Type & set__electrode_physical_type(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_physical_type = _arg;
    return *this;
  }
  Type & set__signal_mode(
    const uint8_t & _arg)
  {
    this->signal_mode = _arg;
    return *this;
  }
  Type & set__filters(
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> & _arg)
  {
    this->filters = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t UNIT_UNKNOWN =
    0u;
  static constexpr uint8_t UNIT_UV =
    1u;
  static constexpr uint8_t UNIT_MV =
    2u;
  static constexpr uint8_t UNIT_COUNTS =
    3u;
  static constexpr int8_t EEG_FEATURE_UNKNOWN =
    0;
  static constexpr uint8_t EEG_PREPROC_BANDPASS =
    1u;
  static constexpr uint8_t EEG_PREPROC_NOTCH =
    2u;
  static constexpr uint8_t EEG_PREPROC_ICA =
    3u;
  static constexpr uint8_t EEG_PREPROC_CAR =
    4u;
  static constexpr uint8_t EEG_PREPROC_ARTEFACT_REJ =
    5u;
  static constexpr uint8_t EEG_PREPROC_BASELINE_CORR =
    6u;
  static constexpr uint8_t EEG_PREPROC_DOWNSAMPLE =
    7u;
  static constexpr uint8_t EEG_PREPROC_SEGMENTED =
    8u;
  static constexpr uint8_t EEG_FEATURE_CUSTOM =
    255u;
  static constexpr uint8_t MONTAGE_TYPE_UNKNOWN =
    0u;
  static constexpr uint8_t MONTAGE_TYPE_BIPOLAR =
    1u;
  static constexpr uint8_t MONTAGE_TYPE_REFERENTIAL =
    2u;
  static constexpr uint8_t MONTAGE_TYPE_AVERAGE_REF =
    3u;
  static constexpr uint8_t MONTAGE_TYPE_LAPLACIAN =
    4u;
  static constexpr uint8_t PLACEMENT_METHOD_UNKNOWN =
    0u;
  static constexpr uint8_t PLACEMENT_METHOD_1020 =
    1u;
  static constexpr uint8_t PLACEMENT_METHOD_1010 =
    2u;
  static constexpr uint8_t PLACEMENT_METHOD_105 =
    3u;
  static constexpr uint8_t PLACEMENT_METHOD_CUSTOM =
    255u;
  static constexpr uint8_t ELECTRODE_UNKNOWN =
    0u;
  static constexpr uint8_t ELECTRODE_FP1 =
    1u;
  static constexpr uint8_t ELECTRODE_FP2 =
    2u;
  static constexpr uint8_t ELECTRODE_F3 =
    3u;
  static constexpr uint8_t ELECTRODE_F4 =
    4u;
  static constexpr uint8_t ELECTRODE_C3 =
    5u;
  static constexpr uint8_t ELECTRODE_C4 =
    6u;
  static constexpr uint8_t ELECTRODE_P3 =
    7u;
  static constexpr uint8_t ELECTRODE_P4 =
    8u;
  static constexpr uint8_t ELECTRODE_O1 =
    9u;
  static constexpr uint8_t ELECTRODE_O2 =
    10u;
  static constexpr uint8_t ELECTRODE_F7 =
    11u;
  static constexpr uint8_t ELECTRODE_F8 =
    12u;
  static constexpr uint8_t ELECTRODE_T3 =
    13u;
  static constexpr uint8_t ELECTRODE_T4 =
    14u;
  static constexpr uint8_t ELECTRODE_T5 =
    15u;
  static constexpr uint8_t ELECTRODE_T6 =
    16u;
  static constexpr uint8_t ELECTRODE_FZ =
    17u;
  static constexpr uint8_t ELECTRODE_CZ =
    18u;
  static constexpr uint8_t ELECTRODE_PZ =
    19u;
  static constexpr uint8_t ELECTRODE_OZ =
    20u;
  static constexpr uint8_t ELECTRODE_CUSTOM =
    255u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_UNKNOWN =
    0u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_AGCL =
    1u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_GOLD_CUP =
    2u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_DRY =
    3u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_WET =
    4u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_HYDROGEL =
    5u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_MICRONEEDLE =
    6u;
  static constexpr uint8_t ELECTRODE_PHYSICAL_CUSTOM =
    255u;
  static constexpr uint8_t SIGNAL_MODE_UNKNOWN =
    0u;
  static constexpr uint8_t SIGNAL_MODE_SURFACE =
    1u;
  static constexpr uint8_t SIGNAL_MODE_INTRACRANIAL =
    2u;
  static constexpr uint8_t SIGNAL_MODE_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::EEGInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::EEGInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EEGInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EEGInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__EEGInfo
    std::shared_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__EEGInfo
    std::shared_ptr<healthcare_msgs::msg::EEGInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EEGInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->channel_size != other.channel_size) {
      return false;
    }
    if (this->units != other.units) {
      return false;
    }
    if (this->selected_preprocessing != other.selected_preprocessing) {
      return false;
    }
    if (this->montage_type != other.montage_type) {
      return false;
    }
    if (this->bipolar_active_sites != other.bipolar_active_sites) {
      return false;
    }
    if (this->bipolar_reference_sites != other.bipolar_reference_sites) {
      return false;
    }
    if (this->reference_sites != other.reference_sites) {
      return false;
    }
    if (this->placement_method != other.placement_method) {
      return false;
    }
    if (this->electrode_sites != other.electrode_sites) {
      return false;
    }
    if (this->electrode_physical_type != other.electrode_physical_type) {
      return false;
    }
    if (this->signal_mode != other.signal_mode) {
      return false;
    }
    if (this->filters != other.filters) {
      return false;
    }
    return true;
  }
  bool operator!=(const EEGInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EEGInfo_

// alias to use template instance with default allocator
using EEGInfo =
  healthcare_msgs::msg::EEGInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::UNIT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::UNIT_UV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::UNIT_MV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::UNIT_COUNTS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t EEGInfo_<ContainerAllocator>::EEG_FEATURE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_BANDPASS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_NOTCH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_ICA;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_CAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_ARTEFACT_REJ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_BASELINE_CORR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_DOWNSAMPLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_PREPROC_SEGMENTED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::EEG_FEATURE_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::MONTAGE_TYPE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::MONTAGE_TYPE_BIPOLAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::MONTAGE_TYPE_REFERENTIAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::MONTAGE_TYPE_AVERAGE_REF;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::MONTAGE_TYPE_LAPLACIAN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::PLACEMENT_METHOD_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::PLACEMENT_METHOD_1020;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::PLACEMENT_METHOD_1010;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::PLACEMENT_METHOD_105;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::PLACEMENT_METHOD_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_FP1;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_FP2;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_F3;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_F4;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_C3;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_C4;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_P3;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_P4;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_O1;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_O2;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_F7;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_F8;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_T3;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_T4;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_T5;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_T6;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_FZ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_CZ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PZ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_OZ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_AGCL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_GOLD_CUP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_DRY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_WET;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_HYDROGEL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_MICRONEEDLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::ELECTRODE_PHYSICAL_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::SIGNAL_MODE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::SIGNAL_MODE_SURFACE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::SIGNAL_MODE_INTRACRANIAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EEGInfo_<ContainerAllocator>::SIGNAL_MODE_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__STRUCT_HPP_
