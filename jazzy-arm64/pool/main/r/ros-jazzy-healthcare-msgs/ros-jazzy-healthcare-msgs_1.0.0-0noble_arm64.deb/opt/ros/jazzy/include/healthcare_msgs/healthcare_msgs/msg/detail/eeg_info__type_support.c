// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/eeg_info__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/eeg_info__functions.h"
#include "healthcare_msgs/msg/detail/eeg_info__struct.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/device_info.h"
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__rosidl_typesupport_introspection_c.h"
// Member `selected_preprocessing`
// Member `bipolar_active_sites`
// Member `bipolar_reference_sites`
// Member `reference_sites`
// Member `placement_method`
// Member `electrode_sites`
// Member `electrode_physical_type`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `filters`
#include "healthcare_msgs/msg/filter_base.h"
// Member `filters`
#include "healthcare_msgs/msg/detail/filter_base__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__EEGInfo__init(message_memory);
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_fini_function(void * message_memory)
{
  healthcare_msgs__msg__EEGInfo__fini(message_memory);
}

size_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__selected_preprocessing(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__selected_preprocessing(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__selected_preprocessing(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__selected_preprocessing(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__selected_preprocessing(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__selected_preprocessing(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__selected_preprocessing(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__selected_preprocessing(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__bipolar_active_sites(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__bipolar_active_sites(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__bipolar_active_sites(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__bipolar_active_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__bipolar_active_sites(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__bipolar_active_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__bipolar_active_sites(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__bipolar_active_sites(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__bipolar_reference_sites(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__bipolar_reference_sites(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__bipolar_reference_sites(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__bipolar_reference_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__bipolar_reference_sites(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__bipolar_reference_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__bipolar_reference_sites(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__bipolar_reference_sites(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__reference_sites(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__reference_sites(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__reference_sites(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__reference_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__reference_sites(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__reference_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__reference_sites(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__reference_sites(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__placement_method(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__placement_method(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__placement_method(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__placement_method(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__placement_method(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__placement_method(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__placement_method(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__placement_method(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__electrode_sites(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__electrode_sites(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__electrode_sites(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__electrode_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__electrode_sites(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__electrode_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__electrode_sites(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__electrode_sites(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__electrode_physical_type(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__electrode_physical_type(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__electrode_physical_type(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__electrode_physical_type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__electrode_physical_type(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__electrode_physical_type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__electrode_physical_type(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__electrode_physical_type(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_member_array[13] = {
  {
    "device_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, device_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "channel_size",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, channel_size),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "units",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, units),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "selected_preprocessing",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, selected_preprocessing),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__selected_preprocessing,  // size() function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__selected_preprocessing,  // get_const(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__selected_preprocessing,  // get(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__selected_preprocessing,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__selected_preprocessing,  // assign(index, value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__selected_preprocessing  // resize(index) function pointer
  },
  {
    "montage_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, montage_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "bipolar_active_sites",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, bipolar_active_sites),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__bipolar_active_sites,  // size() function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__bipolar_active_sites,  // get_const(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__bipolar_active_sites,  // get(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__bipolar_active_sites,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__bipolar_active_sites,  // assign(index, value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__bipolar_active_sites  // resize(index) function pointer
  },
  {
    "bipolar_reference_sites",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, bipolar_reference_sites),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__bipolar_reference_sites,  // size() function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__bipolar_reference_sites,  // get_const(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__bipolar_reference_sites,  // get(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__bipolar_reference_sites,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__bipolar_reference_sites,  // assign(index, value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__bipolar_reference_sites  // resize(index) function pointer
  },
  {
    "reference_sites",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, reference_sites),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__reference_sites,  // size() function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__reference_sites,  // get_const(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__reference_sites,  // get(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__reference_sites,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__reference_sites,  // assign(index, value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__reference_sites  // resize(index) function pointer
  },
  {
    "placement_method",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, placement_method),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__placement_method,  // size() function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__placement_method,  // get_const(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__placement_method,  // get(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__placement_method,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__placement_method,  // assign(index, value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__placement_method  // resize(index) function pointer
  },
  {
    "electrode_sites",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, electrode_sites),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__electrode_sites,  // size() function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__electrode_sites,  // get_const(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__electrode_sites,  // get(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__electrode_sites,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__electrode_sites,  // assign(index, value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__electrode_sites  // resize(index) function pointer
  },
  {
    "electrode_physical_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, electrode_physical_type),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__size_function__EEGInfo__electrode_physical_type,  // size() function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_const_function__EEGInfo__electrode_physical_type,  // get_const(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__get_function__EEGInfo__electrode_physical_type,  // get(index) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__fetch_function__EEGInfo__electrode_physical_type,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__assign_function__EEGInfo__electrode_physical_type,  // assign(index, value) function pointer
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__resize_function__EEGInfo__electrode_physical_type  // resize(index) function pointer
  },
  {
    "signal_mode",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, signal_mode),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "filters",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EEGInfo, filters),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "EEGInfo",  // message name
  13,  // number of fields
  sizeof(healthcare_msgs__msg__EEGInfo),
  false,  // has_any_key_member_
  healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_member_array,  // message members
  healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__EEGInfo__get_type_hash,
  &healthcare_msgs__msg__EEGInfo__get_type_description,
  &healthcare_msgs__msg__EEGInfo__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, EEGInfo)() {
  healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, DeviceInfo)();
  healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_member_array[12].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, FilterBase)();
  if (!healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__EEGInfo__rosidl_typesupport_introspection_c__EEGInfo_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
