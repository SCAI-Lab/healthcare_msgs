// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/EMG.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/emg.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EMG__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EMG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/emg__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const EMG & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: session_id
  {
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << ", ";
  }

  // member: channel_size
  {
    out << "channel_size: ";
    rosidl_generator_traits::value_to_yaml(msg.channel_size, out);
    out << ", ";
  }

  // member: sample_size
  {
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << ", ";
  }

  // member: emg
  {
    if (msg.emg.size() == 0) {
      out << "emg: []";
    } else {
      out << "emg: [";
      size_t pending_items = msg.emg.size();
      for (auto item : msg.emg) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: signal_quality
  {
    if (msg.signal_quality.size() == 0) {
      out << "signal_quality: []";
    } else {
      out << "signal_quality: [";
      size_t pending_items = msg.signal_quality.size();
      for (auto item : msg.signal_quality) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EMG & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: session_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << "\n";
  }

  // member: channel_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "channel_size: ";
    rosidl_generator_traits::value_to_yaml(msg.channel_size, out);
    out << "\n";
  }

  // member: sample_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << "\n";
  }

  // member: emg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.emg.size() == 0) {
      out << "emg: []\n";
    } else {
      out << "emg:\n";
      for (auto item : msg.emg) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: signal_quality
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.signal_quality.size() == 0) {
      out << "signal_quality: []\n";
    } else {
      out << "signal_quality:\n";
      for (auto item : msg.signal_quality) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EMG & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::EMG & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::EMG & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::EMG>()
{
  return "healthcare_msgs::msg::EMG";
}

template<>
inline const char * name<healthcare_msgs::msg::EMG>()
{
  return "healthcare_msgs/msg/EMG";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::EMG>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::EMG>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::EMG>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EMG__TRAITS_HPP_
