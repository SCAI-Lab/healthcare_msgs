// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice
#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "healthcare_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "healthcare_msgs/msg/detail/eeg_info__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
bool cdr_serialize_healthcare_msgs__msg__EEGInfo(
  const healthcare_msgs__msg__EEGInfo * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
bool cdr_deserialize_healthcare_msgs__msg__EEGInfo(
  eprosima::fastcdr::Cdr &,
  healthcare_msgs__msg__EEGInfo * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
size_t get_serialized_size_healthcare_msgs__msg__EEGInfo(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
size_t max_serialized_size_healthcare_msgs__msg__EEGInfo(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
bool cdr_serialize_key_healthcare_msgs__msg__EEGInfo(
  const healthcare_msgs__msg__EEGInfo * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
size_t get_serialized_size_key_healthcare_msgs__msg__EEGInfo(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
size_t max_serialized_size_key_healthcare_msgs__msg__EEGInfo(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, healthcare_msgs, msg, EEGInfo)();

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
