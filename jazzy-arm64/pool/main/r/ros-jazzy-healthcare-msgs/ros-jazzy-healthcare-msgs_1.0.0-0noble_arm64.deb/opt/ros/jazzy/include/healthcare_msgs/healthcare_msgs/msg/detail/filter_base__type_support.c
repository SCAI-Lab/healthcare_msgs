// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/FilterBase.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/filter_base__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/filter_base__functions.h"
#include "healthcare_msgs/msg/detail/filter_base__struct.h"


// Include directives for member types
// Member `filters`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `band_pass_filter`
#include "healthcare_msgs/msg/band_pass_filter.h"
// Member `band_pass_filter`
#include "healthcare_msgs/msg/detail/band_pass_filter__rosidl_typesupport_introspection_c.h"
// Member `butter_worth_filter`
#include "healthcare_msgs/msg/butter_worth_filter.h"
// Member `butter_worth_filter`
#include "healthcare_msgs/msg/detail/butter_worth_filter__rosidl_typesupport_introspection_c.h"
// Member `high_pass_filter`
#include "healthcare_msgs/msg/high_pass_filter.h"
// Member `high_pass_filter`
#include "healthcare_msgs/msg/detail/high_pass_filter__rosidl_typesupport_introspection_c.h"
// Member `kalman_filter`
#include "healthcare_msgs/msg/kalman_filter.h"
// Member `kalman_filter`
#include "healthcare_msgs/msg/detail/kalman_filter__rosidl_typesupport_introspection_c.h"
// Member `low_pass_filter`
#include "healthcare_msgs/msg/low_pass_filter.h"
// Member `low_pass_filter`
#include "healthcare_msgs/msg/detail/low_pass_filter__rosidl_typesupport_introspection_c.h"
// Member `moving_average_filter`
#include "healthcare_msgs/msg/moving_average_filter.h"
// Member `moving_average_filter`
#include "healthcare_msgs/msg/detail/moving_average_filter__rosidl_typesupport_introspection_c.h"
// Member `notch_filter`
#include "healthcare_msgs/msg/notch_filter.h"
// Member `notch_filter`
#include "healthcare_msgs/msg/detail/notch_filter__rosidl_typesupport_introspection_c.h"
// Member `savitzky_golay_filter`
#include "healthcare_msgs/msg/savitzky_golay_filter.h"
// Member `savitzky_golay_filter`
#include "healthcare_msgs/msg/detail/savitzky_golay_filter__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__FilterBase__init(message_memory);
}

void healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_fini_function(void * message_memory)
{
  healthcare_msgs__msg__FilterBase__fini(message_memory);
}

size_t healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__size_function__FilterBase__filters(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__get_const_function__FilterBase__filters(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__get_function__FilterBase__filters(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__fetch_function__FilterBase__filters(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__get_const_function__FilterBase__filters(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__assign_function__FilterBase__filters(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__get_function__FilterBase__filters(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__resize_function__FilterBase__filters(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[9] = {
  {
    "filters",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, filters),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__size_function__FilterBase__filters,  // size() function pointer
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__get_const_function__FilterBase__filters,  // get_const(index) function pointer
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__get_function__FilterBase__filters,  // get(index) function pointer
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__fetch_function__FilterBase__filters,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__assign_function__FilterBase__filters,  // assign(index, value) function pointer
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__resize_function__FilterBase__filters  // resize(index) function pointer
  },
  {
    "band_pass_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, band_pass_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "butter_worth_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, butter_worth_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "high_pass_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, high_pass_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "kalman_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, kalman_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "low_pass_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, low_pass_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "moving_average_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, moving_average_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "notch_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, notch_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "savitzky_golay_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__FilterBase, savitzky_golay_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "FilterBase",  // message name
  9,  // number of fields
  sizeof(healthcare_msgs__msg__FilterBase),
  false,  // has_any_key_member_
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array,  // message members
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__FilterBase__get_type_hash,
  &healthcare_msgs__msg__FilterBase__get_type_description,
  &healthcare_msgs__msg__FilterBase__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, FilterBase)() {
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, BandPassFilter)();
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, ButterWorthFilter)();
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, HighPassFilter)();
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, KalmanFilter)();
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, LowPassFilter)();
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, MovingAverageFilter)();
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[7].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, NotchFilter)();
  healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_member_array[8].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, SavitzkyGolayFilter)();
  if (!healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__FilterBase__rosidl_typesupport_introspection_c__FilterBase_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
