// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/BrainDecodingConcentrationInfo.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__functions.h"
#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__struct.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/device_info.h"
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__rosidl_typesupport_introspection_c.h"
// Member `brain_decoding_general_info`
#include "healthcare_msgs/msg/brain_decoding_general_info.h"
// Member `brain_decoding_general_info`
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__rosidl_typesupport_introspection_c.h"
// Member `comments`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__init(message_memory);
}

void healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_fini_function(void * message_memory)
{
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_member_array[3] = {
  {
    "device_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__BrainDecodingConcentrationInfo, device_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "brain_decoding_general_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__BrainDecodingConcentrationInfo, brain_decoding_general_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "comments",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__BrainDecodingConcentrationInfo, comments),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "BrainDecodingConcentrationInfo",  // message name
  3,  // number of fields
  sizeof(healthcare_msgs__msg__BrainDecodingConcentrationInfo),
  false,  // has_any_key_member_
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_member_array,  // message members
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_hash,
  &healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_description,
  &healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, BrainDecodingConcentrationInfo)() {
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, DeviceInfo)();
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, BrainDecodingGeneralInfo)();
  if (!healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__BrainDecodingConcentrationInfo__rosidl_typesupport_introspection_c__BrainDecodingConcentrationInfo_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
