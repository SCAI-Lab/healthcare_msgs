// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/ECG.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/ecg__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/ecg__functions.h"
#include "healthcare_msgs/msg/detail/ecg__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `session_id`
#include "rosidl_runtime_c/string_functions.h"
// Member `ecg`
// Member `signal_quality`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__ECG__init(message_memory);
}

void healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_fini_function(void * message_memory)
{
  healthcare_msgs__msg__ECG__fini(message_memory);
}

size_t healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__size_function__ECG__ecg(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_const_function__ECG__ecg(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_function__ECG__ecg(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__fetch_function__ECG__ecg(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_const_function__ECG__ecg(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__assign_function__ECG__ecg(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_function__ECG__ecg(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__resize_function__ECG__ecg(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__size_function__ECG__signal_quality(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_const_function__ECG__signal_quality(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_function__ECG__signal_quality(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__fetch_function__ECG__signal_quality(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_const_function__ECG__signal_quality(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__assign_function__ECG__signal_quality(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_function__ECG__signal_quality(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__resize_function__ECG__signal_quality(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_member_array[6] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ECG, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "session_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ECG, session_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "channel_size",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ECG, channel_size),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sample_size",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ECG, sample_size),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "ecg",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ECG, ecg),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__size_function__ECG__ecg,  // size() function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_const_function__ECG__ecg,  // get_const(index) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_function__ECG__ecg,  // get(index) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__fetch_function__ECG__ecg,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__assign_function__ECG__ecg,  // assign(index, value) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__resize_function__ECG__ecg  // resize(index) function pointer
  },
  {
    "signal_quality",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ECG, signal_quality),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__size_function__ECG__signal_quality,  // size() function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_const_function__ECG__signal_quality,  // get_const(index) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__get_function__ECG__signal_quality,  // get(index) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__fetch_function__ECG__signal_quality,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__assign_function__ECG__signal_quality,  // assign(index, value) function pointer
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__resize_function__ECG__signal_quality  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "ECG",  // message name
  6,  // number of fields
  sizeof(healthcare_msgs__msg__ECG),
  false,  // has_any_key_member_
  healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_member_array,  // message members
  healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__ECG__get_type_hash,
  &healthcare_msgs__msg__ECG__get_type_description,
  &healthcare_msgs__msg__ECG__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, ECG)() {
  healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__ECG__rosidl_typesupport_introspection_c__ECG_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
