// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/CardiacOutput.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/cardiac_output.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__CardiacOutput __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__CardiacOutput __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CardiacOutput_
{
  using Type = CardiacOutput_<ContainerAllocator>;

  explicit CardiacOutput_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->sample_size = 0;
    }
  }

  explicit CardiacOutput_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    session_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->sample_size = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _session_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _session_id_type session_id;
  using _sample_size_type =
    uint16_t;
  _sample_size_type sample_size;
  using _cardiac_output_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _cardiac_output_type cardiac_output;
  using _quality_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _quality_type quality;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__session_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->session_id = _arg;
    return *this;
  }
  Type & set__sample_size(
    const uint16_t & _arg)
  {
    this->sample_size = _arg;
    return *this;
  }
  Type & set__cardiac_output(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->cardiac_output = _arg;
    return *this;
  }
  Type & set__quality(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->quality = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::CardiacOutput_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::CardiacOutput_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::CardiacOutput_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::CardiacOutput_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__CardiacOutput
    std::shared_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__CardiacOutput
    std::shared_ptr<healthcare_msgs::msg::CardiacOutput_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CardiacOutput_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->session_id != other.session_id) {
      return false;
    }
    if (this->sample_size != other.sample_size) {
      return false;
    }
    if (this->cardiac_output != other.cardiac_output) {
      return false;
    }
    if (this->quality != other.quality) {
      return false;
    }
    return true;
  }
  bool operator!=(const CardiacOutput_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CardiacOutput_

// alias to use template instance with default allocator
using CardiacOutput =
  healthcare_msgs::msg::CardiacOutput_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT__STRUCT_HPP_
