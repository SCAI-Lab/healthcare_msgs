// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/BandPassFilter.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/band_pass_filter.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/band_pass_filter__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BandPassFilter & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: low_cutoff_frequency
  {
    out << "low_cutoff_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.low_cutoff_frequency, out);
    out << ", ";
  }

  // member: high_cutoff_frequency
  {
    out << "high_cutoff_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.high_cutoff_frequency, out);
    out << ", ";
  }

  // member: order
  {
    out << "order: ";
    rosidl_generator_traits::value_to_yaml(msg.order, out);
    out << ", ";
  }

  // member: sampling_rate
  {
    out << "sampling_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.sampling_rate, out);
    out << ", ";
  }

  // member: zero_phase
  {
    out << "zero_phase: ";
    rosidl_generator_traits::value_to_yaml(msg.zero_phase, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BandPassFilter & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: low_cutoff_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "low_cutoff_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.low_cutoff_frequency, out);
    out << "\n";
  }

  // member: high_cutoff_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "high_cutoff_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.high_cutoff_frequency, out);
    out << "\n";
  }

  // member: order
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "order: ";
    rosidl_generator_traits::value_to_yaml(msg.order, out);
    out << "\n";
  }

  // member: sampling_rate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sampling_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.sampling_rate, out);
    out << "\n";
  }

  // member: zero_phase
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "zero_phase: ";
    rosidl_generator_traits::value_to_yaml(msg.zero_phase, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BandPassFilter & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::BandPassFilter & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::BandPassFilter & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::BandPassFilter>()
{
  return "healthcare_msgs::msg::BandPassFilter";
}

template<>
inline const char * name<healthcare_msgs::msg::BandPassFilter>()
{
  return "healthcare_msgs/msg/BandPassFilter";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::BandPassFilter>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::BandPassFilter>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<healthcare_msgs::msg::BandPassFilter>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__TRAITS_HPP_
