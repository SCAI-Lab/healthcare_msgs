// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/BloodVolumePulse.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/blood_volume_pulse.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__BloodVolumePulse __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__BloodVolumePulse __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BloodVolumePulse_
{
  using Type = BloodVolumePulse_<ContainerAllocator>;

  explicit BloodVolumePulse_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->sample_size = 0;
    }
  }

  explicit BloodVolumePulse_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    session_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->sample_size = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _session_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _session_id_type session_id;
  using _sample_size_type =
    uint16_t;
  _sample_size_type sample_size;
  using _bvp_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _bvp_type bvp;
  using _quality_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _quality_type quality;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__session_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->session_id = _arg;
    return *this;
  }
  Type & set__sample_size(
    const uint16_t & _arg)
  {
    this->sample_size = _arg;
    return *this;
  }
  Type & set__bvp(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->bvp = _arg;
    return *this;
  }
  Type & set__quality(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->quality = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__BloodVolumePulse
    std::shared_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__BloodVolumePulse
    std::shared_ptr<healthcare_msgs::msg::BloodVolumePulse_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BloodVolumePulse_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->session_id != other.session_id) {
      return false;
    }
    if (this->sample_size != other.sample_size) {
      return false;
    }
    if (this->bvp != other.bvp) {
      return false;
    }
    if (this->quality != other.quality) {
      return false;
    }
    return true;
  }
  bool operator!=(const BloodVolumePulse_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BloodVolumePulse_

// alias to use template instance with default allocator
using BloodVolumePulse =
  healthcare_msgs::msg::BloodVolumePulse_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__STRUCT_HPP_
