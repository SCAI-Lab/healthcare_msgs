// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from healthcare_msgs:msg/BrainDecodingConcentrationInfo.idl
// generated code does not contain a copyright notice

#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x26, 0x5f, 0x87, 0x4d, 0x32, 0x5e, 0xad, 0xc0,
      0x9c, 0x43, 0xc6, 0xfe, 0xe7, 0x6f, 0xdc, 0x57,
      0x33, 0xd8, 0xda, 0x59, 0x57, 0x24, 0x7d, 0xbd,
      0x13, 0x44, 0x88, 0xee, 0xa0, 0x06, 0xff, 0x89,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "builtin_interfaces/msg/detail/time__functions.h"
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/duration__functions.h"
#include "healthcare_msgs/msg/detail/device_info__functions.h"
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__functions.h"
#include "healthcare_msgs/msg/detail/medical_device_system__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Duration__EXPECTED_HASH = {1, {
    0xe8, 0xd0, 0x09, 0xf6, 0x59, 0x81, 0x6f, 0x75,
    0x8b, 0x75, 0x33, 0x4e, 0xe1, 0xa9, 0xca, 0x5b,
    0x5c, 0x0b, 0x85, 0x98, 0x43, 0x26, 0x1f, 0x14,
    0xc7, 0xf9, 0x37, 0x34, 0x95, 0x99, 0xd9, 0x3b,
  }};
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__BrainDecodingGeneralInfo__EXPECTED_HASH = {1, {
    0x42, 0xaf, 0x60, 0x8a, 0x26, 0x8a, 0x95, 0x2a,
    0x71, 0x3a, 0x07, 0x32, 0xaa, 0x71, 0x16, 0x32,
    0xb2, 0xd3, 0x73, 0xf3, 0x50, 0xd1, 0x05, 0x5d,
    0xf8, 0xa7, 0x1f, 0x4f, 0x23, 0x7f, 0xae, 0x8e,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__DeviceInfo__EXPECTED_HASH = {1, {
    0x4d, 0xc5, 0xe3, 0xb8, 0xd1, 0xf2, 0x32, 0xdc,
    0x47, 0x38, 0xf3, 0xb6, 0x95, 0x81, 0xb2, 0x54,
    0x04, 0xc1, 0x6b, 0xf2, 0x4a, 0x3d, 0x13, 0x43,
    0x93, 0x84, 0xd2, 0x8c, 0x39, 0x67, 0xc8, 0x37,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__MedicalDeviceSystem__EXPECTED_HASH = {1, {
    0xda, 0xb7, 0x3b, 0x18, 0x28, 0x32, 0xc2, 0x93,
    0xe7, 0x0e, 0xf8, 0xbb, 0x7a, 0x8c, 0xc3, 0x39,
    0xcf, 0xcc, 0x44, 0x98, 0x7d, 0x22, 0xf4, 0xee,
    0x91, 0x09, 0x7e, 0x63, 0xae, 0xd3, 0xa6, 0xac,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char healthcare_msgs__msg__BrainDecodingConcentrationInfo__TYPE_NAME[] = "healthcare_msgs/msg/BrainDecodingConcentrationInfo";
static char builtin_interfaces__msg__Duration__TYPE_NAME[] = "builtin_interfaces/msg/Duration";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__TYPE_NAME[] = "healthcare_msgs/msg/BrainDecodingGeneralInfo";
static char healthcare_msgs__msg__DeviceInfo__TYPE_NAME[] = "healthcare_msgs/msg/DeviceInfo";
static char healthcare_msgs__msg__MedicalDeviceSystem__TYPE_NAME[] = "healthcare_msgs/msg/MedicalDeviceSystem";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELD_NAME__device_info[] = "device_info";
static char healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELD_NAME__brain_decoding_general_info[] = "brain_decoding_general_info";
static char healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELD_NAME__comments[] = "comments";

static rosidl_runtime_c__type_description__Field healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELDS[] = {
  {
    {healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELD_NAME__device_info, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {healthcare_msgs__msg__DeviceInfo__TYPE_NAME, 30, 30},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELD_NAME__brain_decoding_general_info, 27, 27},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {healthcare_msgs__msg__BrainDecodingGeneralInfo__TYPE_NAME, 44, 44},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELD_NAME__comments, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription healthcare_msgs__msg__BrainDecodingConcentrationInfo__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Duration__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__TYPE_NAME, 44, 44},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__TYPE_NAME, 30, 30},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__MedicalDeviceSystem__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {healthcare_msgs__msg__BrainDecodingConcentrationInfo__TYPE_NAME, 50, 50},
      {healthcare_msgs__msg__BrainDecodingConcentrationInfo__FIELDS, 3, 3},
    },
    {healthcare_msgs__msg__BrainDecodingConcentrationInfo__REFERENCED_TYPE_DESCRIPTIONS, 6, 6},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Duration__EXPECTED_HASH, builtin_interfaces__msg__Duration__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Duration__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__BrainDecodingGeneralInfo__EXPECTED_HASH, healthcare_msgs__msg__BrainDecodingGeneralInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = healthcare_msgs__msg__BrainDecodingGeneralInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__DeviceInfo__EXPECTED_HASH, healthcare_msgs__msg__DeviceInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[3].fields = healthcare_msgs__msg__DeviceInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__MedicalDeviceSystem__EXPECTED_HASH, healthcare_msgs__msg__MedicalDeviceSystem__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[4].fields = healthcare_msgs__msg__MedicalDeviceSystem__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "DeviceInfo device_info\n"
  "BrainDecodingGeneralInfo brain_decoding_general_info\n"
  "string comments";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {healthcare_msgs__msg__BrainDecodingConcentrationInfo__TYPE_NAME, 50, 50},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 92, 92},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[7];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 7, 7};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Duration__get_individual_type_description_source(NULL);
    sources[2] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[3] = *healthcare_msgs__msg__BrainDecodingGeneralInfo__get_individual_type_description_source(NULL);
    sources[4] = *healthcare_msgs__msg__DeviceInfo__get_individual_type_description_source(NULL);
    sources[5] = *healthcare_msgs__msg__MedicalDeviceSystem__get_individual_type_description_source(NULL);
    sources[6] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
