// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from healthcare_msgs:msg/BloodVolumePulseInfo.idl
// generated code does not contain a copyright notice

#include "healthcare_msgs/msg/detail/blood_volume_pulse_info__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__BloodVolumePulseInfo__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xc1, 0x30, 0x72, 0xd6, 0xff, 0x51, 0xee, 0x85,
      0x0a, 0x36, 0xb9, 0xea, 0x0f, 0x7e, 0x9a, 0x81,
      0xa9, 0x8e, 0x38, 0xd1, 0x97, 0x8a, 0x91, 0xff,
      0x59, 0x89, 0xa3, 0x1c, 0x5c, 0x35, 0xfe, 0xd5,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "healthcare_msgs/msg/detail/filter_base__functions.h"
#include "healthcare_msgs/msg/detail/butter_worth_filter__functions.h"
#include "healthcare_msgs/msg/detail/high_pass_filter__functions.h"
#include "healthcare_msgs/msg/detail/medical_device_system__functions.h"
#include "healthcare_msgs/msg/detail/moving_average_filter__functions.h"
#include "healthcare_msgs/msg/detail/savitzky_golay_filter__functions.h"
#include "healthcare_msgs/msg/detail/device_info__functions.h"
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/duration__functions.h"
#include "healthcare_msgs/msg/detail/low_pass_filter__functions.h"
#include "healthcare_msgs/msg/detail/notch_filter__functions.h"
#include "healthcare_msgs/msg/detail/kalman_filter__functions.h"
#include "healthcare_msgs/msg/detail/band_pass_filter__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Duration__EXPECTED_HASH = {1, {
    0xe8, 0xd0, 0x09, 0xf6, 0x59, 0x81, 0x6f, 0x75,
    0x8b, 0x75, 0x33, 0x4e, 0xe1, 0xa9, 0xca, 0x5b,
    0x5c, 0x0b, 0x85, 0x98, 0x43, 0x26, 0x1f, 0x14,
    0xc7, 0xf9, 0x37, 0x34, 0x95, 0x99, 0xd9, 0x3b,
  }};
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__BandPassFilter__EXPECTED_HASH = {1, {
    0xc9, 0x14, 0x38, 0x84, 0x7e, 0x1c, 0xf6, 0x93,
    0xd1, 0xfc, 0xbf, 0x77, 0x4d, 0xb2, 0xfc, 0xac,
    0x15, 0x6b, 0x59, 0x23, 0x98, 0x2b, 0xf6, 0x61,
    0x5f, 0x5d, 0xfa, 0x30, 0x64, 0x55, 0xf1, 0xf6,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__ButterWorthFilter__EXPECTED_HASH = {1, {
    0x83, 0x2e, 0x1c, 0xf6, 0x91, 0xb4, 0xa1, 0xcd,
    0x5f, 0xda, 0xe1, 0x63, 0xde, 0x21, 0x22, 0x2a,
    0x4b, 0x19, 0xb4, 0x17, 0x4b, 0x4e, 0xcd, 0xa5,
    0x24, 0x9c, 0xef, 0xa1, 0x09, 0x5d, 0xff, 0x7d,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__DeviceInfo__EXPECTED_HASH = {1, {
    0x4d, 0xc5, 0xe3, 0xb8, 0xd1, 0xf2, 0x32, 0xdc,
    0x47, 0x38, 0xf3, 0xb6, 0x95, 0x81, 0xb2, 0x54,
    0x04, 0xc1, 0x6b, 0xf2, 0x4a, 0x3d, 0x13, 0x43,
    0x93, 0x84, 0xd2, 0x8c, 0x39, 0x67, 0xc8, 0x37,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__FilterBase__EXPECTED_HASH = {1, {
    0x1d, 0xfd, 0xc4, 0x38, 0xcf, 0x09, 0xbf, 0x44,
    0xf0, 0x9f, 0xe9, 0x88, 0x28, 0x0b, 0x19, 0x5a,
    0x2e, 0xfb, 0xec, 0x01, 0x1b, 0xa5, 0xa8, 0x26,
    0x6f, 0xf7, 0x6a, 0xda, 0x66, 0x98, 0xc0, 0x04,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__HighPassFilter__EXPECTED_HASH = {1, {
    0x8e, 0x1d, 0xcf, 0xf3, 0x94, 0x54, 0x7f, 0x0d,
    0x73, 0x68, 0xd6, 0xba, 0x56, 0x8e, 0x0b, 0x70,
    0x0e, 0x4f, 0xf2, 0x11, 0xa4, 0xc7, 0xa8, 0x31,
    0xe7, 0xb5, 0x53, 0xe8, 0xe3, 0x1a, 0xed, 0xa7,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__KalmanFilter__EXPECTED_HASH = {1, {
    0x1e, 0x39, 0xc3, 0x39, 0x70, 0xd4, 0xd0, 0x4b,
    0x51, 0x3d, 0x51, 0x03, 0x18, 0xbd, 0x29, 0xe5,
    0x8f, 0x9a, 0x17, 0xff, 0xe1, 0x91, 0xe1, 0x12,
    0x97, 0xa3, 0x7d, 0xb6, 0x06, 0x62, 0xe8, 0x9c,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__LowPassFilter__EXPECTED_HASH = {1, {
    0x64, 0xb0, 0xa4, 0x08, 0x29, 0x74, 0x1d, 0xcc,
    0x85, 0x98, 0xd0, 0xe6, 0xc9, 0xcd, 0xdc, 0x48,
    0x04, 0x6a, 0x9d, 0xf0, 0xb6, 0x65, 0x3b, 0xfc,
    0x93, 0x4c, 0x1d, 0x5a, 0xde, 0x8f, 0x5e, 0xf2,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__MedicalDeviceSystem__EXPECTED_HASH = {1, {
    0xda, 0xb7, 0x3b, 0x18, 0x28, 0x32, 0xc2, 0x93,
    0xe7, 0x0e, 0xf8, 0xbb, 0x7a, 0x8c, 0xc3, 0x39,
    0xcf, 0xcc, 0x44, 0x98, 0x7d, 0x22, 0xf4, 0xee,
    0x91, 0x09, 0x7e, 0x63, 0xae, 0xd3, 0xa6, 0xac,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__MovingAverageFilter__EXPECTED_HASH = {1, {
    0xd4, 0xed, 0xd6, 0x83, 0x3d, 0xbe, 0x02, 0xff,
    0xfe, 0xaa, 0xba, 0xe0, 0x3f, 0x47, 0x93, 0x9c,
    0xb1, 0xa5, 0x86, 0x9a, 0x27, 0x2b, 0x18, 0xc6,
    0x03, 0x03, 0xc7, 0xe4, 0xd3, 0x5c, 0x4a, 0xfc,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__NotchFilter__EXPECTED_HASH = {1, {
    0x3f, 0xac, 0xfc, 0x7a, 0xbc, 0x33, 0xcf, 0x76,
    0x1b, 0xc5, 0xb4, 0x92, 0xfa, 0x7f, 0xa4, 0x08,
    0xd0, 0x95, 0x35, 0xd1, 0xf4, 0xc7, 0x32, 0x5e,
    0x56, 0x99, 0xa0, 0xa2, 0xc8, 0xe4, 0xe9, 0xde,
  }};
static const rosidl_type_hash_t healthcare_msgs__msg__SavitzkyGolayFilter__EXPECTED_HASH = {1, {
    0x2b, 0xc5, 0x9c, 0x55, 0x69, 0x3b, 0x82, 0xf6,
    0xe3, 0x06, 0x32, 0xf6, 0x52, 0x0e, 0xdf, 0x7e,
    0x9c, 0x74, 0x25, 0xff, 0x44, 0x13, 0xef, 0xa2,
    0xbf, 0x75, 0x96, 0x1e, 0x83, 0xea, 0xc7, 0x3b,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char healthcare_msgs__msg__BloodVolumePulseInfo__TYPE_NAME[] = "healthcare_msgs/msg/BloodVolumePulseInfo";
static char builtin_interfaces__msg__Duration__TYPE_NAME[] = "builtin_interfaces/msg/Duration";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char healthcare_msgs__msg__BandPassFilter__TYPE_NAME[] = "healthcare_msgs/msg/BandPassFilter";
static char healthcare_msgs__msg__ButterWorthFilter__TYPE_NAME[] = "healthcare_msgs/msg/ButterWorthFilter";
static char healthcare_msgs__msg__DeviceInfo__TYPE_NAME[] = "healthcare_msgs/msg/DeviceInfo";
static char healthcare_msgs__msg__FilterBase__TYPE_NAME[] = "healthcare_msgs/msg/FilterBase";
static char healthcare_msgs__msg__HighPassFilter__TYPE_NAME[] = "healthcare_msgs/msg/HighPassFilter";
static char healthcare_msgs__msg__KalmanFilter__TYPE_NAME[] = "healthcare_msgs/msg/KalmanFilter";
static char healthcare_msgs__msg__LowPassFilter__TYPE_NAME[] = "healthcare_msgs/msg/LowPassFilter";
static char healthcare_msgs__msg__MedicalDeviceSystem__TYPE_NAME[] = "healthcare_msgs/msg/MedicalDeviceSystem";
static char healthcare_msgs__msg__MovingAverageFilter__TYPE_NAME[] = "healthcare_msgs/msg/MovingAverageFilter";
static char healthcare_msgs__msg__NotchFilter__TYPE_NAME[] = "healthcare_msgs/msg/NotchFilter";
static char healthcare_msgs__msg__SavitzkyGolayFilter__TYPE_NAME[] = "healthcare_msgs/msg/SavitzkyGolayFilter";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__device_info[] = "device_info";
static char healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__unit[] = "unit";
static char healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__sensor_placement[] = "sensor_placement";
static char healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__filters[] = "filters";

static rosidl_runtime_c__type_description__Field healthcare_msgs__msg__BloodVolumePulseInfo__FIELDS[] = {
  {
    {healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__device_info, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {healthcare_msgs__msg__DeviceInfo__TYPE_NAME, 30, 30},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__unit, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__sensor_placement, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BloodVolumePulseInfo__FIELD_NAME__filters, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {healthcare_msgs__msg__FilterBase__TYPE_NAME, 30, 30},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription healthcare_msgs__msg__BloodVolumePulseInfo__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Duration__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BandPassFilter__TYPE_NAME, 34, 34},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__ButterWorthFilter__TYPE_NAME, 37, 37},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__DeviceInfo__TYPE_NAME, 30, 30},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__FilterBase__TYPE_NAME, 30, 30},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__HighPassFilter__TYPE_NAME, 34, 34},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__KalmanFilter__TYPE_NAME, 32, 32},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__LowPassFilter__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__MedicalDeviceSystem__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__MovingAverageFilter__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__NotchFilter__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__SavitzkyGolayFilter__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__BloodVolumePulseInfo__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {healthcare_msgs__msg__BloodVolumePulseInfo__TYPE_NAME, 40, 40},
      {healthcare_msgs__msg__BloodVolumePulseInfo__FIELDS, 4, 4},
    },
    {healthcare_msgs__msg__BloodVolumePulseInfo__REFERENCED_TYPE_DESCRIPTIONS, 14, 14},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Duration__EXPECTED_HASH, builtin_interfaces__msg__Duration__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Duration__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__BandPassFilter__EXPECTED_HASH, healthcare_msgs__msg__BandPassFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = healthcare_msgs__msg__BandPassFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__ButterWorthFilter__EXPECTED_HASH, healthcare_msgs__msg__ButterWorthFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[3].fields = healthcare_msgs__msg__ButterWorthFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__DeviceInfo__EXPECTED_HASH, healthcare_msgs__msg__DeviceInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[4].fields = healthcare_msgs__msg__DeviceInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__FilterBase__EXPECTED_HASH, healthcare_msgs__msg__FilterBase__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = healthcare_msgs__msg__FilterBase__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__HighPassFilter__EXPECTED_HASH, healthcare_msgs__msg__HighPassFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[6].fields = healthcare_msgs__msg__HighPassFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__KalmanFilter__EXPECTED_HASH, healthcare_msgs__msg__KalmanFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[7].fields = healthcare_msgs__msg__KalmanFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__LowPassFilter__EXPECTED_HASH, healthcare_msgs__msg__LowPassFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[8].fields = healthcare_msgs__msg__LowPassFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__MedicalDeviceSystem__EXPECTED_HASH, healthcare_msgs__msg__MedicalDeviceSystem__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[9].fields = healthcare_msgs__msg__MedicalDeviceSystem__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__MovingAverageFilter__EXPECTED_HASH, healthcare_msgs__msg__MovingAverageFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[10].fields = healthcare_msgs__msg__MovingAverageFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__NotchFilter__EXPECTED_HASH, healthcare_msgs__msg__NotchFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[11].fields = healthcare_msgs__msg__NotchFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&healthcare_msgs__msg__SavitzkyGolayFilter__EXPECTED_HASH, healthcare_msgs__msg__SavitzkyGolayFilter__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[12].fields = healthcare_msgs__msg__SavitzkyGolayFilter__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[13].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "DeviceInfo device_info\n"
  "\n"
  "# Units Enum\n"
  "uint8 UNIT_UNKNOWN = 0\n"
  "uint8 UNIT_MV = 1                     # Millivolts\n"
  "uint8 UNIT_UV = 2                     # Microvolts\n"
  "uint8 UNIT_COUNTS = 3                 # Raw ADC counts\n"
  "uint8 UNIT_CUSTOM = 255\n"
  "\n"
  "uint8 unit\n"
  "\n"
  "# Sensor Placement Enum\n"
  "uint8 PLACEMENT_UNKNOWN = 0\n"
  "uint8 PLACEMENT_WRIST = 1\n"
  "uint8 PLACEMENT_EARLOBE = 2\n"
  "uint8 PLACEMENT_FINGER = 3\n"
  "uint8 PLACEMENT_ARM = 4\n"
  "uint8 PLACEMENT_FOREHEAD = 5\n"
  "uint8 PLACEMENT_CUSTOM = 255\n"
  "\n"
  "uint8[] sensor_placement\n"
  "\n"
  "FilterBase filters";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__BloodVolumePulseInfo__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {healthcare_msgs__msg__BloodVolumePulseInfo__TYPE_NAME, 40, 40},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 515, 515},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__BloodVolumePulseInfo__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[15];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 15, 15};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *healthcare_msgs__msg__BloodVolumePulseInfo__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Duration__get_individual_type_description_source(NULL);
    sources[2] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[3] = *healthcare_msgs__msg__BandPassFilter__get_individual_type_description_source(NULL);
    sources[4] = *healthcare_msgs__msg__ButterWorthFilter__get_individual_type_description_source(NULL);
    sources[5] = *healthcare_msgs__msg__DeviceInfo__get_individual_type_description_source(NULL);
    sources[6] = *healthcare_msgs__msg__FilterBase__get_individual_type_description_source(NULL);
    sources[7] = *healthcare_msgs__msg__HighPassFilter__get_individual_type_description_source(NULL);
    sources[8] = *healthcare_msgs__msg__KalmanFilter__get_individual_type_description_source(NULL);
    sources[9] = *healthcare_msgs__msg__LowPassFilter__get_individual_type_description_source(NULL);
    sources[10] = *healthcare_msgs__msg__MedicalDeviceSystem__get_individual_type_description_source(NULL);
    sources[11] = *healthcare_msgs__msg__MovingAverageFilter__get_individual_type_description_source(NULL);
    sources[12] = *healthcare_msgs__msg__NotchFilter__get_individual_type_description_source(NULL);
    sources[13] = *healthcare_msgs__msg__SavitzkyGolayFilter__get_individual_type_description_source(NULL);
    sources[14] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
