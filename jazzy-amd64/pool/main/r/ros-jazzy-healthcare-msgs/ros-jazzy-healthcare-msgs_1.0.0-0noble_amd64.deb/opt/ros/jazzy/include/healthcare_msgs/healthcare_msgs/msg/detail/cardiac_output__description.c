// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from healthcare_msgs:msg/CardiacOutput.idl
// generated code does not contain a copyright notice

#include "healthcare_msgs/msg/detail/cardiac_output__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__CardiacOutput__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xcb, 0x2c, 0x6c, 0x76, 0x21, 0xef, 0xed, 0x9d,
      0x4d, 0x70, 0x7d, 0xe6, 0xd2, 0x17, 0xec, 0x52,
      0x1a, 0xde, 0x6e, 0x28, 0x79, 0x3c, 0x2a, 0xe3,
      0xe5, 0x82, 0x25, 0x4f, 0xa7, 0x21, 0xcb, 0x6c,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char healthcare_msgs__msg__CardiacOutput__TYPE_NAME[] = "healthcare_msgs/msg/CardiacOutput";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char healthcare_msgs__msg__CardiacOutput__FIELD_NAME__header[] = "header";
static char healthcare_msgs__msg__CardiacOutput__FIELD_NAME__session_id[] = "session_id";
static char healthcare_msgs__msg__CardiacOutput__FIELD_NAME__sample_size[] = "sample_size";
static char healthcare_msgs__msg__CardiacOutput__FIELD_NAME__cardiac_output[] = "cardiac_output";
static char healthcare_msgs__msg__CardiacOutput__FIELD_NAME__quality[] = "quality";

static rosidl_runtime_c__type_description__Field healthcare_msgs__msg__CardiacOutput__FIELDS[] = {
  {
    {healthcare_msgs__msg__CardiacOutput__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__CardiacOutput__FIELD_NAME__session_id, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__CardiacOutput__FIELD_NAME__sample_size, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__CardiacOutput__FIELD_NAME__cardiac_output, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__CardiacOutput__FIELD_NAME__quality, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription healthcare_msgs__msg__CardiacOutput__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__CardiacOutput__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {healthcare_msgs__msg__CardiacOutput__TYPE_NAME, 33, 33},
      {healthcare_msgs__msg__CardiacOutput__FIELDS, 5, 5},
    },
    {healthcare_msgs__msg__CardiacOutput__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "std_msgs/Header header\n"
  "string session_id                     # Match DeviceInfo's session_id\n"
  "uint16 sample_size\n"
  "\n"
  "float32[] cardiac_output              # Cardic output outputted by sensor in [unit]\n"
  "float32[] quality                     # From 0 (poor) to 1 (excellent)";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__CardiacOutput__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {healthcare_msgs__msg__CardiacOutput__TYPE_NAME, 33, 33},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 268, 268},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__CardiacOutput__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *healthcare_msgs__msg__CardiacOutput__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
