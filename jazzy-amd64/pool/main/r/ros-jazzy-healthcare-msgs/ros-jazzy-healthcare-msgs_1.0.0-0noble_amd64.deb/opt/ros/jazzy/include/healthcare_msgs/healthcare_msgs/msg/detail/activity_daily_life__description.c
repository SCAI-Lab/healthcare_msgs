// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from healthcare_msgs:msg/ActivityDailyLife.idl
// generated code does not contain a copyright notice

#include "healthcare_msgs/msg/detail/activity_daily_life__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__ActivityDailyLife__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x1e, 0xa0, 0xbe, 0x40, 0x9b, 0xc1, 0xbc, 0x02,
      0xfb, 0x30, 0xd9, 0xe9, 0x94, 0x8f, 0x48, 0x01,
      0x66, 0xed, 0xb4, 0x95, 0xda, 0x7c, 0x51, 0xab,
      0x18, 0x3d, 0x94, 0x0a, 0x05, 0x83, 0xf8, 0x45,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char healthcare_msgs__msg__ActivityDailyLife__TYPE_NAME[] = "healthcare_msgs/msg/ActivityDailyLife";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char healthcare_msgs__msg__ActivityDailyLife__FIELD_NAME__header[] = "header";
static char healthcare_msgs__msg__ActivityDailyLife__FIELD_NAME__adl[] = "adl";
static char healthcare_msgs__msg__ActivityDailyLife__FIELD_NAME__confidence[] = "confidence";

static rosidl_runtime_c__type_description__Field healthcare_msgs__msg__ActivityDailyLife__FIELDS[] = {
  {
    {healthcare_msgs__msg__ActivityDailyLife__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__ActivityDailyLife__FIELD_NAME__adl, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__ActivityDailyLife__FIELD_NAME__confidence, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription healthcare_msgs__msg__ActivityDailyLife__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__ActivityDailyLife__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {healthcare_msgs__msg__ActivityDailyLife__TYPE_NAME, 37, 37},
      {healthcare_msgs__msg__ActivityDailyLife__FIELDS, 3, 3},
    },
    {healthcare_msgs__msg__ActivityDailyLife__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "std_msgs/Header header\n"
  "\n"
  "uint16 ADL_UNKNOWN                    = 0\n"
  "\n"
  "# Basic ADL (Self-Care)\n"
  "uint16 ADL_BATHING                    = 1   # ICF d510\n"
  "uint16 ADL_DRESSING                   = 2   # ICF d540\n"
  "uint16 ADL_EATING                     = 3   # ICF d550\n"
  "uint16 ADL_TOILETING                  = 4   # ICF d530\n"
  "uint16 ADL_GROOMING                   = 5   # ICF d520\n"
  "uint16 ADL_TRANSFERRING               = 6   # ICF d420 (Changing basic body position)\n"
  "uint16 ADL_MOBILITY                   = 7   # ICF d450 (Walking)\n"
  "uint16 ADL_CONTINENCE                 = 8   # ICF d5301 (Regulating urination)\n"
  "\n"
  "# Instrumental ADL (Independent Living)\n"
  "uint16 ADL_COOKING                    = 20  # ICF d630\n"
  "uint16 ADL_CLEANING                   = 21  # ICF d640\n"
  "uint16 ADL_LAUNDRY                    = 22  # ICF d6401\n"
  "uint16 ADL_SHOPPING                   = 23  # ICF d620\n"
  "uint16 ADL_USING_TRANSPORTATION       = 24  # ICF d470\n"
  "uint16 ADL_MANAGING_FINANCES          = 25  # ICF d860\n"
  "uint16 ADL_USING_TELEPHONE            = 26  # ICF d360\n"
  "uint16 ADL_TAKING_MEDICATION          = 27  # ICF d5702\n"
  "\n"
  "# Leisure & Social Participation\n"
  "uint16 ADL_SOCIAL_INTERACTION         = 40  # ICF d750\n"
  "uint16 ADL_RECREATION                 = 41  # ICF d920\n"
  "uint16 ADL_COMMUNITY_ACTIVITY         = 42  # ICF d910\n"
  "\n"
  "uint16          adl         # Activity of daily life\n"
  "float32         confidence  # Model prediction confidence level from 0 (poor) to 1 (excellent)";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__ActivityDailyLife__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {healthcare_msgs__msg__ActivityDailyLife__TYPE_NAME, 37, 37},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1427, 1427},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__ActivityDailyLife__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *healthcare_msgs__msg__ActivityDailyLife__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
