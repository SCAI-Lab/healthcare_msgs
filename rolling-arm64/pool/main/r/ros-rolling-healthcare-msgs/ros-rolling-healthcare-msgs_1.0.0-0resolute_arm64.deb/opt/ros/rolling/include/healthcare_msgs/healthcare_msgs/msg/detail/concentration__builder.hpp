// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/Concentration.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/concentration.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/concentration__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_Concentration_quality
{
public:
  explicit Init_Concentration_quality(::healthcare_msgs::msg::Concentration & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::Concentration quality(::healthcare_msgs::msg::Concentration::_quality_type arg)
  {
    msg_.quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::Concentration msg_;
};

class Init_Concentration_is_concentrated
{
public:
  explicit Init_Concentration_is_concentrated(::healthcare_msgs::msg::Concentration & msg)
  : msg_(msg)
  {}
  Init_Concentration_quality is_concentrated(::healthcare_msgs::msg::Concentration::_is_concentrated_type arg)
  {
    msg_.is_concentrated = std::move(arg);
    return Init_Concentration_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::Concentration msg_;
};

class Init_Concentration_confidence
{
public:
  explicit Init_Concentration_confidence(::healthcare_msgs::msg::Concentration & msg)
  : msg_(msg)
  {}
  Init_Concentration_is_concentrated confidence(::healthcare_msgs::msg::Concentration::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_Concentration_is_concentrated(msg_);
  }

private:
  ::healthcare_msgs::msg::Concentration msg_;
};

class Init_Concentration_concentration_score
{
public:
  explicit Init_Concentration_concentration_score(::healthcare_msgs::msg::Concentration & msg)
  : msg_(msg)
  {}
  Init_Concentration_confidence concentration_score(::healthcare_msgs::msg::Concentration::_concentration_score_type arg)
  {
    msg_.concentration_score = std::move(arg);
    return Init_Concentration_confidence(msg_);
  }

private:
  ::healthcare_msgs::msg::Concentration msg_;
};

class Init_Concentration_sample_size
{
public:
  explicit Init_Concentration_sample_size(::healthcare_msgs::msg::Concentration & msg)
  : msg_(msg)
  {}
  Init_Concentration_concentration_score sample_size(::healthcare_msgs::msg::Concentration::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_Concentration_concentration_score(msg_);
  }

private:
  ::healthcare_msgs::msg::Concentration msg_;
};

class Init_Concentration_session_id
{
public:
  explicit Init_Concentration_session_id(::healthcare_msgs::msg::Concentration & msg)
  : msg_(msg)
  {}
  Init_Concentration_sample_size session_id(::healthcare_msgs::msg::Concentration::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_Concentration_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::Concentration msg_;
};

class Init_Concentration_header
{
public:
  Init_Concentration_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Concentration_session_id header(::healthcare_msgs::msg::Concentration::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Concentration_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::Concentration msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::Concentration>()
{
  return healthcare_msgs::msg::builder::Init_Concentration_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__BUILDER_HPP_
