// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/FilterBase.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/filter_base.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'TYPE_NONE'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_NONE = 0
};

/// Constant 'TYPE_BAND_PASS'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_BAND_PASS = 1
};

/// Constant 'TYPE_BUTTERWORTH'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_BUTTERWORTH = 2
};

/// Constant 'TYPE_HIGH_PASS'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_HIGH_PASS = 3
};

/// Constant 'TYPE_KALMAN'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_KALMAN = 4
};

/// Constant 'TYPE_LOW_PASS'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_LOW_PASS = 5
};

/// Constant 'TYPE_MOVING_AVERAGE'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_MOVING_AVERAGE = 6
};

/// Constant 'TYPE_NOTCH'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_NOTCH = 7
};

/// Constant 'TYPE_SAVITZKY_GOLAY'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_SAVITZKY_GOLAY = 8
};

/// Constant 'TYPE_CUSTOM'.
enum
{
  healthcare_msgs__msg__FilterBase__TYPE_CUSTOM = 255
};

// Include directives for member types
// Member 'filters'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'band_pass_filter'
#include "healthcare_msgs/msg/detail/band_pass_filter__struct.h"
// Member 'butter_worth_filter'
#include "healthcare_msgs/msg/detail/butter_worth_filter__struct.h"
// Member 'high_pass_filter'
#include "healthcare_msgs/msg/detail/high_pass_filter__struct.h"
// Member 'kalman_filter'
#include "healthcare_msgs/msg/detail/kalman_filter__struct.h"
// Member 'low_pass_filter'
#include "healthcare_msgs/msg/detail/low_pass_filter__struct.h"
// Member 'moving_average_filter'
#include "healthcare_msgs/msg/detail/moving_average_filter__struct.h"
// Member 'notch_filter'
#include "healthcare_msgs/msg/detail/notch_filter__struct.h"
// Member 'savitzky_golay_filter'
#include "healthcare_msgs/msg/detail/savitzky_golay_filter__struct.h"

/// Struct defined in msg/FilterBase in the package healthcare_msgs.
/**
  * Enum values for filter_type
 */
typedef struct healthcare_msgs__msg__FilterBase
{
  /// If several filters are applied, indicate the sequential order
  rosidl_runtime_c__uint8__Sequence filters;
  healthcare_msgs__msg__BandPassFilter band_pass_filter;
  healthcare_msgs__msg__ButterWorthFilter butter_worth_filter;
  healthcare_msgs__msg__HighPassFilter high_pass_filter;
  healthcare_msgs__msg__KalmanFilter kalman_filter;
  healthcare_msgs__msg__LowPassFilter low_pass_filter;
  healthcare_msgs__msg__MovingAverageFilter moving_average_filter;
  healthcare_msgs__msg__NotchFilter notch_filter;
  healthcare_msgs__msg__SavitzkyGolayFilter savitzky_golay_filter;
} healthcare_msgs__msg__FilterBase;

// Struct for a sequence of healthcare_msgs__msg__FilterBase.
typedef struct healthcare_msgs__msg__FilterBase__Sequence
{
  healthcare_msgs__msg__FilterBase * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__FilterBase__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__STRUCT_H_
