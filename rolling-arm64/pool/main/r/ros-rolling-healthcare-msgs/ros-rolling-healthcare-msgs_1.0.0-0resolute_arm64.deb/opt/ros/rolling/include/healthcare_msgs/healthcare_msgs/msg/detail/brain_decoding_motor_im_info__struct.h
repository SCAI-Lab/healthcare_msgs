// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BrainDecodingMotorImInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_motor_im_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'MI_FEATURE_BETA'.
/**
  * Motor Imagery Specific Feature Enum
  * Beta-band specific analysis
 */
enum
{
  healthcare_msgs__msg__BrainDecodingMotorImInfo__MI_FEATURE_BETA = 70
};

/// Constant 'MI_FEATURE_MU'.
/**
  * Mu-band specific analysis
 */
enum
{
  healthcare_msgs__msg__BrainDecodingMotorImInfo__MI_FEATURE_MU = 71
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.h"
// Member 'mi_features'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'comments'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/BrainDecodingMotorImInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BrainDecodingMotorImInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  healthcare_msgs__msg__BrainDecodingGeneralInfo brain_decoding_general_info;
  rosidl_runtime_c__uint8__Sequence mi_features;
  rosidl_runtime_c__String comments;
} healthcare_msgs__msg__BrainDecodingMotorImInfo;

// Struct for a sequence of healthcare_msgs__msg__BrainDecodingMotorImInfo.
typedef struct healthcare_msgs__msg__BrainDecodingMotorImInfo__Sequence
{
  healthcare_msgs__msg__BrainDecodingMotorImInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BrainDecodingMotorImInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__STRUCT_H_
