// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingGeneralInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_general_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_buffer/buffer.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__BrainDecodingGeneralInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__BrainDecodingGeneralInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BrainDecodingGeneralInfo_
{
  using Type = BrainDecodingGeneralInfo_<ContainerAllocator>;

  explicit BrainDecodingGeneralInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->windowing_function = "";
      this->window_size = 0;
      this->window_overlap = 0;
      this->output_method = 0;
      this->num_windows_per_output = 0;
      this->classifier_model_name = "";
      this->model_version = "";
    }
  }

  explicit BrainDecodingGeneralInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : windowing_function(_alloc),
    classifier_model_name(_alloc),
    model_version(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->windowing_function = "";
      this->window_size = 0;
      this->window_overlap = 0;
      this->output_method = 0;
      this->num_windows_per_output = 0;
      this->classifier_model_name = "";
      this->model_version = "";
    }
  }

  // field types and members
  using _windowing_function_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _windowing_function_type windowing_function;
  using _window_size_type =
    uint16_t;
  _window_size_type window_size;
  using _window_overlap_type =
    uint16_t;
  _window_overlap_type window_overlap;
  using _output_method_type =
    uint8_t;
  _output_method_type output_method;
  using _num_windows_per_output_type =
    uint16_t;
  _num_windows_per_output_type num_windows_per_output;
  using _classifier_model_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _classifier_model_name_type classifier_model_name;
  using _model_version_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _model_version_type model_version;
  using _selected_preprocessing_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _selected_preprocessing_type selected_preprocessing;
  using _selected_features_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _selected_features_type selected_features;

  // setters for named parameter idiom
  Type & set__windowing_function(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->windowing_function = _arg;
    return *this;
  }
  Type & set__window_size(
    const uint16_t & _arg)
  {
    this->window_size = _arg;
    return *this;
  }
  Type & set__window_overlap(
    const uint16_t & _arg)
  {
    this->window_overlap = _arg;
    return *this;
  }
  Type & set__output_method(
    const uint8_t & _arg)
  {
    this->output_method = _arg;
    return *this;
  }
  Type & set__num_windows_per_output(
    const uint16_t & _arg)
  {
    this->num_windows_per_output = _arg;
    return *this;
  }
  Type & set__classifier_model_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->classifier_model_name = _arg;
    return *this;
  }
  Type & set__model_version(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->model_version = _arg;
    return *this;
  }
  Type & set__selected_preprocessing(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->selected_preprocessing = _arg;
    return *this;
  }
  Type & set__selected_features(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->selected_features = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t OUTPUT_METHOD_UNKNOWN =
    0u;
  static constexpr uint8_t OUTPUT_METHOD_SINGLE_WINDOW =
    1u;
  static constexpr uint8_t OUTPUT_METHOD_MULTIPLE_WINDOW =
    2u;
  static constexpr uint8_t OUTPUT_METHOD_AVERAGE =
    3u;
  static constexpr uint8_t OUTPUT_METHOD_SAMPLE_WISE =
    4u;
  static constexpr uint8_t OUTPUT_METHOD_CUSTOM =
    255u;
  static constexpr uint8_t EEG_PREPROC_UNKNOWN =
    0u;
  static constexpr uint8_t EEG_PREPROC_BANDPASS =
    1u;
  static constexpr uint8_t EEG_PREPROC_NOTCH =
    2u;
  static constexpr uint8_t EEG_PREPROC_ICA =
    3u;
  static constexpr uint8_t EEG_PREPROC_CAR =
    4u;
  static constexpr uint8_t EEG_PREPROC_ARTEFACT_REJ =
    5u;
  static constexpr uint8_t EEG_PREPROC_BASELINE_CORR =
    6u;
  static constexpr uint8_t EEG_PREPROC_DOWNSAMPLE =
    7u;
  static constexpr uint8_t EEG_PREPROC_SEGMENTED =
    8u;
  static constexpr uint8_t EEG_PREPROC_CUSTOM =
    255u;
  static constexpr uint8_t EEG_FEATURE_UNKNOWN =
    0u;
  static constexpr uint8_t EEG_FEATURE_FREQUENCY_WELCH =
    1u;
  static constexpr uint8_t EEG_FEATURE_EXTRACT_PSD =
    2u;
  static constexpr uint8_t EEG_FEATURE_MORLET =
    3u;
  static constexpr uint8_t EEG_FEATURE_BAND_POWER =
    4u;
  static constexpr uint8_t EEG_FEATURE_RELATIVE_POWER =
    5u;
  static constexpr uint8_t EEG_FEATURE_SPECTRAL_FEATURES =
    6u;
  static constexpr uint8_t EEG_FEATURE_PEAK =
    10u;
  static constexpr uint8_t EEG_FEATURE_HJORTH =
    11u;
  static constexpr uint8_t EEG_FEATURE_ENTROPY =
    20u;
  static constexpr uint8_t EEG_FEATURE_SAMPLE_ENTROPY =
    21u;
  static constexpr uint8_t EEG_FEATURE_HFD =
    22u;
  static constexpr uint8_t EEG_FEATURE_PFD =
    23u;
  static constexpr uint8_t EEG_FEATURE_DFA =
    24u;
  static constexpr uint8_t EEG_FEATURE_GRAPH_FEATURES =
    30u;
  static constexpr uint8_t EEG_FEATURE_SOURCE_CONNECTIVITY =
    31u;
  static constexpr uint8_t EEG_FEATURE_CONNECTIVITY =
    32u;
  static constexpr uint8_t EEG_FEATURE_DECODING_CSP =
    33u;
  static constexpr uint8_t EEG_FEATURE_SSL_FEATURES =
    34u;
  static constexpr uint8_t EEG_FEATURE_PLV =
    35u;
  static constexpr uint8_t EEG_FEATURE_COHERENCE =
    36u;
  static constexpr uint8_t EEG_FEATURE_GRAPH_CONNECTIVITY =
    37u;
  static constexpr uint8_t EEG_FEATURE_STAT_FEATURES =
    40u;
  static constexpr uint8_t EEG_FEATURE_RIEMAN_COVARIANCE =
    41u;
  static constexpr uint8_t EEG_FEATURE_CORR_MATRIX =
    42u;
  static constexpr uint8_t EEG_FEATURE_CSP =
    50u;
  static constexpr uint8_t EEG_FEATURE_FBCSP =
    51u;
  static constexpr uint8_t EEG_FEATURE_XDAWN =
    52u;
  static constexpr uint8_t EEG_FEATURE_FUSION =
    60u;
  static constexpr uint8_t EEG_FEATURE_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__BrainDecodingGeneralInfo
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__BrainDecodingGeneralInfo
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BrainDecodingGeneralInfo_ & other) const
  {
    if (this->windowing_function != other.windowing_function) {
      return false;
    }
    if (this->window_size != other.window_size) {
      return false;
    }
    if (this->window_overlap != other.window_overlap) {
      return false;
    }
    if (this->output_method != other.output_method) {
      return false;
    }
    if (this->num_windows_per_output != other.num_windows_per_output) {
      return false;
    }
    if (this->classifier_model_name != other.classifier_model_name) {
      return false;
    }
    if (this->model_version != other.model_version) {
      return false;
    }
    if (this->selected_preprocessing != other.selected_preprocessing) {
      return false;
    }
    if (this->selected_features != other.selected_features) {
      return false;
    }
    return true;
  }
  bool operator!=(const BrainDecodingGeneralInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BrainDecodingGeneralInfo_

// alias to use template instance with default allocator
using BrainDecodingGeneralInfo =
  healthcare_msgs::msg::BrainDecodingGeneralInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::OUTPUT_METHOD_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::OUTPUT_METHOD_SINGLE_WINDOW;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::OUTPUT_METHOD_MULTIPLE_WINDOW;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::OUTPUT_METHOD_AVERAGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::OUTPUT_METHOD_SAMPLE_WISE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::OUTPUT_METHOD_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_BANDPASS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_NOTCH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_ICA;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_CAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_ARTEFACT_REJ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_BASELINE_CORR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_DOWNSAMPLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_SEGMENTED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_PREPROC_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_FREQUENCY_WELCH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_EXTRACT_PSD;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_MORLET;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_BAND_POWER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_RELATIVE_POWER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_SPECTRAL_FEATURES;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_PEAK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_HJORTH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_ENTROPY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_SAMPLE_ENTROPY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_HFD;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_PFD;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_DFA;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_GRAPH_FEATURES;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_SOURCE_CONNECTIVITY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_CONNECTIVITY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_DECODING_CSP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_SSL_FEATURES;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_PLV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_COHERENCE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_GRAPH_CONNECTIVITY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_STAT_FEATURES;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_RIEMAN_COVARIANCE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_CORR_MATRIX;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_CSP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_FBCSP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_XDAWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_FUSION;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingGeneralInfo_<ContainerAllocator>::EEG_FEATURE_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__STRUCT_HPP_
