// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EOGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eog_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/eog_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EOGInfo_filters
{
public:
  explicit Init_EOGInfo_filters(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EOGInfo filters(::healthcare_msgs::msg::EOGInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_length_light_dark_phase
{
public:
  explicit Init_EOGInfo_length_light_dark_phase(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  Init_EOGInfo_filters length_light_dark_phase(::healthcare_msgs::msg::EOGInfo::_length_light_dark_phase_type arg)
  {
    msg_.length_light_dark_phase = std::move(arg);
    return Init_EOGInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_gazefield_background_light_brightness
{
public:
  explicit Init_EOGInfo_gazefield_background_light_brightness(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  Init_EOGInfo_length_light_dark_phase gazefield_background_light_brightness(::healthcare_msgs::msg::EOGInfo::_gazefield_background_light_brightness_type arg)
  {
    msg_.gazefield_background_light_brightness = std::move(arg);
    return Init_EOGInfo_length_light_dark_phase(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_lightsource
{
public:
  explicit Init_EOGInfo_lightsource(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  Init_EOGInfo_gazefield_background_light_brightness lightsource(::healthcare_msgs::msg::EOGInfo::_lightsource_type arg)
  {
    msg_.lightsource = std::move(arg);
    return Init_EOGInfo_gazefield_background_light_brightness(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_signal_mode
{
public:
  explicit Init_EOGInfo_signal_mode(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  Init_EOGInfo_lightsource signal_mode(::healthcare_msgs::msg::EOGInfo::_signal_mode_type arg)
  {
    msg_.signal_mode = std::move(arg);
    return Init_EOGInfo_lightsource(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_lead_type
{
public:
  explicit Init_EOGInfo_lead_type(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  Init_EOGInfo_signal_mode lead_type(::healthcare_msgs::msg::EOGInfo::_lead_type_type arg)
  {
    msg_.lead_type = std::move(arg);
    return Init_EOGInfo_signal_mode(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_electrode_placement
{
public:
  explicit Init_EOGInfo_electrode_placement(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  Init_EOGInfo_lead_type electrode_placement(::healthcare_msgs::msg::EOGInfo::_electrode_placement_type arg)
  {
    msg_.electrode_placement = std::move(arg);
    return Init_EOGInfo_lead_type(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_units
{
public:
  explicit Init_EOGInfo_units(::healthcare_msgs::msg::EOGInfo & msg)
  : msg_(msg)
  {}
  Init_EOGInfo_electrode_placement units(::healthcare_msgs::msg::EOGInfo::_units_type arg)
  {
    msg_.units = std::move(arg);
    return Init_EOGInfo_electrode_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

class Init_EOGInfo_device_info
{
public:
  Init_EOGInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EOGInfo_units device_info(::healthcare_msgs::msg::EOGInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_EOGInfo_units(msg_);
  }

private:
  ::healthcare_msgs::msg::EOGInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EOGInfo>()
{
  return healthcare_msgs::msg::builder::Init_EOGInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__BUILDER_HPP_
