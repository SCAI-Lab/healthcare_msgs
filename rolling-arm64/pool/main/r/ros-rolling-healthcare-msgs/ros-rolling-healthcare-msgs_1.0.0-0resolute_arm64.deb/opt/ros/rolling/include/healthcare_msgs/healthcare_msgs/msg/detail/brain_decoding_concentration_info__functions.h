// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from healthcare_msgs:msg/BrainDecodingConcentrationInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_concentration_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__FUNCTIONS_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/action_type_support_struct.h"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_runtime_c/service_type_support_struct.h"
#include "rosidl_runtime_c/type_description/type_description__struct.h"
#include "rosidl_runtime_c/type_description/type_source__struct.h"
#include "rosidl_runtime_c/type_hash.h"
#include "rosidl_runtime_c/visibility_control.h"
#include "healthcare_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__struct.h"

/// Initialize msg/BrainDecodingConcentrationInfo message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo
 * )) before or use
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BrainDecodingConcentrationInfo__init(healthcare_msgs__msg__BrainDecodingConcentrationInfo * msg);

/// Finalize msg/BrainDecodingConcentrationInfo message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BrainDecodingConcentrationInfo__fini(healthcare_msgs__msg__BrainDecodingConcentrationInfo * msg);

/// Create msg/BrainDecodingConcentrationInfo message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__BrainDecodingConcentrationInfo *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__create(void);

/// Destroy msg/BrainDecodingConcentrationInfo message.
/**
 * It calls
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BrainDecodingConcentrationInfo__destroy(healthcare_msgs__msg__BrainDecodingConcentrationInfo * msg);

/// Check for msg/BrainDecodingConcentrationInfo message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BrainDecodingConcentrationInfo__are_equal(const healthcare_msgs__msg__BrainDecodingConcentrationInfo * lhs, const healthcare_msgs__msg__BrainDecodingConcentrationInfo * rhs);

/// Copy a msg/BrainDecodingConcentrationInfo message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BrainDecodingConcentrationInfo__copy(
  const healthcare_msgs__msg__BrainDecodingConcentrationInfo * input,
  healthcare_msgs__msg__BrainDecodingConcentrationInfo * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of msg/BrainDecodingConcentrationInfo messages.
/**
 * It allocates the memory for the number of elements and calls
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__init(healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence * array, size_t size);

/// Finalize array of msg/BrainDecodingConcentrationInfo messages.
/**
 * It calls
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__fini(healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence * array);

/// Create array of msg/BrainDecodingConcentrationInfo messages.
/**
 * It allocates the memory for the array and calls
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence *
healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__create(size_t size);

/// Destroy array of msg/BrainDecodingConcentrationInfo messages.
/**
 * It calls
 * healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__destroy(healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence * array);

/// Check for msg/BrainDecodingConcentrationInfo message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__are_equal(const healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence * lhs, const healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence * rhs);

/// Copy an array of msg/BrainDecodingConcentrationInfo messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence__copy(
  const healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence * input,
  healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__FUNCTIONS_H_
