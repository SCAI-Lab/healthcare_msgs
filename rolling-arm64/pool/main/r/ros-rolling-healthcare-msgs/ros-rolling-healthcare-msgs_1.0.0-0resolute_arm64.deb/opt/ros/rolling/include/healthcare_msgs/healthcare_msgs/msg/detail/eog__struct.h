// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EOG.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eog.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EOG__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EOG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"
// Member 'eog'
// Member 'signal_quality'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/EOG in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EOG
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint8_t channel_size;
  uint16_t sample_size;
  /// Raw or filtered BCG values [channel]x[sample]
  rosidl_runtime_c__float__Sequence eog;
  /// From 0 (poor) to 1 (excellent)
  rosidl_runtime_c__float__Sequence signal_quality;
} healthcare_msgs__msg__EOG;

// Struct for a sequence of healthcare_msgs__msg__EOG.
typedef struct healthcare_msgs__msg__EOG__Sequence
{
  healthcare_msgs__msg__EOG * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EOG__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EOG__STRUCT_H_
