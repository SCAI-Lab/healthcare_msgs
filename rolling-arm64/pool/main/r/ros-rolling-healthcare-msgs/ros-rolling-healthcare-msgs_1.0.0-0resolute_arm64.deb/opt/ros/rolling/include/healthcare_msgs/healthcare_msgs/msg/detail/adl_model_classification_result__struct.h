// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/adl_model_classification_result.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'device_serial_number'
// Member 'glossary'
// Member 'model_type'
// Member 'model_version'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ADLModelClassificationResult in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__ADLModelClassificationResult
{
  std_msgs__msg__Header header;
  /// Serialnumbers of the devices of signal origin
  rosidl_runtime_c__String__Sequence device_serial_number;
  /// Possibilities linked to the prediction_probability with same index
  rosidl_runtime_c__String__Sequence glossary;
  /// Amount of Classes (2=supine/nonsupine, 3=supine/nonsupine/nonoccupied, 4, 5)
  uint16_t class_amount;
  /// Machine learning model type
  rosidl_runtime_c__String__Sequence model_type;
  /// The version the model is trained with/ From what data was the model created
  rosidl_runtime_c__String__Sequence model_version;
} healthcare_msgs__msg__ADLModelClassificationResult;

// Struct for a sequence of healthcare_msgs__msg__ADLModelClassificationResult.
typedef struct healthcare_msgs__msg__ADLModelClassificationResult__Sequence
{
  healthcare_msgs__msg__ADLModelClassificationResult * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__ADLModelClassificationResult__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__STRUCT_H_
