// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/EDAInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eda_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/eda_info__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const EDAInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: electrode_placement
  {
    if (msg.electrode_placement.size() == 0) {
      out << "electrode_placement: []";
    } else {
      out << "electrode_placement: [";
      size_t pending_items = msg.electrode_placement.size();
      for (auto item : msg.electrode_placement) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: electrode_type
  {
    if (msg.electrode_type.size() == 0) {
      out << "electrode_type: []";
    } else {
      out << "electrode_type: [";
      size_t pending_items = msg.electrode_type.size();
      for (auto item : msg.electrode_type) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: measuring_technique
  {
    out << "measuring_technique: ";
    rosidl_generator_traits::value_to_yaml(msg.measuring_technique, out);
    out << ", ";
  }

  // member: current_form
  {
    out << "current_form: ";
    rosidl_generator_traits::value_to_yaml(msg.current_form, out);
    out << ", ";
  }

  // member: filters
  {
    out << "filters: ";
    to_flow_style_yaml(msg.filters, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EDAInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: electrode_placement
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.electrode_placement.size() == 0) {
      out << "electrode_placement: []\n";
    } else {
      out << "electrode_placement:\n";
      for (auto item : msg.electrode_placement) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: electrode_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.electrode_type.size() == 0) {
      out << "electrode_type: []\n";
    } else {
      out << "electrode_type:\n";
      for (auto item : msg.electrode_type) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: measuring_technique
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measuring_technique: ";
    rosidl_generator_traits::value_to_yaml(msg.measuring_technique, out);
    out << "\n";
  }

  // member: current_form
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current_form: ";
    rosidl_generator_traits::value_to_yaml(msg.current_form, out);
    out << "\n";
  }

  // member: filters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filters:\n";
    to_block_style_yaml(msg.filters, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EDAInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::EDAInfo>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).device_info,
    std::forward<T>(msg).electrode_placement,
    std::forward<T>(msg).electrode_type,
    std::forward<T>(msg).measuring_technique,
    std::forward<T>(msg).current_form,
    std::forward<T>(msg).filters);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::EDAInfo>()
{
  return "healthcare_msgs::msg::EDAInfo";
}

template<>
constexpr const char * name<healthcare_msgs::msg::EDAInfo>()
{
  return "healthcare_msgs/msg/EDAInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::EDAInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::EDAInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::EDAInfo>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::EDAInfo>
{
  static constexpr std::size_t member_count = 6;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "device_info",
    "electrode_placement",
    "electrode_type",
    "measuring_technique",
    "current_form",
    "filters",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__TRAITS_HPP_
