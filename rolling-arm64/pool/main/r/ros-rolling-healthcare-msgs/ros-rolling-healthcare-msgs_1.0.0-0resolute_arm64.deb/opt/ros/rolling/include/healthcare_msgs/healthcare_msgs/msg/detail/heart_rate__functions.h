// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from healthcare_msgs:msg/HeartRate.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/heart_rate.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__FUNCTIONS_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/action_type_support_struct.h"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_runtime_c/service_type_support_struct.h"
#include "rosidl_runtime_c/type_description/type_description__struct.h"
#include "rosidl_runtime_c/type_description/type_source__struct.h"
#include "rosidl_runtime_c/type_hash.h"
#include "rosidl_runtime_c/visibility_control.h"
#include "healthcare_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "healthcare_msgs/msg/detail/heart_rate__struct.h"

/// Initialize msg/HeartRate message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * healthcare_msgs__msg__HeartRate
 * )) before or use
 * healthcare_msgs__msg__HeartRate__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRate__init(healthcare_msgs__msg__HeartRate * msg);

/// Finalize msg/HeartRate message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRate__fini(healthcare_msgs__msg__HeartRate * msg);

/// Create msg/HeartRate message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * healthcare_msgs__msg__HeartRate__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__HeartRate *
healthcare_msgs__msg__HeartRate__create(void);

/// Destroy msg/HeartRate message.
/**
 * It calls
 * healthcare_msgs__msg__HeartRate__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRate__destroy(healthcare_msgs__msg__HeartRate * msg);

/// Check for msg/HeartRate message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRate__are_equal(const healthcare_msgs__msg__HeartRate * lhs, const healthcare_msgs__msg__HeartRate * rhs);

/// Copy a msg/HeartRate message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRate__copy(
  const healthcare_msgs__msg__HeartRate * input,
  healthcare_msgs__msg__HeartRate * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__HeartRate__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__HeartRate__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__HeartRate__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__HeartRate__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of msg/HeartRate messages.
/**
 * It allocates the memory for the number of elements and calls
 * healthcare_msgs__msg__HeartRate__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRate__Sequence__init(healthcare_msgs__msg__HeartRate__Sequence * array, size_t size);

/// Finalize array of msg/HeartRate messages.
/**
 * It calls
 * healthcare_msgs__msg__HeartRate__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRate__Sequence__fini(healthcare_msgs__msg__HeartRate__Sequence * array);

/// Create array of msg/HeartRate messages.
/**
 * It allocates the memory for the array and calls
 * healthcare_msgs__msg__HeartRate__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__HeartRate__Sequence *
healthcare_msgs__msg__HeartRate__Sequence__create(size_t size);

/// Destroy array of msg/HeartRate messages.
/**
 * It calls
 * healthcare_msgs__msg__HeartRate__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRate__Sequence__destroy(healthcare_msgs__msg__HeartRate__Sequence * array);

/// Check for msg/HeartRate message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRate__Sequence__are_equal(const healthcare_msgs__msg__HeartRate__Sequence * lhs, const healthcare_msgs__msg__HeartRate__Sequence * rhs);

/// Copy an array of msg/HeartRate messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRate__Sequence__copy(
  const healthcare_msgs__msg__HeartRate__Sequence * input,
  healthcare_msgs__msg__HeartRate__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__FUNCTIONS_H_
