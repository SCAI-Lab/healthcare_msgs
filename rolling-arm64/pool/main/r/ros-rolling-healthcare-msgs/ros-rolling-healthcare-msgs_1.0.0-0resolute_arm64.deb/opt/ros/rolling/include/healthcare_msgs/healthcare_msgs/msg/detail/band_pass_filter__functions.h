// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from healthcare_msgs:msg/BandPassFilter.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/band_pass_filter.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__FUNCTIONS_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/action_type_support_struct.h"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_runtime_c/service_type_support_struct.h"
#include "rosidl_runtime_c/type_description/type_description__struct.h"
#include "rosidl_runtime_c/type_description/type_source__struct.h"
#include "rosidl_runtime_c/type_hash.h"
#include "rosidl_runtime_c/visibility_control.h"
#include "healthcare_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "healthcare_msgs/msg/detail/band_pass_filter__struct.h"

/// Initialize msg/BandPassFilter message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * healthcare_msgs__msg__BandPassFilter
 * )) before or use
 * healthcare_msgs__msg__BandPassFilter__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BandPassFilter__init(healthcare_msgs__msg__BandPassFilter * msg);

/// Finalize msg/BandPassFilter message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BandPassFilter__fini(healthcare_msgs__msg__BandPassFilter * msg);

/// Create msg/BandPassFilter message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * healthcare_msgs__msg__BandPassFilter__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__BandPassFilter *
healthcare_msgs__msg__BandPassFilter__create(void);

/// Destroy msg/BandPassFilter message.
/**
 * It calls
 * healthcare_msgs__msg__BandPassFilter__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BandPassFilter__destroy(healthcare_msgs__msg__BandPassFilter * msg);

/// Check for msg/BandPassFilter message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BandPassFilter__are_equal(const healthcare_msgs__msg__BandPassFilter * lhs, const healthcare_msgs__msg__BandPassFilter * rhs);

/// Copy a msg/BandPassFilter message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BandPassFilter__copy(
  const healthcare_msgs__msg__BandPassFilter * input,
  healthcare_msgs__msg__BandPassFilter * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__BandPassFilter__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__BandPassFilter__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__BandPassFilter__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__BandPassFilter__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of msg/BandPassFilter messages.
/**
 * It allocates the memory for the number of elements and calls
 * healthcare_msgs__msg__BandPassFilter__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BandPassFilter__Sequence__init(healthcare_msgs__msg__BandPassFilter__Sequence * array, size_t size);

/// Finalize array of msg/BandPassFilter messages.
/**
 * It calls
 * healthcare_msgs__msg__BandPassFilter__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BandPassFilter__Sequence__fini(healthcare_msgs__msg__BandPassFilter__Sequence * array);

/// Create array of msg/BandPassFilter messages.
/**
 * It allocates the memory for the array and calls
 * healthcare_msgs__msg__BandPassFilter__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__BandPassFilter__Sequence *
healthcare_msgs__msg__BandPassFilter__Sequence__create(size_t size);

/// Destroy array of msg/BandPassFilter messages.
/**
 * It calls
 * healthcare_msgs__msg__BandPassFilter__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__BandPassFilter__Sequence__destroy(healthcare_msgs__msg__BandPassFilter__Sequence * array);

/// Check for msg/BandPassFilter message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BandPassFilter__Sequence__are_equal(const healthcare_msgs__msg__BandPassFilter__Sequence * lhs, const healthcare_msgs__msg__BandPassFilter__Sequence * rhs);

/// Copy an array of msg/BandPassFilter messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__BandPassFilter__Sequence__copy(
  const healthcare_msgs__msg__BandPassFilter__Sequence * input,
  healthcare_msgs__msg__BandPassFilter__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__FUNCTIONS_H_
