// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/BrainDecodingGeneralInfo.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `windowing_function`
// Member `classifier_model_name`
// Member `model_version`
#include "rosidl_runtime_c/string_functions.h"
// Member `selected_preprocessing`
// Member `selected_features`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
healthcare_msgs__msg__BrainDecodingGeneralInfo__init(healthcare_msgs__msg__BrainDecodingGeneralInfo * msg)
{
  if (!msg) {
    return false;
  }
  // windowing_function
  if (!rosidl_runtime_c__String__init(&msg->windowing_function)) {
    healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(msg);
    return false;
  }
  // window_size
  // window_overlap
  // output_method
  // num_windows_per_output
  // classifier_model_name
  if (!rosidl_runtime_c__String__init(&msg->classifier_model_name)) {
    healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(msg);
    return false;
  }
  // model_version
  if (!rosidl_runtime_c__String__init(&msg->model_version)) {
    healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(msg);
    return false;
  }
  // selected_preprocessing
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->selected_preprocessing, 0)) {
    healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(msg);
    return false;
  }
  // selected_features
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->selected_features, 0)) {
    healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(healthcare_msgs__msg__BrainDecodingGeneralInfo * msg)
{
  if (!msg) {
    return;
  }
  // windowing_function
  rosidl_runtime_c__String__fini(&msg->windowing_function);
  // window_size
  // window_overlap
  // output_method
  // num_windows_per_output
  // classifier_model_name
  rosidl_runtime_c__String__fini(&msg->classifier_model_name);
  // model_version
  rosidl_runtime_c__String__fini(&msg->model_version);
  // selected_preprocessing
  rosidl_runtime_c__uint8__Sequence__fini(&msg->selected_preprocessing);
  // selected_features
  rosidl_runtime_c__uint8__Sequence__fini(&msg->selected_features);
}

bool
healthcare_msgs__msg__BrainDecodingGeneralInfo__are_equal(const healthcare_msgs__msg__BrainDecodingGeneralInfo * lhs, const healthcare_msgs__msg__BrainDecodingGeneralInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // windowing_function
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->windowing_function), &(rhs->windowing_function)))
  {
    return false;
  }
  // window_size
  if (lhs->window_size != rhs->window_size) {
    return false;
  }
  // window_overlap
  if (lhs->window_overlap != rhs->window_overlap) {
    return false;
  }
  // output_method
  if (lhs->output_method != rhs->output_method) {
    return false;
  }
  // num_windows_per_output
  if (lhs->num_windows_per_output != rhs->num_windows_per_output) {
    return false;
  }
  // classifier_model_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->classifier_model_name), &(rhs->classifier_model_name)))
  {
    return false;
  }
  // model_version
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->model_version), &(rhs->model_version)))
  {
    return false;
  }
  // selected_preprocessing
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->selected_preprocessing), &(rhs->selected_preprocessing)))
  {
    return false;
  }
  // selected_features
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->selected_features), &(rhs->selected_features)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__BrainDecodingGeneralInfo__copy(
  const healthcare_msgs__msg__BrainDecodingGeneralInfo * input,
  healthcare_msgs__msg__BrainDecodingGeneralInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // windowing_function
  if (!rosidl_runtime_c__String__copy(
      &(input->windowing_function), &(output->windowing_function)))
  {
    return false;
  }
  // window_size
  output->window_size = input->window_size;
  // window_overlap
  output->window_overlap = input->window_overlap;
  // output_method
  output->output_method = input->output_method;
  // num_windows_per_output
  output->num_windows_per_output = input->num_windows_per_output;
  // classifier_model_name
  if (!rosidl_runtime_c__String__copy(
      &(input->classifier_model_name), &(output->classifier_model_name)))
  {
    return false;
  }
  // model_version
  if (!rosidl_runtime_c__String__copy(
      &(input->model_version), &(output->model_version)))
  {
    return false;
  }
  // selected_preprocessing
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->selected_preprocessing), &(output->selected_preprocessing)))
  {
    return false;
  }
  // selected_features
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->selected_features), &(output->selected_features)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__BrainDecodingGeneralInfo *
healthcare_msgs__msg__BrainDecodingGeneralInfo__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BrainDecodingGeneralInfo * msg = (healthcare_msgs__msg__BrainDecodingGeneralInfo *)allocator.allocate(sizeof(healthcare_msgs__msg__BrainDecodingGeneralInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__BrainDecodingGeneralInfo));
  bool success = healthcare_msgs__msg__BrainDecodingGeneralInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__BrainDecodingGeneralInfo__destroy(healthcare_msgs__msg__BrainDecodingGeneralInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__init(healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BrainDecodingGeneralInfo * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__BrainDecodingGeneralInfo *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__BrainDecodingGeneralInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__BrainDecodingGeneralInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__fini(healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence *
healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * array = (healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__destroy(healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__are_equal(const healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * lhs, const healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__BrainDecodingGeneralInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence__copy(
  const healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * input,
  healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__BrainDecodingGeneralInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__BrainDecodingGeneralInfo * data =
      (healthcare_msgs__msg__BrainDecodingGeneralInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__BrainDecodingGeneralInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__BrainDecodingGeneralInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
