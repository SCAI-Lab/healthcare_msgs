// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/EOGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eog_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_buffer/buffer.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__EOGInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__EOGInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct EOGInfo_
{
  using Type = EOGInfo_<ContainerAllocator>;

  explicit EOGInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    filters(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
      this->signal_mode = 0;
      this->lightsource = 0;
      this->gazefield_background_light_brightness = 0.0f;
    }
  }

  explicit EOGInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    filters(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
      this->signal_mode = 0;
      this->lightsource = 0;
      this->gazefield_background_light_brightness = 0.0f;
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _units_type =
    uint8_t;
  _units_type units;
  using _electrode_placement_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_placement_type electrode_placement;
  using _lead_type_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _lead_type_type lead_type;
  using _signal_mode_type =
    uint8_t;
  _signal_mode_type signal_mode;
  using _lightsource_type =
    uint8_t;
  _lightsource_type lightsource;
  using _gazefield_background_light_brightness_type =
    float;
  _gazefield_background_light_brightness_type gazefield_background_light_brightness;
  using _length_light_dark_phase_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _length_light_dark_phase_type length_light_dark_phase;
  using _filters_type =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator>;
  _filters_type filters;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__units(
    const uint8_t & _arg)
  {
    this->units = _arg;
    return *this;
  }
  Type & set__electrode_placement(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_placement = _arg;
    return *this;
  }
  Type & set__lead_type(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->lead_type = _arg;
    return *this;
  }
  Type & set__signal_mode(
    const uint8_t & _arg)
  {
    this->signal_mode = _arg;
    return *this;
  }
  Type & set__lightsource(
    const uint8_t & _arg)
  {
    this->lightsource = _arg;
    return *this;
  }
  Type & set__gazefield_background_light_brightness(
    const float & _arg)
  {
    this->gazefield_background_light_brightness = _arg;
    return *this;
  }
  Type & set__length_light_dark_phase(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->length_light_dark_phase = _arg;
    return *this;
  }
  Type & set__filters(
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> & _arg)
  {
    this->filters = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t UNIT_UNKNOWN =
    0u;
  static constexpr uint8_t UNIT_UV =
    1u;
  static constexpr uint8_t UNIT_MV =
    2u;
  static constexpr uint8_t UNIT_COUNTS =
    3u;
  static constexpr uint8_t PLACEMENT_UNKNOWN =
    0u;
  static constexpr uint8_t PLACEMENT_LEFT_EYE =
    1u;
  static constexpr uint8_t PLACEMENT_RIGHT_EYE =
    2u;
  static constexpr uint8_t PLACEMENT_FOREHEAD =
    3u;
  static constexpr uint8_t PLACEMENT_TEMPLE_LEFT =
    4u;
  static constexpr uint8_t PLACEMENT_TEMPLE_RIGHT =
    5u;
  static constexpr uint8_t PLACEMENT_ABOVE_EYE =
    6u;
  static constexpr uint8_t PLACEMENT_BELOW_EYE =
    7u;
  static constexpr uint8_t PLACEMENT_CUSTOM =
    255u;
  static constexpr uint8_t LEAD_UNKNOWN =
    0u;
  static constexpr uint8_t LEAD_BIPOLAR_HORIZONTAL =
    1u;
  static constexpr uint8_t LEAD_BIPOLAR_VERTICAL =
    2u;
  static constexpr uint8_t LEAD_UNIPOLAR =
    3u;
  static constexpr uint8_t LEAD_CORNEAL_RETINAL =
    4u;
  static constexpr uint8_t LEAD_CUSTOM =
    255u;
  static constexpr uint8_t MODE_UNKNOWN =
    0u;
  static constexpr uint8_t MODE_SURFACE =
    1u;
  static constexpr uint8_t MODE_BIPOLAR =
    2u;
  static constexpr uint8_t MODE_UNIPOLAR =
    3u;
  static constexpr uint8_t MODE_CORNEAL_RETINAL =
    4u;
  static constexpr uint8_t MODE_INTRACULAR =
    5u;
  static constexpr uint8_t MODE_DERIVED =
    6u;
  static constexpr uint8_t MODE_CUSTOM =
    255u;
  static constexpr uint8_t LIGHTSOURCE_UNKNOWN =
    0u;
  static constexpr uint8_t LIGHTSOURCE_TUNGSTEN =
    1u;
  static constexpr uint8_t LIGHTSOURCE_HALOGEN =
    2u;
  static constexpr uint8_t LIGHTSOURCE_LED =
    3u;
  static constexpr uint8_t LIGHTSOURCE_FLUORESCENT =
    4u;
  static constexpr uint8_t LIGHTSOURCE_SUNLIGHT =
    5u;
  static constexpr uint8_t LIGHTSOURCE_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::EOGInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::EOGInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EOGInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EOGInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__EOGInfo
    std::shared_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__EOGInfo
    std::shared_ptr<healthcare_msgs::msg::EOGInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EOGInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->units != other.units) {
      return false;
    }
    if (this->electrode_placement != other.electrode_placement) {
      return false;
    }
    if (this->lead_type != other.lead_type) {
      return false;
    }
    if (this->signal_mode != other.signal_mode) {
      return false;
    }
    if (this->lightsource != other.lightsource) {
      return false;
    }
    if (this->gazefield_background_light_brightness != other.gazefield_background_light_brightness) {
      return false;
    }
    if (this->length_light_dark_phase != other.length_light_dark_phase) {
      return false;
    }
    if (this->filters != other.filters) {
      return false;
    }
    return true;
  }
  bool operator!=(const EOGInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EOGInfo_

// alias to use template instance with default allocator
using EOGInfo =
  healthcare_msgs::msg::EOGInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::UNIT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::UNIT_UV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::UNIT_MV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::UNIT_COUNTS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_LEFT_EYE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_RIGHT_EYE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_FOREHEAD;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_TEMPLE_LEFT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_TEMPLE_RIGHT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_ABOVE_EYE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_BELOW_EYE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::PLACEMENT_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LEAD_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LEAD_BIPOLAR_HORIZONTAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LEAD_BIPOLAR_VERTICAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LEAD_UNIPOLAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LEAD_CORNEAL_RETINAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LEAD_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_SURFACE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_BIPOLAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_UNIPOLAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_CORNEAL_RETINAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_INTRACULAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_DERIVED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::MODE_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LIGHTSOURCE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LIGHTSOURCE_TUNGSTEN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LIGHTSOURCE_HALOGEN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LIGHTSOURCE_LED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LIGHTSOURCE_FLUORESCENT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LIGHTSOURCE_SUNLIGHT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EOGInfo_<ContainerAllocator>::LIGHTSOURCE_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__STRUCT_HPP_
