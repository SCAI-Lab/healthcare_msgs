// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/DeviceInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/device_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_buffer/buffer.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'mds'
#include "healthcare_msgs/msg/detail/medical_device_system__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__DeviceInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__DeviceInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DeviceInfo_
{
  using Type = DeviceInfo_<ContainerAllocator>;

  explicit DeviceInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    mds(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->device_manufacturer = "";
      this->device_name = "";
      this->device_type = "";
      this->device_serial_number = "";
      this->minimal_operation_temperature = 0.0f;
      this->maximal_operation_temperature = 0.0f;
      this->maximal_relative_humidity = 0.0f;
      this->minimal_atmospheric_pressure = 0.0f;
      this->maximal_atmospheric_pressure = 0.0f;
      this->measuring_unit = "";
      this->acquisition_rate_hz = 0;
      this->gain = 0.0f;
      this->resolution = 0.0f;
      this->adc_resolution = 0;
      this->accuracy = 0.0f;
      this->max_range = 0.0f;
      this->min_range = 0.0f;
      this->window_size_samples = 0ul;
      this->quality_window_size_samples = 0ul;
      this->stride_length = 0.0f;
    }
  }

  explicit DeviceInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    session_id(_alloc),
    mds(_alloc, _init),
    device_manufacturer(_alloc),
    device_name(_alloc),
    device_type(_alloc),
    device_serial_number(_alloc),
    measuring_unit(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->device_manufacturer = "";
      this->device_name = "";
      this->device_type = "";
      this->device_serial_number = "";
      this->minimal_operation_temperature = 0.0f;
      this->maximal_operation_temperature = 0.0f;
      this->maximal_relative_humidity = 0.0f;
      this->minimal_atmospheric_pressure = 0.0f;
      this->maximal_atmospheric_pressure = 0.0f;
      this->measuring_unit = "";
      this->acquisition_rate_hz = 0;
      this->gain = 0.0f;
      this->resolution = 0.0f;
      this->adc_resolution = 0;
      this->accuracy = 0.0f;
      this->max_range = 0.0f;
      this->min_range = 0.0f;
      this->window_size_samples = 0ul;
      this->quality_window_size_samples = 0ul;
      this->stride_length = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _session_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _session_id_type session_id;
  using _mds_type =
    healthcare_msgs::msg::MedicalDeviceSystem_<ContainerAllocator>;
  _mds_type mds;
  using _device_manufacturer_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _device_manufacturer_type device_manufacturer;
  using _device_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _device_name_type device_name;
  using _device_type_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _device_type_type device_type;
  using _device_serial_number_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _device_serial_number_type device_serial_number;
  using _minimal_operation_temperature_type =
    float;
  _minimal_operation_temperature_type minimal_operation_temperature;
  using _maximal_operation_temperature_type =
    float;
  _maximal_operation_temperature_type maximal_operation_temperature;
  using _maximal_relative_humidity_type =
    float;
  _maximal_relative_humidity_type maximal_relative_humidity;
  using _minimal_atmospheric_pressure_type =
    float;
  _minimal_atmospheric_pressure_type minimal_atmospheric_pressure;
  using _maximal_atmospheric_pressure_type =
    float;
  _maximal_atmospheric_pressure_type maximal_atmospheric_pressure;
  using _measuring_unit_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _measuring_unit_type measuring_unit;
  using _acquisition_rate_hz_type =
    uint16_t;
  _acquisition_rate_hz_type acquisition_rate_hz;
  using _gain_type =
    float;
  _gain_type gain;
  using _resolution_type =
    float;
  _resolution_type resolution;
  using _adc_resolution_type =
    uint8_t;
  _adc_resolution_type adc_resolution;
  using _accuracy_type =
    float;
  _accuracy_type accuracy;
  using _max_range_type =
    float;
  _max_range_type max_range;
  using _min_range_type =
    float;
  _min_range_type min_range;
  using _window_size_samples_type =
    uint32_t;
  _window_size_samples_type window_size_samples;
  using _quality_window_size_samples_type =
    uint32_t;
  _quality_window_size_samples_type quality_window_size_samples;
  using _stride_length_type =
    float;
  _stride_length_type stride_length;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__session_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->session_id = _arg;
    return *this;
  }
  Type & set__mds(
    const healthcare_msgs::msg::MedicalDeviceSystem_<ContainerAllocator> & _arg)
  {
    this->mds = _arg;
    return *this;
  }
  Type & set__device_manufacturer(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->device_manufacturer = _arg;
    return *this;
  }
  Type & set__device_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->device_name = _arg;
    return *this;
  }
  Type & set__device_type(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->device_type = _arg;
    return *this;
  }
  Type & set__device_serial_number(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->device_serial_number = _arg;
    return *this;
  }
  Type & set__minimal_operation_temperature(
    const float & _arg)
  {
    this->minimal_operation_temperature = _arg;
    return *this;
  }
  Type & set__maximal_operation_temperature(
    const float & _arg)
  {
    this->maximal_operation_temperature = _arg;
    return *this;
  }
  Type & set__maximal_relative_humidity(
    const float & _arg)
  {
    this->maximal_relative_humidity = _arg;
    return *this;
  }
  Type & set__minimal_atmospheric_pressure(
    const float & _arg)
  {
    this->minimal_atmospheric_pressure = _arg;
    return *this;
  }
  Type & set__maximal_atmospheric_pressure(
    const float & _arg)
  {
    this->maximal_atmospheric_pressure = _arg;
    return *this;
  }
  Type & set__measuring_unit(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->measuring_unit = _arg;
    return *this;
  }
  Type & set__acquisition_rate_hz(
    const uint16_t & _arg)
  {
    this->acquisition_rate_hz = _arg;
    return *this;
  }
  Type & set__gain(
    const float & _arg)
  {
    this->gain = _arg;
    return *this;
  }
  Type & set__resolution(
    const float & _arg)
  {
    this->resolution = _arg;
    return *this;
  }
  Type & set__adc_resolution(
    const uint8_t & _arg)
  {
    this->adc_resolution = _arg;
    return *this;
  }
  Type & set__accuracy(
    const float & _arg)
  {
    this->accuracy = _arg;
    return *this;
  }
  Type & set__max_range(
    const float & _arg)
  {
    this->max_range = _arg;
    return *this;
  }
  Type & set__min_range(
    const float & _arg)
  {
    this->min_range = _arg;
    return *this;
  }
  Type & set__window_size_samples(
    const uint32_t & _arg)
  {
    this->window_size_samples = _arg;
    return *this;
  }
  Type & set__quality_window_size_samples(
    const uint32_t & _arg)
  {
    this->quality_window_size_samples = _arg;
    return *this;
  }
  Type & set__stride_length(
    const float & _arg)
  {
    this->stride_length = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__DeviceInfo
    std::shared_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__DeviceInfo
    std::shared_ptr<healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DeviceInfo_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->session_id != other.session_id) {
      return false;
    }
    if (this->mds != other.mds) {
      return false;
    }
    if (this->device_manufacturer != other.device_manufacturer) {
      return false;
    }
    if (this->device_name != other.device_name) {
      return false;
    }
    if (this->device_type != other.device_type) {
      return false;
    }
    if (this->device_serial_number != other.device_serial_number) {
      return false;
    }
    if (this->minimal_operation_temperature != other.minimal_operation_temperature) {
      return false;
    }
    if (this->maximal_operation_temperature != other.maximal_operation_temperature) {
      return false;
    }
    if (this->maximal_relative_humidity != other.maximal_relative_humidity) {
      return false;
    }
    if (this->minimal_atmospheric_pressure != other.minimal_atmospheric_pressure) {
      return false;
    }
    if (this->maximal_atmospheric_pressure != other.maximal_atmospheric_pressure) {
      return false;
    }
    if (this->measuring_unit != other.measuring_unit) {
      return false;
    }
    if (this->acquisition_rate_hz != other.acquisition_rate_hz) {
      return false;
    }
    if (this->gain != other.gain) {
      return false;
    }
    if (this->resolution != other.resolution) {
      return false;
    }
    if (this->adc_resolution != other.adc_resolution) {
      return false;
    }
    if (this->accuracy != other.accuracy) {
      return false;
    }
    if (this->max_range != other.max_range) {
      return false;
    }
    if (this->min_range != other.min_range) {
      return false;
    }
    if (this->window_size_samples != other.window_size_samples) {
      return false;
    }
    if (this->quality_window_size_samples != other.quality_window_size_samples) {
      return false;
    }
    if (this->stride_length != other.stride_length) {
      return false;
    }
    return true;
  }
  bool operator!=(const DeviceInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DeviceInfo_

// alias to use template instance with default allocator
using DeviceInfo =
  healthcare_msgs::msg::DeviceInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__STRUCT_HPP_
