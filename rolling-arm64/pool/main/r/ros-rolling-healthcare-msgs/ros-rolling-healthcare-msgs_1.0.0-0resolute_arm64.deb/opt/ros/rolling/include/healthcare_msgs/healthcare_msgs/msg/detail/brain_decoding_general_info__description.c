// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from healthcare_msgs:msg/BrainDecodingGeneralInfo.idl
// generated code does not contain a copyright notice

#include "healthcare_msgs/msg/detail/brain_decoding_general_info__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
const rosidl_type_hash_t *
healthcare_msgs__msg__BrainDecodingGeneralInfo__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x42, 0xaf, 0x60, 0x8a, 0x26, 0x8a, 0x95, 0x2a,
      0x71, 0x3a, 0x07, 0x32, 0xaa, 0x71, 0x16, 0x32,
      0xb2, 0xd3, 0x73, 0xf3, 0x50, 0xd1, 0x05, 0x5d,
      0xf8, 0xa7, 0x1f, 0x4f, 0x23, 0x7f, 0xae, 0x8e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char healthcare_msgs__msg__BrainDecodingGeneralInfo__TYPE_NAME[] = "healthcare_msgs/msg/BrainDecodingGeneralInfo";

// Define type names, field names, and default values
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__windowing_function[] = "windowing_function";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__window_size[] = "window_size";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__window_overlap[] = "window_overlap";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__output_method[] = "output_method";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__num_windows_per_output[] = "num_windows_per_output";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__classifier_model_name[] = "classifier_model_name";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__model_version[] = "model_version";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__selected_preprocessing[] = "selected_preprocessing";
static char healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__selected_features[] = "selected_features";

static rosidl_runtime_c__type_description__Field healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELDS[] = {
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__windowing_function, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__window_size, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__window_overlap, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__output_method, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__num_windows_per_output, 22, 22},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__classifier_model_name, 21, 21},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__model_version, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__selected_preprocessing, 22, 22},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELD_NAME__selected_features, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
healthcare_msgs__msg__BrainDecodingGeneralInfo__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {healthcare_msgs__msg__BrainDecodingGeneralInfo__TYPE_NAME, 44, 44},
      {healthcare_msgs__msg__BrainDecodingGeneralInfo__FIELDS, 9, 9},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Windowing that leads to the output\n"
  "string windowing_function\n"
  "uint16 window_size\n"
  "uint16 window_overlap\n"
  "\n"
  "# Output Method Enum\n"
  "uint8 OUTPUT_METHOD_UNKNOWN           = 0\n"
  "uint8 OUTPUT_METHOD_SINGLE_WINDOW     = 1\n"
  "uint8 OUTPUT_METHOD_MULTIPLE_WINDOW   = 2\n"
  "uint8 OUTPUT_METHOD_AVERAGE           = 3\n"
  "uint8 OUTPUT_METHOD_SAMPLE_WISE\\t\\t  = 4   \n"
  "uint8 OUTPUT_METHOD_CUSTOM            = 255 \n"
  "\n"
  "uint8 output_method\n"
  "\n"
  "uint16 num_windows_per_output\\t\\t\\t\\t\\t# For multiple-window or averaging methods (only if output_method = 2, 3 or 4), this specifies how many windows to combine.\n"
  "\n"
  "# Model information\n"
  "string classifier_model_name\n"
  "string model_version\n"
  "\n"
  "# EEG Preprocessing Enum\n"
  "uint8 EEG_PREPROC_UNKNOWN            = 0\n"
  "\n"
  "uint8 EEG_PREPROC_BANDPASS          = 1  # Bandpass filter applied\n"
  "uint8 EEG_PREPROC_NOTCH             = 2  # Notch filter (e.g., 50/60 Hz)\n"
  "uint8 EEG_PREPROC_ICA               = 3  # Independent Component Analysis\n"
  "uint8 EEG_PREPROC_CAR               = 4  # Common Average Reference\n"
  "uint8 EEG_PREPROC_ARTEFACT_REJ      = 5  # Artifact rejection/interpolation\n"
  "uint8 EEG_PREPROC_BASELINE_CORR     = 6  # Baseline correction\n"
  "uint8 EEG_PREPROC_DOWNSAMPLE        = 7  # Downsampling\n"
  "uint8 EEG_PREPROC_SEGMENTED         = 8  # Epoching / segmentation\n"
  "\n"
  "uint8 EEG_PREPROC_CUSTOM            = 255 \n"
  "\n"
  "uint8[] selected_preprocessing\\t\\t\\t\\t\\t\\t\n"
  "\n"
  "# EEG Feature Enum\n"
  "uint8 EEG_FEATURE_UNKNOWN            = 0\n"
  "\n"
  "# Frequency Domain\n"
  "uint8 EEG_FEATURE_FREQUENCY_WELCH     = 1   # Compute power spectral density using Welch's method\n"
  "uint8 EEG_FEATURE_EXTRACT_PSD         = 2   # Compute power spectral density (general)\n"
  "uint8 EEG_FEATURE_MORLET              = 3   # Time-frequency features via Morlet wavelets\n"
  "uint8 EEG_FEATURE_BAND_POWER          = 4   # Compute power in standard EEG bands (delta, theta, alpha, beta, gamma)\n"
  "uint8 EEG_FEATURE_RELATIVE_POWER      = 5   # Relative power ratios between bands\n"
  "uint8 EEG_FEATURE_SPECTRAL_FEATURES   = 6   # Frequency-domain metrics (spectral slope, centroid, etc.)\n"
  "\n"
  "# Time Domain\n"
  "uint8 EEG_FEATURE_PEAK                = 10  # Extract peak latency and amplitude from EEG\n"
  "uint8 EEG_FEATURE_HJORTH              = 11  # Hjorth parameters: activity, mobility, complexity\n"
  "\n"
  "# Complexity\n"
  "uint8 EEG_FEATURE_ENTROPY             = 20  # Spectral entropy\n"
  "uint8 EEG_FEATURE_SAMPLE_ENTROPY      = 21  # Sample entropy (pattern regularity)\n"
  "uint8 EEG_FEATURE_HFD                 = 22  # Higuchi Fractal Dimension\n"
  "uint8 EEG_FEATURE_PFD                 = 23  # Petrosian Fractal Dimension\n"
  "uint8 EEG_FEATURE_DFA                 = 24  # Detrended Fluctuation Analysis\n"
  "\n"
  "# Connectivity / State Domain\n"
  "uint8 EEG_FEATURE_GRAPH_FEATURES      = 30  # Graph-theoretic EEG features\n"
  "uint8 EEG_FEATURE_SOURCE_CONNECTIVITY = 31  # Source-level connectivity matrices\n"
  "uint8 EEG_FEATURE_CONNECTIVITY        = 32  # Coherence, PLV, or other connectivity metrics\n"
  "uint8 EEG_FEATURE_DECODING_CSP        = 33  # Common Spatial Patterns for ERP / MI decoding\n"
  "uint8 EEG_FEATURE_SSL_FEATURES        = 34  # Self-supervised latent features\n"
  "uint8 EEG_FEATURE_PLV                  = 35  # Phase-Locking Value between channels (phase consistency)\n"
  "uint8 EEG_FEATURE_COHERENCE            = 36  # Frequency-domain linear synchronization between channels\n"
  "uint8 EEG_FEATURE_GRAPH_CONNECTIVITY   = 37  # Graph-theoretic measures from channel connectivity\n"
  "\n"
  "# Statistical\n"
  "uint8 EEG_FEATURE_STAT_FEATURES       = 40  # Mean, variance, skewness, kurtosis\n"
  "uint8 EEG_FEATURE_RIEMAN_COVARIANCE   = 41  # Covariance matrices Riemannian tangent space\n"
  "uint8 EEG_FEATURE_CORR_MATRIX         = 42 # Raw covariance or correlation between EEG channels\n"
  "\n"
  "# Spatial Filtering (MI-specific)\n"
  "uint8 EEG_FEATURE_CSP                   = 50  # Common Spatial Patterns, maximizes variance differences between classes\n"
  "uint8 EEG_FEATURE_FBCSP                 = 51  # Filter Bank CSP, applies CSP over multiple frequency bands\n"
  "uint8 EEG_FEATURE_XDAWN                 = 52  # xDAWN spatial filtering to enhance signal-to-noise\n"
  "\n"
  "# cross-category fusion \n"
  "uint8 EEG_FEATURE_FUSION                = 60  # Combines multiple feature types into a single feature vector\n"
  "\n"
  "uint8 EEG_FEATURE_CUSTOM              = 255  \n"
  "\n"
  "uint8[] selected_features\\t\\t\\t\\t\\t\\t";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
healthcare_msgs__msg__BrainDecodingGeneralInfo__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {healthcare_msgs__msg__BrainDecodingGeneralInfo__TYPE_NAME, 44, 44},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 4182, 4182},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
healthcare_msgs__msg__BrainDecodingGeneralInfo__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *healthcare_msgs__msg__BrainDecodingGeneralInfo__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
