// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/CardiacOutput.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/cardiac_output__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/cardiac_output__functions.h"
#include "healthcare_msgs/msg/detail/cardiac_output__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `session_id`
#include "rosidl_runtime_c/string_functions.h"
// Member `cardiac_output`
// Member `quality`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__CardiacOutput__init(message_memory);
}

void healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_fini_function(void * message_memory)
{
  healthcare_msgs__msg__CardiacOutput__fini(message_memory);
}

size_t healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__size_function__CardiacOutput__cardiac_output(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_const_function__CardiacOutput__cardiac_output(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_function__CardiacOutput__cardiac_output(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__fetch_function__CardiacOutput__cardiac_output(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_const_function__CardiacOutput__cardiac_output(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__assign_function__CardiacOutput__cardiac_output(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_function__CardiacOutput__cardiac_output(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__resize_function__CardiacOutput__cardiac_output(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__size_function__CardiacOutput__quality(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_const_function__CardiacOutput__quality(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_function__CardiacOutput__quality(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__fetch_function__CardiacOutput__quality(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_const_function__CardiacOutput__quality(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__assign_function__CardiacOutput__quality(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_function__CardiacOutput__quality(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__resize_function__CardiacOutput__quality(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_member_array[5] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__CardiacOutput, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "session_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__CardiacOutput, session_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "sample_size",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__CardiacOutput, sample_size),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "cardiac_output",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__CardiacOutput, cardiac_output),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__size_function__CardiacOutput__cardiac_output,  // size() function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_const_function__CardiacOutput__cardiac_output,  // get_const(index) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_function__CardiacOutput__cardiac_output,  // get(index) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__fetch_function__CardiacOutput__cardiac_output,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__assign_function__CardiacOutput__cardiac_output,  // assign(index, value) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__resize_function__CardiacOutput__cardiac_output,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "quality",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__CardiacOutput, quality),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__size_function__CardiacOutput__quality,  // size() function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_const_function__CardiacOutput__quality,  // get_const(index) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__get_function__CardiacOutput__quality,  // get(index) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__fetch_function__CardiacOutput__quality,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__assign_function__CardiacOutput__quality,  // assign(index, value) function pointer
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__resize_function__CardiacOutput__quality,  // resize(index) function pointer
    false  // is_rosidl_buffer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "CardiacOutput",  // message name
  5,  // number of fields
  sizeof(healthcare_msgs__msg__CardiacOutput),
  false,  // has_any_key_member_
  healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_member_array,  // message members
  healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__CardiacOutput__get_type_hash,
  &healthcare_msgs__msg__CardiacOutput__get_type_description,
  &healthcare_msgs__msg__CardiacOutput__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, CardiacOutput)() {
  healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__CardiacOutput__rosidl_typesupport_introspection_c__CardiacOutput_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
