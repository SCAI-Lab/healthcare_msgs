// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/ButterWorthFilter.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/butter_worth_filter.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/butter_worth_filter__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_ButterWorthFilter_zero_phase
{
public:
  explicit Init_ButterWorthFilter_zero_phase(::healthcare_msgs::msg::ButterWorthFilter & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::ButterWorthFilter zero_phase(::healthcare_msgs::msg::ButterWorthFilter::_zero_phase_type arg)
  {
    msg_.zero_phase = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::ButterWorthFilter msg_;
};

class Init_ButterWorthFilter_sampling_rate
{
public:
  explicit Init_ButterWorthFilter_sampling_rate(::healthcare_msgs::msg::ButterWorthFilter & msg)
  : msg_(msg)
  {}
  Init_ButterWorthFilter_zero_phase sampling_rate(::healthcare_msgs::msg::ButterWorthFilter::_sampling_rate_type arg)
  {
    msg_.sampling_rate = std::move(arg);
    return Init_ButterWorthFilter_zero_phase(msg_);
  }

private:
  ::healthcare_msgs::msg::ButterWorthFilter msg_;
};

class Init_ButterWorthFilter_order
{
public:
  explicit Init_ButterWorthFilter_order(::healthcare_msgs::msg::ButterWorthFilter & msg)
  : msg_(msg)
  {}
  Init_ButterWorthFilter_sampling_rate order(::healthcare_msgs::msg::ButterWorthFilter::_order_type arg)
  {
    msg_.order = std::move(arg);
    return Init_ButterWorthFilter_sampling_rate(msg_);
  }

private:
  ::healthcare_msgs::msg::ButterWorthFilter msg_;
};

class Init_ButterWorthFilter_cutoff_frequency
{
public:
  explicit Init_ButterWorthFilter_cutoff_frequency(::healthcare_msgs::msg::ButterWorthFilter & msg)
  : msg_(msg)
  {}
  Init_ButterWorthFilter_order cutoff_frequency(::healthcare_msgs::msg::ButterWorthFilter::_cutoff_frequency_type arg)
  {
    msg_.cutoff_frequency = std::move(arg);
    return Init_ButterWorthFilter_order(msg_);
  }

private:
  ::healthcare_msgs::msg::ButterWorthFilter msg_;
};

class Init_ButterWorthFilter_header
{
public:
  Init_ButterWorthFilter_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ButterWorthFilter_cutoff_frequency header(::healthcare_msgs::msg::ButterWorthFilter::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ButterWorthFilter_cutoff_frequency(msg_);
  }

private:
  ::healthcare_msgs::msg::ButterWorthFilter msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::ButterWorthFilter>()
{
  return healthcare_msgs::msg::builder::Init_ButterWorthFilter_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__BUILDER_HPP_
