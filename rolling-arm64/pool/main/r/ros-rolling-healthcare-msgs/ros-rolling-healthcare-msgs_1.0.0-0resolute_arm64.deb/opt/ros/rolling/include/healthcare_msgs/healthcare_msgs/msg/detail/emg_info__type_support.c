// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/EMGInfo.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/emg_info__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/emg_info__functions.h"
#include "healthcare_msgs/msg/detail/emg_info__struct.h"
#include "rosidl_buffer/c_helpers.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/device_info.h"
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__rosidl_typesupport_introspection_c.h"
// Member `electrode_placement`
// Member `electrode_type`
// Member `external_devices`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `filters`
#include "healthcare_msgs/msg/filter_base.h"
// Member `filters`
#include "healthcare_msgs/msg/detail/filter_base__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__EMGInfo__init(message_memory);
}

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_fini_function(void * message_memory)
{
  healthcare_msgs__msg__EMGInfo__fini(message_memory);
}

size_t healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__size_function__EMGInfo__electrode_placement(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return member->size;
}

const void * healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__electrode_placement(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return &member->data[index];
}

void * healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__electrode_placement(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return &member->data[index];
}

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__fetch_function__EMGInfo__electrode_placement(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__electrode_placement(untyped_member, index));
  uint8_t * value = (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__assign_function__EMGInfo__electrode_placement(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__electrode_placement(untyped_member, index));
  const uint8_t * value = (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__resize_function__EMGInfo__electrode_placement(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__size_function__EMGInfo__electrode_type(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return member->size;
}

const void * healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__electrode_type(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return &member->data[index];
}

void * healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__electrode_type(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return &member->data[index];
}

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__fetch_function__EMGInfo__electrode_type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__electrode_type(untyped_member, index));
  uint8_t * value = (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__assign_function__EMGInfo__electrode_type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__electrode_type(untyped_member, index));
  const uint8_t * value = (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__resize_function__EMGInfo__electrode_type(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__size_function__EMGInfo__external_devices(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return member->size;
}

const void * healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__external_devices(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return &member->data[index];
}

void * healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__external_devices(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  return &member->data[index];
}

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__fetch_function__EMGInfo__external_devices(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__external_devices(untyped_member, index));
  uint8_t * value = (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__assign_function__EMGInfo__external_devices(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__external_devices(untyped_member, index));
  const uint8_t * value = (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__resize_function__EMGInfo__external_devices(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  if (member->is_rosidl_buffer) {
    rosidl_buffer_uint8_throw_if_not_cpu((const void *)member->data);
  }
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_member_array[7] = {
  {
    "device_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EMGInfo, device_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "units",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EMGInfo, units),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "electrode_placement",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EMGInfo, electrode_placement),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__size_function__EMGInfo__electrode_placement,  // size() function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__electrode_placement,  // get_const(index) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__electrode_placement,  // get(index) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__fetch_function__EMGInfo__electrode_placement,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__assign_function__EMGInfo__electrode_placement,  // assign(index, value) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__resize_function__EMGInfo__electrode_placement,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "electrode_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EMGInfo, electrode_type),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__size_function__EMGInfo__electrode_type,  // size() function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__electrode_type,  // get_const(index) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__electrode_type,  // get(index) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__fetch_function__EMGInfo__electrode_type,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__assign_function__EMGInfo__electrode_type,  // assign(index, value) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__resize_function__EMGInfo__electrode_type,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "external_devices",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EMGInfo, external_devices),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__size_function__EMGInfo__external_devices,  // size() function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_const_function__EMGInfo__external_devices,  // get_const(index) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__get_function__EMGInfo__external_devices,  // get(index) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__fetch_function__EMGInfo__external_devices,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__assign_function__EMGInfo__external_devices,  // assign(index, value) function pointer
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__resize_function__EMGInfo__external_devices,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "signal_mode",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EMGInfo, signal_mode),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "filters",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__EMGInfo, filters),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL,  // resize(index) function pointer
    false  // is_rosidl_buffer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "EMGInfo",  // message name
  7,  // number of fields
  sizeof(healthcare_msgs__msg__EMGInfo),
  false,  // has_any_key_member_
  healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_member_array,  // message members
  healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__EMGInfo__get_type_hash,
  &healthcare_msgs__msg__EMGInfo__get_type_description,
  &healthcare_msgs__msg__EMGInfo__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, EMGInfo)() {
  healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, DeviceInfo)();
  healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, FilterBase)();
  if (!healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__EMGInfo__rosidl_typesupport_introspection_c__EMGInfo_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
