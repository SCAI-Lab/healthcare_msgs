// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BloodVolumePulseInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/blood_volume_pulse_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_MV'.
/**
  * Millivolts
 */
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__UNIT_MV = 1
};

/// Constant 'UNIT_UV'.
/**
  * Microvolts
 */
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__UNIT_UV = 2
};

/// Constant 'UNIT_COUNTS'.
/**
  * Raw ADC counts
 */
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__UNIT_COUNTS = 3
};

/// Constant 'UNIT_CUSTOM'.
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__UNIT_CUSTOM = 255
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Sensor Placement Enum
 */
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_WRIST'.
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__PLACEMENT_WRIST = 1
};

/// Constant 'PLACEMENT_EARLOBE'.
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__PLACEMENT_EARLOBE = 2
};

/// Constant 'PLACEMENT_FINGER'.
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__PLACEMENT_FINGER = 3
};

/// Constant 'PLACEMENT_ARM'.
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__PLACEMENT_ARM = 4
};

/// Constant 'PLACEMENT_FOREHEAD'.
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__PLACEMENT_FOREHEAD = 5
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__BloodVolumePulseInfo__PLACEMENT_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'sensor_placement'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/BloodVolumePulseInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BloodVolumePulseInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  uint8_t unit;
  rosidl_runtime_c__uint8__Sequence sensor_placement;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__BloodVolumePulseInfo;

// Struct for a sequence of healthcare_msgs__msg__BloodVolumePulseInfo.
typedef struct healthcare_msgs__msg__BloodVolumePulseInfo__Sequence
{
  healthcare_msgs__msg__BloodVolumePulseInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BloodVolumePulseInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE_INFO__STRUCT_H_
