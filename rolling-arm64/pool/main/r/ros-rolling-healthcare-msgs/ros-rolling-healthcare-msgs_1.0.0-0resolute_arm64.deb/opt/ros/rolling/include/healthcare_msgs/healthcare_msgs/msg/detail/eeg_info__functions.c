// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/eeg_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__functions.h"
// Member `selected_preprocessing`
// Member `bipolar_active_sites`
// Member `bipolar_reference_sites`
// Member `reference_sites`
// Member `placement_method`
// Member `electrode_sites`
// Member `electrode_physical_type`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `filters`
#include "healthcare_msgs/msg/detail/filter_base__functions.h"

bool
healthcare_msgs__msg__EEGInfo__init(healthcare_msgs__msg__EEGInfo * msg)
{
  if (!msg) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__init(&msg->device_info)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // channel_size
  // units
  // selected_preprocessing
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->selected_preprocessing, 0)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // montage_type
  // bipolar_active_sites
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->bipolar_active_sites, 0)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // bipolar_reference_sites
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->bipolar_reference_sites, 0)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // reference_sites
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->reference_sites, 0)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // placement_method
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->placement_method, 0)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // electrode_sites
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->electrode_sites, 0)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // electrode_physical_type
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->electrode_physical_type, 0)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  // signal_mode
  // filters
  if (!healthcare_msgs__msg__FilterBase__init(&msg->filters)) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__EEGInfo__fini(healthcare_msgs__msg__EEGInfo * msg)
{
  if (!msg) {
    return;
  }
  // device_info
  healthcare_msgs__msg__DeviceInfo__fini(&msg->device_info);
  // channel_size
  // units
  // selected_preprocessing
  rosidl_runtime_c__uint8__Sequence__fini(&msg->selected_preprocessing);
  // montage_type
  // bipolar_active_sites
  rosidl_runtime_c__uint8__Sequence__fini(&msg->bipolar_active_sites);
  // bipolar_reference_sites
  rosidl_runtime_c__uint8__Sequence__fini(&msg->bipolar_reference_sites);
  // reference_sites
  rosidl_runtime_c__uint8__Sequence__fini(&msg->reference_sites);
  // placement_method
  rosidl_runtime_c__uint8__Sequence__fini(&msg->placement_method);
  // electrode_sites
  rosidl_runtime_c__uint8__Sequence__fini(&msg->electrode_sites);
  // electrode_physical_type
  rosidl_runtime_c__uint8__Sequence__fini(&msg->electrode_physical_type);
  // signal_mode
  // filters
  healthcare_msgs__msg__FilterBase__fini(&msg->filters);
}

bool
healthcare_msgs__msg__EEGInfo__are_equal(const healthcare_msgs__msg__EEGInfo * lhs, const healthcare_msgs__msg__EEGInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__are_equal(
      &(lhs->device_info), &(rhs->device_info)))
  {
    return false;
  }
  // channel_size
  if (lhs->channel_size != rhs->channel_size) {
    return false;
  }
  // units
  if (lhs->units != rhs->units) {
    return false;
  }
  // selected_preprocessing
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->selected_preprocessing), &(rhs->selected_preprocessing)))
  {
    return false;
  }
  // montage_type
  if (lhs->montage_type != rhs->montage_type) {
    return false;
  }
  // bipolar_active_sites
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->bipolar_active_sites), &(rhs->bipolar_active_sites)))
  {
    return false;
  }
  // bipolar_reference_sites
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->bipolar_reference_sites), &(rhs->bipolar_reference_sites)))
  {
    return false;
  }
  // reference_sites
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->reference_sites), &(rhs->reference_sites)))
  {
    return false;
  }
  // placement_method
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->placement_method), &(rhs->placement_method)))
  {
    return false;
  }
  // electrode_sites
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->electrode_sites), &(rhs->electrode_sites)))
  {
    return false;
  }
  // electrode_physical_type
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->electrode_physical_type), &(rhs->electrode_physical_type)))
  {
    return false;
  }
  // signal_mode
  if (lhs->signal_mode != rhs->signal_mode) {
    return false;
  }
  // filters
  if (!healthcare_msgs__msg__FilterBase__are_equal(
      &(lhs->filters), &(rhs->filters)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__EEGInfo__copy(
  const healthcare_msgs__msg__EEGInfo * input,
  healthcare_msgs__msg__EEGInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__copy(
      &(input->device_info), &(output->device_info)))
  {
    return false;
  }
  // channel_size
  output->channel_size = input->channel_size;
  // units
  output->units = input->units;
  // selected_preprocessing
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->selected_preprocessing), &(output->selected_preprocessing)))
  {
    return false;
  }
  // montage_type
  output->montage_type = input->montage_type;
  // bipolar_active_sites
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->bipolar_active_sites), &(output->bipolar_active_sites)))
  {
    return false;
  }
  // bipolar_reference_sites
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->bipolar_reference_sites), &(output->bipolar_reference_sites)))
  {
    return false;
  }
  // reference_sites
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->reference_sites), &(output->reference_sites)))
  {
    return false;
  }
  // placement_method
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->placement_method), &(output->placement_method)))
  {
    return false;
  }
  // electrode_sites
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->electrode_sites), &(output->electrode_sites)))
  {
    return false;
  }
  // electrode_physical_type
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->electrode_physical_type), &(output->electrode_physical_type)))
  {
    return false;
  }
  // signal_mode
  output->signal_mode = input->signal_mode;
  // filters
  if (!healthcare_msgs__msg__FilterBase__copy(
      &(input->filters), &(output->filters)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__EEGInfo *
healthcare_msgs__msg__EEGInfo__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__EEGInfo * msg = (healthcare_msgs__msg__EEGInfo *)allocator.allocate(sizeof(healthcare_msgs__msg__EEGInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__EEGInfo));
  bool success = healthcare_msgs__msg__EEGInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__EEGInfo__destroy(healthcare_msgs__msg__EEGInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__EEGInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__EEGInfo__Sequence__init(healthcare_msgs__msg__EEGInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__EEGInfo * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__EEGInfo *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__EEGInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__EEGInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__EEGInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__EEGInfo__Sequence__fini(healthcare_msgs__msg__EEGInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__EEGInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__EEGInfo__Sequence *
healthcare_msgs__msg__EEGInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__EEGInfo__Sequence * array = (healthcare_msgs__msg__EEGInfo__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__EEGInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__EEGInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__EEGInfo__Sequence__destroy(healthcare_msgs__msg__EEGInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__EEGInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__EEGInfo__Sequence__are_equal(const healthcare_msgs__msg__EEGInfo__Sequence * lhs, const healthcare_msgs__msg__EEGInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__EEGInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__EEGInfo__Sequence__copy(
  const healthcare_msgs__msg__EEGInfo__Sequence * input,
  healthcare_msgs__msg__EEGInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__EEGInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__EEGInfo * data =
      (healthcare_msgs__msg__EEGInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__EEGInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__EEGInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__EEGInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
