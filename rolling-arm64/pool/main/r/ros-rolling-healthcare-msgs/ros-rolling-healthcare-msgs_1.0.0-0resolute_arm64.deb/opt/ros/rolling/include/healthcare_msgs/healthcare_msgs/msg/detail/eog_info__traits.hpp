// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/EOGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eog_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/eog_info__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const EOGInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: units
  {
    out << "units: ";
    rosidl_generator_traits::value_to_yaml(msg.units, out);
    out << ", ";
  }

  // member: electrode_placement
  {
    if (msg.electrode_placement.size() == 0) {
      out << "electrode_placement: []";
    } else {
      out << "electrode_placement: [";
      size_t pending_items = msg.electrode_placement.size();
      for (auto item : msg.electrode_placement) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: lead_type
  {
    if (msg.lead_type.size() == 0) {
      out << "lead_type: []";
    } else {
      out << "lead_type: [";
      size_t pending_items = msg.lead_type.size();
      for (auto item : msg.lead_type) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: signal_mode
  {
    out << "signal_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.signal_mode, out);
    out << ", ";
  }

  // member: lightsource
  {
    out << "lightsource: ";
    rosidl_generator_traits::value_to_yaml(msg.lightsource, out);
    out << ", ";
  }

  // member: gazefield_background_light_brightness
  {
    out << "gazefield_background_light_brightness: ";
    rosidl_generator_traits::value_to_yaml(msg.gazefield_background_light_brightness, out);
    out << ", ";
  }

  // member: length_light_dark_phase
  {
    if (msg.length_light_dark_phase.size() == 0) {
      out << "length_light_dark_phase: []";
    } else {
      out << "length_light_dark_phase: [";
      size_t pending_items = msg.length_light_dark_phase.size();
      for (auto item : msg.length_light_dark_phase) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: filters
  {
    out << "filters: ";
    to_flow_style_yaml(msg.filters, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EOGInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: units
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "units: ";
    rosidl_generator_traits::value_to_yaml(msg.units, out);
    out << "\n";
  }

  // member: electrode_placement
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.electrode_placement.size() == 0) {
      out << "electrode_placement: []\n";
    } else {
      out << "electrode_placement:\n";
      for (auto item : msg.electrode_placement) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: lead_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.lead_type.size() == 0) {
      out << "lead_type: []\n";
    } else {
      out << "lead_type:\n";
      for (auto item : msg.lead_type) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: signal_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "signal_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.signal_mode, out);
    out << "\n";
  }

  // member: lightsource
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lightsource: ";
    rosidl_generator_traits::value_to_yaml(msg.lightsource, out);
    out << "\n";
  }

  // member: gazefield_background_light_brightness
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gazefield_background_light_brightness: ";
    rosidl_generator_traits::value_to_yaml(msg.gazefield_background_light_brightness, out);
    out << "\n";
  }

  // member: length_light_dark_phase
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.length_light_dark_phase.size() == 0) {
      out << "length_light_dark_phase: []\n";
    } else {
      out << "length_light_dark_phase:\n";
      for (auto item : msg.length_light_dark_phase) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: filters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filters:\n";
    to_block_style_yaml(msg.filters, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EOGInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::EOGInfo>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).device_info,
    std::forward<T>(msg).units,
    std::forward<T>(msg).electrode_placement,
    std::forward<T>(msg).lead_type,
    std::forward<T>(msg).signal_mode,
    std::forward<T>(msg).lightsource,
    std::forward<T>(msg).gazefield_background_light_brightness,
    std::forward<T>(msg).length_light_dark_phase,
    std::forward<T>(msg).filters);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::EOGInfo>()
{
  return "healthcare_msgs::msg::EOGInfo";
}

template<>
constexpr const char * name<healthcare_msgs::msg::EOGInfo>()
{
  return "healthcare_msgs/msg/EOGInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::EOGInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::EOGInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::EOGInfo>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::EOGInfo>
{
  static constexpr std::size_t member_count = 9;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "device_info",
    "units",
    "electrode_placement",
    "lead_type",
    "signal_mode",
    "lightsource",
    "gazefield_background_light_brightness",
    "length_light_dark_phase",
    "filters",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__TRAITS_HPP_
