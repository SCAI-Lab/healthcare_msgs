// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BRAIN_DECODING_ERP_INFO_HPP_
#define HEALTHCARE_MSGS__MSG__BRAIN_DECODING_ERP_INFO_HPP_

#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__struct.hpp"  // IWYU pragma: export
#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__builder.hpp"    // IWYU pragma: export
#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__traits.hpp"    // IWYU pragma: export
#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__type_support.hpp"    // IWYU pragma: export

#endif  // HEALTHCARE_MSGS__MSG__BRAIN_DECODING_ERP_INFO_HPP_
