// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BrainDecodingERPInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_erp_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'ERP_FEATURE_AMPLITUDE'.
/**
  * ERP-specific features (expands EEG_FEATURE_ENUM)
 */
enum
{
  healthcare_msgs__msg__BrainDecodingERPInfo__ERP_FEATURE_AMPLITUDE = 70
};

/// Constant 'ERP_FEATURE_LATENCY'.
enum
{
  healthcare_msgs__msg__BrainDecodingERPInfo__ERP_FEATURE_LATENCY = 71
};

/// Constant 'ERP_FEATURE_PEAK_TO_PEAK_TIME'.
/**
  * e.g., P1 to N1 difference
 */
enum
{
  healthcare_msgs__msg__BrainDecodingERPInfo__ERP_FEATURE_PEAK_TO_PEAK_TIME = 72
};

/// Constant 'ERP_FEATURE_PHASE_LOCKING_VALUE'.
/**
  * Trial-to-trial consistency
 */
enum
{
  healthcare_msgs__msg__BrainDecodingERPInfo__ERP_FEATURE_PHASE_LOCKING_VALUE = 73
};

/// Constant 'ERP_FEATURE_AUC'.
/**
  * Area under curve for certain output
 */
enum
{
  healthcare_msgs__msg__BrainDecodingERPInfo__ERP_FEATURE_AUC = 74
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.h"
// Member 'erp_features'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'comments'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/BrainDecodingERPInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BrainDecodingERPInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  healthcare_msgs__msg__BrainDecodingGeneralInfo brain_decoding_general_info;
  rosidl_runtime_c__uint8__Sequence erp_features;
  rosidl_runtime_c__String comments;
} healthcare_msgs__msg__BrainDecodingERPInfo;

// Struct for a sequence of healthcare_msgs__msg__BrainDecodingERPInfo.
typedef struct healthcare_msgs__msg__BrainDecodingERPInfo__Sequence
{
  healthcare_msgs__msg__BrainDecodingERPInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BrainDecodingERPInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__STRUCT_H_
