// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/ECG.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/ecg.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ECG__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__ECG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"
// Member 'ecg'
// Member 'signal_quality'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/ECG in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__ECG
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint8_t channel_size;
  uint16_t sample_size;
  /// Raw or filtered ECG values [channel]x[sample]
  rosidl_runtime_c__float__Sequence ecg;
  /// From 0 (poor) to 1 (excellent)
  rosidl_runtime_c__float__Sequence signal_quality;
} healthcare_msgs__msg__ECG;

// Struct for a sequence of healthcare_msgs__msg__ECG.
typedef struct healthcare_msgs__msg__ECG__Sequence
{
  healthcare_msgs__msg__ECG * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__ECG__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ECG__STRUCT_H_
