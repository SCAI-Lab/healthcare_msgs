// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/ECGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/ecg_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_buffer/buffer.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__ECGInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__ECGInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ECGInfo_
{
  using Type = ECGInfo_<ContainerAllocator>;

  explicit ECGInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    filters(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
    }
  }

  explicit ECGInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    filters(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _units_type =
    uint8_t;
  _units_type units;
  using _electrode_placement_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_placement_type electrode_placement;
  using _lead_type_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _lead_type_type lead_type;
  using _filters_type =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator>;
  _filters_type filters;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__units(
    const uint8_t & _arg)
  {
    this->units = _arg;
    return *this;
  }
  Type & set__electrode_placement(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_placement = _arg;
    return *this;
  }
  Type & set__lead_type(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->lead_type = _arg;
    return *this;
  }
  Type & set__filters(
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> & _arg)
  {
    this->filters = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t UNIT_UNKNOWN =
    0u;
  static constexpr uint8_t UNIT_MV =
    1u;
  static constexpr uint8_t UNIT_UV =
    2u;
  static constexpr uint8_t UNIT_COUNTS =
    3u;
  static constexpr uint8_t PLACEMENT_UNKNOWN =
    0u;
  static constexpr uint8_t PLACEMENT_LIMB =
    1u;
  static constexpr uint8_t PLACEMENT_WRIST_ANKLE =
    2u;
  static constexpr uint8_t PLACEMENT_CHEST =
    3u;
  static constexpr uint8_t PLACEMENT_TORSO =
    4u;
  static constexpr uint8_t PLACEMENT_ABDOMEN =
    5u;
  static constexpr uint8_t PLACEMENT_BACK =
    6u;
  static constexpr uint8_t PLACEMENT_EAR =
    7u;
  static constexpr uint8_t PLACEMENT_NECK =
    8u;
  static constexpr uint8_t PLACEMENT_LEFT_ARM =
    9u;
  static constexpr uint8_t PLACEMENT_RIGHT_ARM =
    10u;
  static constexpr uint8_t PLACEMENT_LEFT_LEG =
    11u;
  static constexpr uint8_t PLACEMENT_RIGHT_LEG =
    12u;
  static constexpr uint8_t PLACEMENT_CUSTOM =
    255u;
  static constexpr uint8_t LEAD_UNKNOWN =
    0u;
  static constexpr uint8_t LEAD_I =
    1u;
  static constexpr uint8_t LEAD_II =
    2u;
  static constexpr uint8_t LEAD_III =
    3u;
  static constexpr uint8_t LEAD_AVR =
    4u;
  static constexpr uint8_t LEAD_AVL =
    5u;
  static constexpr uint8_t LEAD_AVF =
    6u;
  static constexpr uint8_t LEAD_V1 =
    7u;
  static constexpr uint8_t LEAD_V2 =
    8u;
  static constexpr uint8_t LEAD_V3 =
    9u;
  static constexpr uint8_t LEAD_V4 =
    10u;
  static constexpr uint8_t LEAD_V5 =
    11u;
  static constexpr uint8_t LEAD_V6 =
    12u;
  static constexpr uint8_t LEAD_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::ECGInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::ECGInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ECGInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ECGInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__ECGInfo
    std::shared_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__ECGInfo
    std::shared_ptr<healthcare_msgs::msg::ECGInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ECGInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->units != other.units) {
      return false;
    }
    if (this->electrode_placement != other.electrode_placement) {
      return false;
    }
    if (this->lead_type != other.lead_type) {
      return false;
    }
    if (this->filters != other.filters) {
      return false;
    }
    return true;
  }
  bool operator!=(const ECGInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ECGInfo_

// alias to use template instance with default allocator
using ECGInfo =
  healthcare_msgs::msg::ECGInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::UNIT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::UNIT_MV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::UNIT_UV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::UNIT_COUNTS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_LIMB;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_WRIST_ANKLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_CHEST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_TORSO;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_ABDOMEN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_BACK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_EAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_NECK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_LEFT_ARM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_RIGHT_ARM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_LEFT_LEG;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_RIGHT_LEG;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::PLACEMENT_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_I;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_II;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_III;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_AVR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_AVL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_AVF;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_V1;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_V2;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_V3;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_V4;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_V5;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_V6;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ECGInfo_<ContainerAllocator>::LEAD_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__STRUCT_HPP_
