// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EMG.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/emg.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EMG__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EMG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/emg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EMG_signal_quality
{
public:
  explicit Init_EMG_signal_quality(::healthcare_msgs::msg::EMG & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EMG signal_quality(::healthcare_msgs::msg::EMG::_signal_quality_type arg)
  {
    msg_.signal_quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EMG msg_;
};

class Init_EMG_emg
{
public:
  explicit Init_EMG_emg(::healthcare_msgs::msg::EMG & msg)
  : msg_(msg)
  {}
  Init_EMG_signal_quality emg(::healthcare_msgs::msg::EMG::_emg_type arg)
  {
    msg_.emg = std::move(arg);
    return Init_EMG_signal_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::EMG msg_;
};

class Init_EMG_sample_size
{
public:
  explicit Init_EMG_sample_size(::healthcare_msgs::msg::EMG & msg)
  : msg_(msg)
  {}
  Init_EMG_emg sample_size(::healthcare_msgs::msg::EMG::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_EMG_emg(msg_);
  }

private:
  ::healthcare_msgs::msg::EMG msg_;
};

class Init_EMG_channel_size
{
public:
  explicit Init_EMG_channel_size(::healthcare_msgs::msg::EMG & msg)
  : msg_(msg)
  {}
  Init_EMG_sample_size channel_size(::healthcare_msgs::msg::EMG::_channel_size_type arg)
  {
    msg_.channel_size = std::move(arg);
    return Init_EMG_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::EMG msg_;
};

class Init_EMG_session_id
{
public:
  explicit Init_EMG_session_id(::healthcare_msgs::msg::EMG & msg)
  : msg_(msg)
  {}
  Init_EMG_channel_size session_id(::healthcare_msgs::msg::EMG::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_EMG_channel_size(msg_);
  }

private:
  ::healthcare_msgs::msg::EMG msg_;
};

class Init_EMG_header
{
public:
  Init_EMG_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EMG_session_id header(::healthcare_msgs::msg::EMG::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_EMG_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::EMG msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EMG>()
{
  return healthcare_msgs::msg::builder::Init_EMG_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EMG__BUILDER_HPP_
