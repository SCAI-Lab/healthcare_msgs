// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/ButterWorthFilter.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/butter_worth_filter.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/butter_worth_filter__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ButterWorthFilter & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: cutoff_frequency
  {
    out << "cutoff_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.cutoff_frequency, out);
    out << ", ";
  }

  // member: order
  {
    out << "order: ";
    rosidl_generator_traits::value_to_yaml(msg.order, out);
    out << ", ";
  }

  // member: sampling_rate
  {
    out << "sampling_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.sampling_rate, out);
    out << ", ";
  }

  // member: zero_phase
  {
    out << "zero_phase: ";
    rosidl_generator_traits::value_to_yaml(msg.zero_phase, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ButterWorthFilter & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: cutoff_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cutoff_frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.cutoff_frequency, out);
    out << "\n";
  }

  // member: order
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "order: ";
    rosidl_generator_traits::value_to_yaml(msg.order, out);
    out << "\n";
  }

  // member: sampling_rate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sampling_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.sampling_rate, out);
    out << "\n";
  }

  // member: zero_phase
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "zero_phase: ";
    rosidl_generator_traits::value_to_yaml(msg.zero_phase, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ButterWorthFilter & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::ButterWorthFilter>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).header,
    std::forward<T>(msg).cutoff_frequency,
    std::forward<T>(msg).order,
    std::forward<T>(msg).sampling_rate,
    std::forward<T>(msg).zero_phase);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::ButterWorthFilter>()
{
  return "healthcare_msgs::msg::ButterWorthFilter";
}

template<>
constexpr const char * name<healthcare_msgs::msg::ButterWorthFilter>()
{
  return "healthcare_msgs/msg/ButterWorthFilter";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::ButterWorthFilter>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::ButterWorthFilter>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<healthcare_msgs::msg::ButterWorthFilter>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::ButterWorthFilter>
{
  static constexpr std::size_t member_count = 5;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "header",
    "cutoff_frequency",
    "order",
    "sampling_rate",
    "zero_phase",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__TRAITS_HPP_
