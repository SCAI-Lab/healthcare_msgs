// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BLOOD_VOLUME_PULSE_HPP_
#define HEALTHCARE_MSGS__MSG__BLOOD_VOLUME_PULSE_HPP_

#include "healthcare_msgs/msg/detail/blood_volume_pulse__struct.hpp"  // IWYU pragma: export
#include "healthcare_msgs/msg/detail/blood_volume_pulse__builder.hpp"    // IWYU pragma: export
#include "healthcare_msgs/msg/detail/blood_volume_pulse__traits.hpp"    // IWYU pragma: export
#include "healthcare_msgs/msg/detail/blood_volume_pulse__type_support.hpp"    // IWYU pragma: export

#endif  // HEALTHCARE_MSGS__MSG__BLOOD_VOLUME_PULSE_HPP_
