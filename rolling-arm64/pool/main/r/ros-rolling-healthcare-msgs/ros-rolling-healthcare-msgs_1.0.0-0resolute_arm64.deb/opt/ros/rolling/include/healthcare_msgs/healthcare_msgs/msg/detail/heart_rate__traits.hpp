// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/HeartRate.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/heart_rate.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/heart_rate__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const HeartRate & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: session_id
  {
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << ", ";
  }

  // member: sample_size
  {
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << ", ";
  }

  // member: heart_rate
  {
    if (msg.heart_rate.size() == 0) {
      out << "heart_rate: []";
    } else {
      out << "heart_rate: [";
      size_t pending_items = msg.heart_rate.size();
      for (auto item : msg.heart_rate) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: quality
  {
    if (msg.quality.size() == 0) {
      out << "quality: []";
    } else {
      out << "quality: [";
      size_t pending_items = msg.quality.size();
      for (auto item : msg.quality) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HeartRate & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: session_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << "\n";
  }

  // member: sample_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << "\n";
  }

  // member: heart_rate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.heart_rate.size() == 0) {
      out << "heart_rate: []\n";
    } else {
      out << "heart_rate:\n";
      for (auto item : msg.heart_rate) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: quality
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.quality.size() == 0) {
      out << "quality: []\n";
    } else {
      out << "quality:\n";
      for (auto item : msg.quality) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HeartRate & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::HeartRate>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).header,
    std::forward<T>(msg).session_id,
    std::forward<T>(msg).sample_size,
    std::forward<T>(msg).heart_rate,
    std::forward<T>(msg).quality);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::HeartRate>()
{
  return "healthcare_msgs::msg::HeartRate";
}

template<>
constexpr const char * name<healthcare_msgs::msg::HeartRate>()
{
  return "healthcare_msgs/msg/HeartRate";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::HeartRate>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::HeartRate>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::HeartRate>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::HeartRate>
{
  static constexpr std::size_t member_count = 5;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "header",
    "session_id",
    "sample_size",
    "heart_rate",
    "quality",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__TRAITS_HPP_
