// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EDA.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eda.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"
// Member 'scl'
// Member 'scr'
// Member 'eda'
// Member 'signal_quality'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/EDA in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EDA
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint16_t sample_size;
  /// Keep empty if the wearables does not provide one of these.
  /// Skin Conductance Level (tonic)
  rosidl_runtime_c__float__Sequence scl;
  /// Skin Conductance Response (phasic)
  rosidl_runtime_c__float__Sequence scr;
  /// Sum of signals (scl + scr)
  rosidl_runtime_c__float__Sequence eda;
  /// From 0 (poor) to 1 (excellent)
  rosidl_runtime_c__float__Sequence signal_quality;
} healthcare_msgs__msg__EDA;

// Struct for a sequence of healthcare_msgs__msg__EDA.
typedef struct healthcare_msgs__msg__EDA__Sequence
{
  healthcare_msgs__msg__EDA * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EDA__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA__STRUCT_H_
