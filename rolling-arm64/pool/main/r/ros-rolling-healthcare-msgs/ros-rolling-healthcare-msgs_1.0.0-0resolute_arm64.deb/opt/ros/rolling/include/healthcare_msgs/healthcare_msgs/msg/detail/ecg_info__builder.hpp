// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/ECGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/ecg_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/ecg_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_ECGInfo_filters
{
public:
  explicit Init_ECGInfo_filters(::healthcare_msgs::msg::ECGInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::ECGInfo filters(::healthcare_msgs::msg::ECGInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::ECGInfo msg_;
};

class Init_ECGInfo_lead_type
{
public:
  explicit Init_ECGInfo_lead_type(::healthcare_msgs::msg::ECGInfo & msg)
  : msg_(msg)
  {}
  Init_ECGInfo_filters lead_type(::healthcare_msgs::msg::ECGInfo::_lead_type_type arg)
  {
    msg_.lead_type = std::move(arg);
    return Init_ECGInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::ECGInfo msg_;
};

class Init_ECGInfo_electrode_placement
{
public:
  explicit Init_ECGInfo_electrode_placement(::healthcare_msgs::msg::ECGInfo & msg)
  : msg_(msg)
  {}
  Init_ECGInfo_lead_type electrode_placement(::healthcare_msgs::msg::ECGInfo::_electrode_placement_type arg)
  {
    msg_.electrode_placement = std::move(arg);
    return Init_ECGInfo_lead_type(msg_);
  }

private:
  ::healthcare_msgs::msg::ECGInfo msg_;
};

class Init_ECGInfo_units
{
public:
  explicit Init_ECGInfo_units(::healthcare_msgs::msg::ECGInfo & msg)
  : msg_(msg)
  {}
  Init_ECGInfo_electrode_placement units(::healthcare_msgs::msg::ECGInfo::_units_type arg)
  {
    msg_.units = std::move(arg);
    return Init_ECGInfo_electrode_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::ECGInfo msg_;
};

class Init_ECGInfo_device_info
{
public:
  Init_ECGInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ECGInfo_units device_info(::healthcare_msgs::msg::ECGInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_ECGInfo_units(msg_);
  }

private:
  ::healthcare_msgs::msg::ECGInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::ECGInfo>()
{
  return healthcare_msgs::msg::builder::Init_ECGInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__BUILDER_HPP_
