// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "healthcare_msgs/msg/detail/eeg_info__functions.h"
#include "healthcare_msgs/msg/detail/eeg_info__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"
#include "rosidl_buffer/buffer.hpp"

namespace healthcare_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void EEGInfo_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) healthcare_msgs::msg::EEGInfo(_init);
}

void EEGInfo_fini_function(void * message_memory)
{
  auto typed_message = static_cast<healthcare_msgs::msg::EEGInfo *>(message_memory);
  typed_message->~EEGInfo();
}

size_t size_function__EEGInfo__selected_preprocessing(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EEGInfo__selected_preprocessing(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void * get_function__EEGInfo__selected_preprocessing(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void fetch_function__EEGInfo__selected_preprocessing(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__EEGInfo__selected_preprocessing(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__EEGInfo__selected_preprocessing(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__EEGInfo__selected_preprocessing(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__EEGInfo__selected_preprocessing(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member->throw_if_not_cpu_backend();
  member->resize(size);
}

size_t size_function__EEGInfo__bipolar_active_sites(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EEGInfo__bipolar_active_sites(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void * get_function__EEGInfo__bipolar_active_sites(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void fetch_function__EEGInfo__bipolar_active_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__EEGInfo__bipolar_active_sites(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__EEGInfo__bipolar_active_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__EEGInfo__bipolar_active_sites(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__EEGInfo__bipolar_active_sites(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member->throw_if_not_cpu_backend();
  member->resize(size);
}

size_t size_function__EEGInfo__bipolar_reference_sites(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EEGInfo__bipolar_reference_sites(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void * get_function__EEGInfo__bipolar_reference_sites(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void fetch_function__EEGInfo__bipolar_reference_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__EEGInfo__bipolar_reference_sites(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__EEGInfo__bipolar_reference_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__EEGInfo__bipolar_reference_sites(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__EEGInfo__bipolar_reference_sites(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member->throw_if_not_cpu_backend();
  member->resize(size);
}

size_t size_function__EEGInfo__reference_sites(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EEGInfo__reference_sites(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void * get_function__EEGInfo__reference_sites(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void fetch_function__EEGInfo__reference_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__EEGInfo__reference_sites(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__EEGInfo__reference_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__EEGInfo__reference_sites(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__EEGInfo__reference_sites(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member->throw_if_not_cpu_backend();
  member->resize(size);
}

size_t size_function__EEGInfo__placement_method(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EEGInfo__placement_method(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void * get_function__EEGInfo__placement_method(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void fetch_function__EEGInfo__placement_method(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__EEGInfo__placement_method(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__EEGInfo__placement_method(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__EEGInfo__placement_method(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__EEGInfo__placement_method(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member->throw_if_not_cpu_backend();
  member->resize(size);
}

size_t size_function__EEGInfo__electrode_sites(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EEGInfo__electrode_sites(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void * get_function__EEGInfo__electrode_sites(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void fetch_function__EEGInfo__electrode_sites(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__EEGInfo__electrode_sites(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__EEGInfo__electrode_sites(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__EEGInfo__electrode_sites(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__EEGInfo__electrode_sites(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member->throw_if_not_cpu_backend();
  member->resize(size);
}

size_t size_function__EEGInfo__electrode_physical_type(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EEGInfo__electrode_physical_type(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void * get_function__EEGInfo__electrode_physical_type(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member.throw_if_not_cpu_backend();
  return &member[index];
}

void fetch_function__EEGInfo__electrode_physical_type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__EEGInfo__electrode_physical_type(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__EEGInfo__electrode_physical_type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__EEGInfo__electrode_physical_type(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

void resize_function__EEGInfo__electrode_physical_type(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<rosidl::Buffer<uint8_t> *>(untyped_member);
  member->throw_if_not_cpu_backend();
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember EEGInfo_message_member_array[13] = {
  {
    "device_info",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<healthcare_msgs::msg::DeviceInfo>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, device_info),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "channel_size",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, channel_size),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "units",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, units),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "selected_preprocessing",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, selected_preprocessing),  // bytes offset in struct
    nullptr,  // default value
    size_function__EEGInfo__selected_preprocessing,  // size() function pointer
    get_const_function__EEGInfo__selected_preprocessing,  // get_const(index) function pointer
    get_function__EEGInfo__selected_preprocessing,  // get(index) function pointer
    fetch_function__EEGInfo__selected_preprocessing,  // fetch(index, &value) function pointer
    assign_function__EEGInfo__selected_preprocessing,  // assign(index, value) function pointer
    resize_function__EEGInfo__selected_preprocessing,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "montage_type",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, montage_type),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "bipolar_active_sites",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, bipolar_active_sites),  // bytes offset in struct
    nullptr,  // default value
    size_function__EEGInfo__bipolar_active_sites,  // size() function pointer
    get_const_function__EEGInfo__bipolar_active_sites,  // get_const(index) function pointer
    get_function__EEGInfo__bipolar_active_sites,  // get(index) function pointer
    fetch_function__EEGInfo__bipolar_active_sites,  // fetch(index, &value) function pointer
    assign_function__EEGInfo__bipolar_active_sites,  // assign(index, value) function pointer
    resize_function__EEGInfo__bipolar_active_sites,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "bipolar_reference_sites",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, bipolar_reference_sites),  // bytes offset in struct
    nullptr,  // default value
    size_function__EEGInfo__bipolar_reference_sites,  // size() function pointer
    get_const_function__EEGInfo__bipolar_reference_sites,  // get_const(index) function pointer
    get_function__EEGInfo__bipolar_reference_sites,  // get(index) function pointer
    fetch_function__EEGInfo__bipolar_reference_sites,  // fetch(index, &value) function pointer
    assign_function__EEGInfo__bipolar_reference_sites,  // assign(index, value) function pointer
    resize_function__EEGInfo__bipolar_reference_sites,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "reference_sites",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, reference_sites),  // bytes offset in struct
    nullptr,  // default value
    size_function__EEGInfo__reference_sites,  // size() function pointer
    get_const_function__EEGInfo__reference_sites,  // get_const(index) function pointer
    get_function__EEGInfo__reference_sites,  // get(index) function pointer
    fetch_function__EEGInfo__reference_sites,  // fetch(index, &value) function pointer
    assign_function__EEGInfo__reference_sites,  // assign(index, value) function pointer
    resize_function__EEGInfo__reference_sites,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "placement_method",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, placement_method),  // bytes offset in struct
    nullptr,  // default value
    size_function__EEGInfo__placement_method,  // size() function pointer
    get_const_function__EEGInfo__placement_method,  // get_const(index) function pointer
    get_function__EEGInfo__placement_method,  // get(index) function pointer
    fetch_function__EEGInfo__placement_method,  // fetch(index, &value) function pointer
    assign_function__EEGInfo__placement_method,  // assign(index, value) function pointer
    resize_function__EEGInfo__placement_method,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "electrode_sites",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, electrode_sites),  // bytes offset in struct
    nullptr,  // default value
    size_function__EEGInfo__electrode_sites,  // size() function pointer
    get_const_function__EEGInfo__electrode_sites,  // get_const(index) function pointer
    get_function__EEGInfo__electrode_sites,  // get(index) function pointer
    fetch_function__EEGInfo__electrode_sites,  // fetch(index, &value) function pointer
    assign_function__EEGInfo__electrode_sites,  // assign(index, value) function pointer
    resize_function__EEGInfo__electrode_sites,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "electrode_physical_type",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, electrode_physical_type),  // bytes offset in struct
    nullptr,  // default value
    size_function__EEGInfo__electrode_physical_type,  // size() function pointer
    get_const_function__EEGInfo__electrode_physical_type,  // get_const(index) function pointer
    get_function__EEGInfo__electrode_physical_type,  // get(index) function pointer
    fetch_function__EEGInfo__electrode_physical_type,  // fetch(index, &value) function pointer
    assign_function__EEGInfo__electrode_physical_type,  // assign(index, value) function pointer
    resize_function__EEGInfo__electrode_physical_type,  // resize(index) function pointer
    true  // is_rosidl_buffer
  },
  {
    "signal_mode",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, signal_mode),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "filters",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<healthcare_msgs::msg::FilterBase>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::EEGInfo, filters),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers EEGInfo_message_members = {
  "healthcare_msgs::msg",  // message namespace
  "EEGInfo",  // message name
  13,  // number of fields
  sizeof(healthcare_msgs::msg::EEGInfo),
  false,  // has_any_key_member_
  EEGInfo_message_member_array,  // message members
  EEGInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  EEGInfo_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t EEGInfo_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &EEGInfo_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__EEGInfo__get_type_hash,
  &healthcare_msgs__msg__EEGInfo__get_type_description,
  &healthcare_msgs__msg__EEGInfo__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace healthcare_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<healthcare_msgs::msg::EEGInfo>()
{
  return &::healthcare_msgs::msg::rosidl_typesupport_introspection_cpp::EEGInfo_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, healthcare_msgs, msg, EEGInfo)() {
  return &::healthcare_msgs::msg::rosidl_typesupport_introspection_cpp::EEGInfo_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
