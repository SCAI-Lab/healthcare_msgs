// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/HeartRate.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/heart_rate.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/heart_rate__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_HeartRate_quality
{
public:
  explicit Init_HeartRate_quality(::healthcare_msgs::msg::HeartRate & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::HeartRate quality(::healthcare_msgs::msg::HeartRate::_quality_type arg)
  {
    msg_.quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRate msg_;
};

class Init_HeartRate_heart_rate
{
public:
  explicit Init_HeartRate_heart_rate(::healthcare_msgs::msg::HeartRate & msg)
  : msg_(msg)
  {}
  Init_HeartRate_quality heart_rate(::healthcare_msgs::msg::HeartRate::_heart_rate_type arg)
  {
    msg_.heart_rate = std::move(arg);
    return Init_HeartRate_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRate msg_;
};

class Init_HeartRate_sample_size
{
public:
  explicit Init_HeartRate_sample_size(::healthcare_msgs::msg::HeartRate & msg)
  : msg_(msg)
  {}
  Init_HeartRate_heart_rate sample_size(::healthcare_msgs::msg::HeartRate::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_HeartRate_heart_rate(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRate msg_;
};

class Init_HeartRate_session_id
{
public:
  explicit Init_HeartRate_session_id(::healthcare_msgs::msg::HeartRate & msg)
  : msg_(msg)
  {}
  Init_HeartRate_sample_size session_id(::healthcare_msgs::msg::HeartRate::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_HeartRate_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRate msg_;
};

class Init_HeartRate_header
{
public:
  Init_HeartRate_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HeartRate_session_id header(::healthcare_msgs::msg::HeartRate::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_HeartRate_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRate msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::HeartRate>()
{
  return healthcare_msgs::msg::builder::Init_HeartRate_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE__BUILDER_HPP_
