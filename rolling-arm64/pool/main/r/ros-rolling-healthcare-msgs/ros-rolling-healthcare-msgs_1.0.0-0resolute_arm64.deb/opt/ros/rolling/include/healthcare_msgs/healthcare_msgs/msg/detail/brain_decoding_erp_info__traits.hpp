// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingERPInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_erp_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BrainDecodingERPInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: brain_decoding_general_info
  {
    out << "brain_decoding_general_info: ";
    to_flow_style_yaml(msg.brain_decoding_general_info, out);
    out << ", ";
  }

  // member: erp_features
  {
    if (msg.erp_features.size() == 0) {
      out << "erp_features: []";
    } else {
      out << "erp_features: [";
      size_t pending_items = msg.erp_features.size();
      for (auto item : msg.erp_features) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: comments
  {
    out << "comments: ";
    rosidl_generator_traits::value_to_yaml(msg.comments, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BrainDecodingERPInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: brain_decoding_general_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brain_decoding_general_info:\n";
    to_block_style_yaml(msg.brain_decoding_general_info, out, indentation + 2);
  }

  // member: erp_features
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.erp_features.size() == 0) {
      out << "erp_features: []\n";
    } else {
      out << "erp_features:\n";
      for (auto item : msg.erp_features) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: comments
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comments: ";
    rosidl_generator_traits::value_to_yaml(msg.comments, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BrainDecodingERPInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::BrainDecodingERPInfo>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).device_info,
    std::forward<T>(msg).brain_decoding_general_info,
    std::forward<T>(msg).erp_features,
    std::forward<T>(msg).comments);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::BrainDecodingERPInfo>()
{
  return "healthcare_msgs::msg::BrainDecodingERPInfo";
}

template<>
constexpr const char * name<healthcare_msgs::msg::BrainDecodingERPInfo>()
{
  return "healthcare_msgs/msg/BrainDecodingERPInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::BrainDecodingERPInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::BrainDecodingERPInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::BrainDecodingERPInfo>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::BrainDecodingERPInfo>
{
  static constexpr std::size_t member_count = 4;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "device_info",
    "brain_decoding_general_info",
    "erp_features",
    "comments",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__TRAITS_HPP_
