// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/BrainDecodingERPInfo.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__functions.h"
// Member `brain_decoding_general_info`
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__functions.h"
// Member `erp_features`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `comments`
#include "rosidl_runtime_c/string_functions.h"

bool
healthcare_msgs__msg__BrainDecodingERPInfo__init(healthcare_msgs__msg__BrainDecodingERPInfo * msg)
{
  if (!msg) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__init(&msg->device_info)) {
    healthcare_msgs__msg__BrainDecodingERPInfo__fini(msg);
    return false;
  }
  // brain_decoding_general_info
  if (!healthcare_msgs__msg__BrainDecodingGeneralInfo__init(&msg->brain_decoding_general_info)) {
    healthcare_msgs__msg__BrainDecodingERPInfo__fini(msg);
    return false;
  }
  // erp_features
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->erp_features, 0)) {
    healthcare_msgs__msg__BrainDecodingERPInfo__fini(msg);
    return false;
  }
  // comments
  if (!rosidl_runtime_c__String__init(&msg->comments)) {
    healthcare_msgs__msg__BrainDecodingERPInfo__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__BrainDecodingERPInfo__fini(healthcare_msgs__msg__BrainDecodingERPInfo * msg)
{
  if (!msg) {
    return;
  }
  // device_info
  healthcare_msgs__msg__DeviceInfo__fini(&msg->device_info);
  // brain_decoding_general_info
  healthcare_msgs__msg__BrainDecodingGeneralInfo__fini(&msg->brain_decoding_general_info);
  // erp_features
  rosidl_runtime_c__uint8__Sequence__fini(&msg->erp_features);
  // comments
  rosidl_runtime_c__String__fini(&msg->comments);
}

bool
healthcare_msgs__msg__BrainDecodingERPInfo__are_equal(const healthcare_msgs__msg__BrainDecodingERPInfo * lhs, const healthcare_msgs__msg__BrainDecodingERPInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__are_equal(
      &(lhs->device_info), &(rhs->device_info)))
  {
    return false;
  }
  // brain_decoding_general_info
  if (!healthcare_msgs__msg__BrainDecodingGeneralInfo__are_equal(
      &(lhs->brain_decoding_general_info), &(rhs->brain_decoding_general_info)))
  {
    return false;
  }
  // erp_features
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->erp_features), &(rhs->erp_features)))
  {
    return false;
  }
  // comments
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->comments), &(rhs->comments)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__BrainDecodingERPInfo__copy(
  const healthcare_msgs__msg__BrainDecodingERPInfo * input,
  healthcare_msgs__msg__BrainDecodingERPInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__copy(
      &(input->device_info), &(output->device_info)))
  {
    return false;
  }
  // brain_decoding_general_info
  if (!healthcare_msgs__msg__BrainDecodingGeneralInfo__copy(
      &(input->brain_decoding_general_info), &(output->brain_decoding_general_info)))
  {
    return false;
  }
  // erp_features
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->erp_features), &(output->erp_features)))
  {
    return false;
  }
  // comments
  if (!rosidl_runtime_c__String__copy(
      &(input->comments), &(output->comments)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__BrainDecodingERPInfo *
healthcare_msgs__msg__BrainDecodingERPInfo__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BrainDecodingERPInfo * msg = (healthcare_msgs__msg__BrainDecodingERPInfo *)allocator.allocate(sizeof(healthcare_msgs__msg__BrainDecodingERPInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__BrainDecodingERPInfo));
  bool success = healthcare_msgs__msg__BrainDecodingERPInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__BrainDecodingERPInfo__destroy(healthcare_msgs__msg__BrainDecodingERPInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__BrainDecodingERPInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__init(healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BrainDecodingERPInfo * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__BrainDecodingERPInfo *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__BrainDecodingERPInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__BrainDecodingERPInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__BrainDecodingERPInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__fini(healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__BrainDecodingERPInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__BrainDecodingERPInfo__Sequence *
healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * array = (healthcare_msgs__msg__BrainDecodingERPInfo__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__BrainDecodingERPInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__destroy(healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__are_equal(const healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * lhs, const healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__BrainDecodingERPInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__BrainDecodingERPInfo__Sequence__copy(
  const healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * input,
  healthcare_msgs__msg__BrainDecodingERPInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__BrainDecodingERPInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__BrainDecodingERPInfo * data =
      (healthcare_msgs__msg__BrainDecodingERPInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__BrainDecodingERPInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__BrainDecodingERPInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__BrainDecodingERPInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
