// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BrainDecodingGeneralInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_general_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'OUTPUT_METHOD_UNKNOWN'.
/**
  * Output Method Enum
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__OUTPUT_METHOD_UNKNOWN = 0
};

/// Constant 'OUTPUT_METHOD_SINGLE_WINDOW'.
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__OUTPUT_METHOD_SINGLE_WINDOW = 1
};

/// Constant 'OUTPUT_METHOD_MULTIPLE_WINDOW'.
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__OUTPUT_METHOD_MULTIPLE_WINDOW = 2
};

/// Constant 'OUTPUT_METHOD_AVERAGE'.
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__OUTPUT_METHOD_AVERAGE = 3
};

/// Constant 'OUTPUT_METHOD_SAMPLE_WISE'.
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__OUTPUT_METHOD_SAMPLE_WISE = 4
};

/// Constant 'OUTPUT_METHOD_CUSTOM'.
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__OUTPUT_METHOD_CUSTOM = 255
};

/// Constant 'EEG_PREPROC_UNKNOWN'.
/**
  * EEG Preprocessing Enum
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_UNKNOWN = 0
};

/// Constant 'EEG_PREPROC_BANDPASS'.
/**
  * Bandpass filter applied
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_BANDPASS = 1
};

/// Constant 'EEG_PREPROC_NOTCH'.
/**
  * Notch filter (e.g., 50/60 Hz)
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_NOTCH = 2
};

/// Constant 'EEG_PREPROC_ICA'.
/**
  * Independent Component Analysis
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_ICA = 3
};

/// Constant 'EEG_PREPROC_CAR'.
/**
  * Common Average Reference
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_CAR = 4
};

/// Constant 'EEG_PREPROC_ARTEFACT_REJ'.
/**
  * Artifact rejection/interpolation
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_ARTEFACT_REJ = 5
};

/// Constant 'EEG_PREPROC_BASELINE_CORR'.
/**
  * Baseline correction
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_BASELINE_CORR = 6
};

/// Constant 'EEG_PREPROC_DOWNSAMPLE'.
/**
  * Downsampling
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_DOWNSAMPLE = 7
};

/// Constant 'EEG_PREPROC_SEGMENTED'.
/**
  * Epoching / segmentation
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_SEGMENTED = 8
};

/// Constant 'EEG_PREPROC_CUSTOM'.
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_PREPROC_CUSTOM = 255
};

/// Constant 'EEG_FEATURE_UNKNOWN'.
/**
  * EEG Feature Enum
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_UNKNOWN = 0
};

/// Constant 'EEG_FEATURE_FREQUENCY_WELCH'.
/**
  * Frequency Domain
  * Compute power spectral density using Welch's method
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_FREQUENCY_WELCH = 1
};

/// Constant 'EEG_FEATURE_EXTRACT_PSD'.
/**
  * Compute power spectral density (general)
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_EXTRACT_PSD = 2
};

/// Constant 'EEG_FEATURE_MORLET'.
/**
  * Time-frequency features via Morlet wavelets
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_MORLET = 3
};

/// Constant 'EEG_FEATURE_BAND_POWER'.
/**
  * Compute power in standard EEG bands (delta, theta, alpha, beta, gamma)
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_BAND_POWER = 4
};

/// Constant 'EEG_FEATURE_RELATIVE_POWER'.
/**
  * Relative power ratios between bands
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_RELATIVE_POWER = 5
};

/// Constant 'EEG_FEATURE_SPECTRAL_FEATURES'.
/**
  * Frequency-domain metrics (spectral slope, centroid, etc.)
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_SPECTRAL_FEATURES = 6
};

/// Constant 'EEG_FEATURE_PEAK'.
/**
  * Time Domain
  * Extract peak latency and amplitude from EEG
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_PEAK = 10
};

/// Constant 'EEG_FEATURE_HJORTH'.
/**
  * Hjorth parameters: activity, mobility, complexity
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_HJORTH = 11
};

/// Constant 'EEG_FEATURE_ENTROPY'.
/**
  * Complexity
  * Spectral entropy
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_ENTROPY = 20
};

/// Constant 'EEG_FEATURE_SAMPLE_ENTROPY'.
/**
  * Sample entropy (pattern regularity)
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_SAMPLE_ENTROPY = 21
};

/// Constant 'EEG_FEATURE_HFD'.
/**
  * Higuchi Fractal Dimension
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_HFD = 22
};

/// Constant 'EEG_FEATURE_PFD'.
/**
  * Petrosian Fractal Dimension
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_PFD = 23
};

/// Constant 'EEG_FEATURE_DFA'.
/**
  * Detrended Fluctuation Analysis
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_DFA = 24
};

/// Constant 'EEG_FEATURE_GRAPH_FEATURES'.
/**
  * Connectivity / State Domain
  * Graph-theoretic EEG features
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_GRAPH_FEATURES = 30
};

/// Constant 'EEG_FEATURE_SOURCE_CONNECTIVITY'.
/**
  * Source-level connectivity matrices
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_SOURCE_CONNECTIVITY = 31
};

/// Constant 'EEG_FEATURE_CONNECTIVITY'.
/**
  * Coherence, PLV, or other connectivity metrics
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_CONNECTIVITY = 32
};

/// Constant 'EEG_FEATURE_DECODING_CSP'.
/**
  * Common Spatial Patterns for ERP / MI decoding
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_DECODING_CSP = 33
};

/// Constant 'EEG_FEATURE_SSL_FEATURES'.
/**
  * Self-supervised latent features
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_SSL_FEATURES = 34
};

/// Constant 'EEG_FEATURE_PLV'.
/**
  * Phase-Locking Value between channels (phase consistency)
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_PLV = 35
};

/// Constant 'EEG_FEATURE_COHERENCE'.
/**
  * Frequency-domain linear synchronization between channels
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_COHERENCE = 36
};

/// Constant 'EEG_FEATURE_GRAPH_CONNECTIVITY'.
/**
  * Graph-theoretic measures from channel connectivity
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_GRAPH_CONNECTIVITY = 37
};

/// Constant 'EEG_FEATURE_STAT_FEATURES'.
/**
  * Statistical
  * Mean, variance, skewness, kurtosis
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_STAT_FEATURES = 40
};

/// Constant 'EEG_FEATURE_RIEMAN_COVARIANCE'.
/**
  * Covariance matrices Riemannian tangent space
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_RIEMAN_COVARIANCE = 41
};

/// Constant 'EEG_FEATURE_CORR_MATRIX'.
/**
  * Raw covariance or correlation between EEG channels
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_CORR_MATRIX = 42
};

/// Constant 'EEG_FEATURE_CSP'.
/**
  * Spatial Filtering (MI-specific)
  * Common Spatial Patterns, maximizes variance differences between classes
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_CSP = 50
};

/// Constant 'EEG_FEATURE_FBCSP'.
/**
  * Filter Bank CSP, applies CSP over multiple frequency bands
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_FBCSP = 51
};

/// Constant 'EEG_FEATURE_XDAWN'.
/**
  * xDAWN spatial filtering to enhance signal-to-noise
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_XDAWN = 52
};

/// Constant 'EEG_FEATURE_FUSION'.
/**
  * cross-category fusion
  * Combines multiple feature types into a single feature vector
 */
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_FUSION = 60
};

/// Constant 'EEG_FEATURE_CUSTOM'.
enum
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo__EEG_FEATURE_CUSTOM = 255
};

// Include directives for member types
// Member 'windowing_function'
// Member 'classifier_model_name'
// Member 'model_version'
#include "rosidl_runtime_c/string.h"
// Member 'selected_preprocessing'
// Member 'selected_features'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/BrainDecodingGeneralInfo in the package healthcare_msgs.
/**
  * Windowing that leads to the output
 */
typedef struct healthcare_msgs__msg__BrainDecodingGeneralInfo
{
  rosidl_runtime_c__String windowing_function;
  uint16_t window_size;
  uint16_t window_overlap;
  uint8_t output_method;
  /// For multiple-window or averaging methods (only if output_method = 2, 3 or 4), this specifies how many windows to combine.
  uint16_t num_windows_per_output;
  /// Model information
  rosidl_runtime_c__String classifier_model_name;
  rosidl_runtime_c__String model_version;
  rosidl_runtime_c__uint8__Sequence selected_preprocessing;
  rosidl_runtime_c__uint8__Sequence selected_features;
} healthcare_msgs__msg__BrainDecodingGeneralInfo;

// Struct for a sequence of healthcare_msgs__msg__BrainDecodingGeneralInfo.
typedef struct healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence
{
  healthcare_msgs__msg__BrainDecodingGeneralInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BrainDecodingGeneralInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__STRUCT_H_
