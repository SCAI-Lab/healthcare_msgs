// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/CardiacOutputInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/cardiac_output_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/cardiac_output_info__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const CardiacOutputInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: unit
  {
    out << "unit: ";
    rosidl_generator_traits::value_to_yaml(msg.unit, out);
    out << ", ";
  }

  // member: sensor_placement
  {
    if (msg.sensor_placement.size() == 0) {
      out << "sensor_placement: []";
    } else {
      out << "sensor_placement: [";
      size_t pending_items = msg.sensor_placement.size();
      for (auto item : msg.sensor_placement) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: measurement_method
  {
    out << "measurement_method: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_method, out);
    out << ", ";
  }

  // member: filters
  {
    out << "filters: ";
    to_flow_style_yaml(msg.filters, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CardiacOutputInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: unit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "unit: ";
    rosidl_generator_traits::value_to_yaml(msg.unit, out);
    out << "\n";
  }

  // member: sensor_placement
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.sensor_placement.size() == 0) {
      out << "sensor_placement: []\n";
    } else {
      out << "sensor_placement:\n";
      for (auto item : msg.sensor_placement) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: measurement_method
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_method: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_method, out);
    out << "\n";
  }

  // member: filters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filters:\n";
    to_block_style_yaml(msg.filters, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CardiacOutputInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::CardiacOutputInfo>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).device_info,
    std::forward<T>(msg).unit,
    std::forward<T>(msg).sensor_placement,
    std::forward<T>(msg).measurement_method,
    std::forward<T>(msg).filters);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::CardiacOutputInfo>()
{
  return "healthcare_msgs::msg::CardiacOutputInfo";
}

template<>
constexpr const char * name<healthcare_msgs::msg::CardiacOutputInfo>()
{
  return "healthcare_msgs/msg/CardiacOutputInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::CardiacOutputInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::CardiacOutputInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::CardiacOutputInfo>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::CardiacOutputInfo>
{
  static constexpr std::size_t member_count = 5;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "device_info",
    "unit",
    "sensor_placement",
    "measurement_method",
    "filters",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__TRAITS_HPP_
