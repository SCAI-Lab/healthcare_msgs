// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EOG.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eog.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EOG__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EOG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/eog__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EOG_signal_quality
{
public:
  explicit Init_EOG_signal_quality(::healthcare_msgs::msg::EOG & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EOG signal_quality(::healthcare_msgs::msg::EOG::_signal_quality_type arg)
  {
    msg_.signal_quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EOG msg_;
};

class Init_EOG_eog
{
public:
  explicit Init_EOG_eog(::healthcare_msgs::msg::EOG & msg)
  : msg_(msg)
  {}
  Init_EOG_signal_quality eog(::healthcare_msgs::msg::EOG::_eog_type arg)
  {
    msg_.eog = std::move(arg);
    return Init_EOG_signal_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::EOG msg_;
};

class Init_EOG_sample_size
{
public:
  explicit Init_EOG_sample_size(::healthcare_msgs::msg::EOG & msg)
  : msg_(msg)
  {}
  Init_EOG_eog sample_size(::healthcare_msgs::msg::EOG::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_EOG_eog(msg_);
  }

private:
  ::healthcare_msgs::msg::EOG msg_;
};

class Init_EOG_channel_size
{
public:
  explicit Init_EOG_channel_size(::healthcare_msgs::msg::EOG & msg)
  : msg_(msg)
  {}
  Init_EOG_sample_size channel_size(::healthcare_msgs::msg::EOG::_channel_size_type arg)
  {
    msg_.channel_size = std::move(arg);
    return Init_EOG_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::EOG msg_;
};

class Init_EOG_session_id
{
public:
  explicit Init_EOG_session_id(::healthcare_msgs::msg::EOG & msg)
  : msg_(msg)
  {}
  Init_EOG_channel_size session_id(::healthcare_msgs::msg::EOG::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_EOG_channel_size(msg_);
  }

private:
  ::healthcare_msgs::msg::EOG msg_;
};

class Init_EOG_header
{
public:
  Init_EOG_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EOG_session_id header(::healthcare_msgs::msg::EOG::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_EOG_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::EOG msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EOG>()
{
  return healthcare_msgs::msg::builder::Init_EOG_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EOG__BUILDER_HPP_
