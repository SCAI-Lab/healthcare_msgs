// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingSleepStageInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_sleep_stage_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/brain_decoding_sleep_stage_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BrainDecodingSleepStageInfo_comments
{
public:
  explicit Init_BrainDecodingSleepStageInfo_comments(::healthcare_msgs::msg::BrainDecodingSleepStageInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BrainDecodingSleepStageInfo comments(::healthcare_msgs::msg::BrainDecodingSleepStageInfo::_comments_type arg)
  {
    msg_.comments = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingSleepStageInfo msg_;
};

class Init_BrainDecodingSleepStageInfo_sleep_features
{
public:
  explicit Init_BrainDecodingSleepStageInfo_sleep_features(::healthcare_msgs::msg::BrainDecodingSleepStageInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingSleepStageInfo_comments sleep_features(::healthcare_msgs::msg::BrainDecodingSleepStageInfo::_sleep_features_type arg)
  {
    msg_.sleep_features = std::move(arg);
    return Init_BrainDecodingSleepStageInfo_comments(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingSleepStageInfo msg_;
};

class Init_BrainDecodingSleepStageInfo_brain_decoding_general_info
{
public:
  explicit Init_BrainDecodingSleepStageInfo_brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingSleepStageInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingSleepStageInfo_sleep_features brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingSleepStageInfo::_brain_decoding_general_info_type arg)
  {
    msg_.brain_decoding_general_info = std::move(arg);
    return Init_BrainDecodingSleepStageInfo_sleep_features(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingSleepStageInfo msg_;
};

class Init_BrainDecodingSleepStageInfo_device_info
{
public:
  Init_BrainDecodingSleepStageInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BrainDecodingSleepStageInfo_brain_decoding_general_info device_info(::healthcare_msgs::msg::BrainDecodingSleepStageInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_BrainDecodingSleepStageInfo_brain_decoding_general_info(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingSleepStageInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BrainDecodingSleepStageInfo>()
{
  return healthcare_msgs::msg::builder::Init_BrainDecodingSleepStageInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__BUILDER_HPP_
