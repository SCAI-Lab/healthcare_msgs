// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/HeartRateInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/heart_rate_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_buffer/buffer.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__HeartRateInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__HeartRateInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct HeartRateInfo_
{
  using Type = HeartRateInfo_<ContainerAllocator>;

  explicit HeartRateInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    filters(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->unit = 0;
      this->measurement_method = 0;
    }
  }

  explicit HeartRateInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    filters(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->unit = 0;
      this->measurement_method = 0;
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _unit_type =
    uint8_t;
  _unit_type unit;
  using _sensor_placement_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _sensor_placement_type sensor_placement;
  using _measurement_method_type =
    uint8_t;
  _measurement_method_type measurement_method;
  using _filters_type =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator>;
  _filters_type filters;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__unit(
    const uint8_t & _arg)
  {
    this->unit = _arg;
    return *this;
  }
  Type & set__sensor_placement(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->sensor_placement = _arg;
    return *this;
  }
  Type & set__measurement_method(
    const uint8_t & _arg)
  {
    this->measurement_method = _arg;
    return *this;
  }
  Type & set__filters(
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> & _arg)
  {
    this->filters = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t UNIT_UNKNOWN =
    0u;
  static constexpr uint8_t UNIT_BPM =
    1u;
  static constexpr uint8_t UNIT_HZ =
    2u;
  static constexpr uint8_t UNIT_CUSTOM =
    255u;
  static constexpr uint8_t PLACEMENT_UNKNOWN =
    0u;
  static constexpr uint8_t PLACEMENT_WRIST =
    1u;
  static constexpr uint8_t PLACEMENT_CHEST =
    2u;
  static constexpr uint8_t PLACEMENT_FINGER =
    3u;
  static constexpr uint8_t PLACEMENT_EARLOBE =
    4u;
  static constexpr uint8_t PLACEMENT_FOREHEAD =
    5u;
  static constexpr uint8_t PLACEMENT_ANKLE =
    6u;
  static constexpr uint8_t PLACEMENT_CUSTOM =
    255u;
  static constexpr uint8_t METHOD_UNKNOWN =
    0u;
  static constexpr uint8_t METHOD_PPG =
    1u;
  static constexpr uint8_t METHOD_ECG =
    2u;
  static constexpr uint8_t METHOD_BCG =
    3u;
  static constexpr uint8_t METHOD_RADAR =
    4u;
  static constexpr uint8_t METHOD_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__HeartRateInfo
    std::shared_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__HeartRateInfo
    std::shared_ptr<healthcare_msgs::msg::HeartRateInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const HeartRateInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->unit != other.unit) {
      return false;
    }
    if (this->sensor_placement != other.sensor_placement) {
      return false;
    }
    if (this->measurement_method != other.measurement_method) {
      return false;
    }
    if (this->filters != other.filters) {
      return false;
    }
    return true;
  }
  bool operator!=(const HeartRateInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct HeartRateInfo_

// alias to use template instance with default allocator
using HeartRateInfo =
  healthcare_msgs::msg::HeartRateInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::UNIT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::UNIT_BPM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::UNIT_HZ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::UNIT_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_WRIST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_CHEST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_FINGER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_EARLOBE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_FOREHEAD;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_ANKLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::PLACEMENT_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::METHOD_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::METHOD_PPG;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::METHOD_ECG;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::METHOD_BCG;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::METHOD_RADAR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t HeartRateInfo_<ContainerAllocator>::METHOD_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_INFO__STRUCT_HPP_
