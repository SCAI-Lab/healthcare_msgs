// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__functions.h"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace healthcare_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ADLModelClassificationResult_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) healthcare_msgs::msg::ADLModelClassificationResult(_init);
}

void ADLModelClassificationResult_fini_function(void * message_memory)
{
  auto typed_message = static_cast<healthcare_msgs::msg::ADLModelClassificationResult *>(message_memory);
  typed_message->~ADLModelClassificationResult();
}

size_t size_function__ADLModelClassificationResult__device_serial_number(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ADLModelClassificationResult__device_serial_number(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void * get_function__ADLModelClassificationResult__device_serial_number(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void fetch_function__ADLModelClassificationResult__device_serial_number(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const std::string *>(
    get_const_function__ADLModelClassificationResult__device_serial_number(untyped_member, index));
  auto & value = *reinterpret_cast<std::string *>(untyped_value);
  value = item;
}

void assign_function__ADLModelClassificationResult__device_serial_number(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<std::string *>(
    get_function__ADLModelClassificationResult__device_serial_number(untyped_member, index));
  const auto & value = *reinterpret_cast<const std::string *>(untyped_value);
  item = value;
}

void resize_function__ADLModelClassificationResult__device_serial_number(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<std::string> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ADLModelClassificationResult__glossary(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ADLModelClassificationResult__glossary(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void * get_function__ADLModelClassificationResult__glossary(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void fetch_function__ADLModelClassificationResult__glossary(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const std::string *>(
    get_const_function__ADLModelClassificationResult__glossary(untyped_member, index));
  auto & value = *reinterpret_cast<std::string *>(untyped_value);
  value = item;
}

void assign_function__ADLModelClassificationResult__glossary(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<std::string *>(
    get_function__ADLModelClassificationResult__glossary(untyped_member, index));
  const auto & value = *reinterpret_cast<const std::string *>(untyped_value);
  item = value;
}

void resize_function__ADLModelClassificationResult__glossary(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<std::string> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ADLModelClassificationResult__model_type(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ADLModelClassificationResult__model_type(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void * get_function__ADLModelClassificationResult__model_type(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void fetch_function__ADLModelClassificationResult__model_type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const std::string *>(
    get_const_function__ADLModelClassificationResult__model_type(untyped_member, index));
  auto & value = *reinterpret_cast<std::string *>(untyped_value);
  value = item;
}

void assign_function__ADLModelClassificationResult__model_type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<std::string *>(
    get_function__ADLModelClassificationResult__model_type(untyped_member, index));
  const auto & value = *reinterpret_cast<const std::string *>(untyped_value);
  item = value;
}

void resize_function__ADLModelClassificationResult__model_type(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<std::string> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ADLModelClassificationResult__model_version(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ADLModelClassificationResult__model_version(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void * get_function__ADLModelClassificationResult__model_version(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void fetch_function__ADLModelClassificationResult__model_version(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const std::string *>(
    get_const_function__ADLModelClassificationResult__model_version(untyped_member, index));
  auto & value = *reinterpret_cast<std::string *>(untyped_value);
  value = item;
}

void assign_function__ADLModelClassificationResult__model_version(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<std::string *>(
    get_function__ADLModelClassificationResult__model_version(untyped_member, index));
  const auto & value = *reinterpret_cast<const std::string *>(untyped_value);
  item = value;
}

void resize_function__ADLModelClassificationResult__model_version(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<std::string> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ADLModelClassificationResult_message_member_array[6] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<std_msgs::msg::Header>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ADLModelClassificationResult, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "device_serial_number",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ADLModelClassificationResult, device_serial_number),  // bytes offset in struct
    nullptr,  // default value
    size_function__ADLModelClassificationResult__device_serial_number,  // size() function pointer
    get_const_function__ADLModelClassificationResult__device_serial_number,  // get_const(index) function pointer
    get_function__ADLModelClassificationResult__device_serial_number,  // get(index) function pointer
    fetch_function__ADLModelClassificationResult__device_serial_number,  // fetch(index, &value) function pointer
    assign_function__ADLModelClassificationResult__device_serial_number,  // assign(index, value) function pointer
    resize_function__ADLModelClassificationResult__device_serial_number,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "glossary",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ADLModelClassificationResult, glossary),  // bytes offset in struct
    nullptr,  // default value
    size_function__ADLModelClassificationResult__glossary,  // size() function pointer
    get_const_function__ADLModelClassificationResult__glossary,  // get_const(index) function pointer
    get_function__ADLModelClassificationResult__glossary,  // get(index) function pointer
    fetch_function__ADLModelClassificationResult__glossary,  // fetch(index, &value) function pointer
    assign_function__ADLModelClassificationResult__glossary,  // assign(index, value) function pointer
    resize_function__ADLModelClassificationResult__glossary,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "class_amount",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ADLModelClassificationResult, class_amount),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "model_type",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ADLModelClassificationResult, model_type),  // bytes offset in struct
    nullptr,  // default value
    size_function__ADLModelClassificationResult__model_type,  // size() function pointer
    get_const_function__ADLModelClassificationResult__model_type,  // get_const(index) function pointer
    get_function__ADLModelClassificationResult__model_type,  // get(index) function pointer
    fetch_function__ADLModelClassificationResult__model_type,  // fetch(index, &value) function pointer
    assign_function__ADLModelClassificationResult__model_type,  // assign(index, value) function pointer
    resize_function__ADLModelClassificationResult__model_type,  // resize(index) function pointer
    false  // is_rosidl_buffer
  },
  {
    "model_version",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs::msg::ADLModelClassificationResult, model_version),  // bytes offset in struct
    nullptr,  // default value
    size_function__ADLModelClassificationResult__model_version,  // size() function pointer
    get_const_function__ADLModelClassificationResult__model_version,  // get_const(index) function pointer
    get_function__ADLModelClassificationResult__model_version,  // get(index) function pointer
    fetch_function__ADLModelClassificationResult__model_version,  // fetch(index, &value) function pointer
    assign_function__ADLModelClassificationResult__model_version,  // assign(index, value) function pointer
    resize_function__ADLModelClassificationResult__model_version,  // resize(index) function pointer
    false  // is_rosidl_buffer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ADLModelClassificationResult_message_members = {
  "healthcare_msgs::msg",  // message namespace
  "ADLModelClassificationResult",  // message name
  6,  // number of fields
  sizeof(healthcare_msgs::msg::ADLModelClassificationResult),
  false,  // has_any_key_member_
  ADLModelClassificationResult_message_member_array,  // message members
  ADLModelClassificationResult_init_function,  // function to initialize message memory (memory has to be allocated)
  ADLModelClassificationResult_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ADLModelClassificationResult_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ADLModelClassificationResult_message_members,
  get_message_typesupport_handle_function,
  &healthcare_msgs__msg__ADLModelClassificationResult__get_type_hash,
  &healthcare_msgs__msg__ADLModelClassificationResult__get_type_description,
  &healthcare_msgs__msg__ADLModelClassificationResult__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace healthcare_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<healthcare_msgs::msg::ADLModelClassificationResult>()
{
  return &::healthcare_msgs::msg::rosidl_typesupport_introspection_cpp::ADLModelClassificationResult_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, healthcare_msgs, msg, ADLModelClassificationResult)() {
  return &::healthcare_msgs::msg::rosidl_typesupport_introspection_cpp::ADLModelClassificationResult_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
