// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/CardiacOutputInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/cardiac_output_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_L_PER_MIN'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__UNIT_L_PER_MIN = 1
};

/// Constant 'UNIT_ML_PER_MIN'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__UNIT_ML_PER_MIN = 2
};

/// Constant 'UNIT_COUNTS'.
/**
  * If raw sensor output is used
 */
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__UNIT_COUNTS = 3
};

/// Constant 'UNIT_CUSTOM'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__UNIT_CUSTOM = 255
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Sensor Placement Enum
 */
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_CHEST'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__PLACEMENT_CHEST = 1
};

/// Constant 'PLACEMENT_BACK'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__PLACEMENT_BACK = 2
};

/// Constant 'PLACEMENT_FINGER'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__PLACEMENT_FINGER = 3
};

/// Constant 'PLACEMENT_NECK'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__PLACEMENT_NECK = 4
};

/// Constant 'PLACEMENT_AORTA'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__PLACEMENT_AORTA = 5
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'METHOD_UNKNOWN'.
/**
  * Measurement Method Enum
 */
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_UNKNOWN = 0
};

/// Constant 'METHOD_DYE_DILUTION'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_DYE_DILUTION = 1
};

/// Constant 'METHOD_THERMODILUTION'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_THERMODILUTION = 2
};

/// Constant 'METHOD_ECHO'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_ECHO = 3
};

/// Constant 'METHOD_IMPEDANCE'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_IMPEDANCE = 4
};

/// Constant 'METHOD_FICK'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_FICK = 5
};

/// Constant 'METHOD_PULSE_CONTOUR'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_PULSE_CONTOUR = 6
};

/// Constant 'METHOD_CUSTOM'.
enum
{
  healthcare_msgs__msg__CardiacOutputInfo__METHOD_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'sensor_placement'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/CardiacOutputInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__CardiacOutputInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  /// e.g., UNIT_L_PER_MIN
  uint8_t unit;
  rosidl_runtime_c__uint8__Sequence sensor_placement;
  uint8_t measurement_method;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__CardiacOutputInfo;

// Struct for a sequence of healthcare_msgs__msg__CardiacOutputInfo.
typedef struct healthcare_msgs__msg__CardiacOutputInfo__Sequence
{
  healthcare_msgs__msg__CardiacOutputInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__CardiacOutputInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__STRUCT_H_
