// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingSleepStageInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_sleep_stage_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_buffer/buffer.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__BrainDecodingSleepStageInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__BrainDecodingSleepStageInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BrainDecodingSleepStageInfo_
{
  using Type = BrainDecodingSleepStageInfo_<ContainerAllocator>;

  explicit BrainDecodingSleepStageInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    brain_decoding_general_info(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->comments = "";
    }
  }

  explicit BrainDecodingSleepStageInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    brain_decoding_general_info(_alloc, _init),
    comments(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->comments = "";
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _brain_decoding_general_info_type =
    healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>;
  _brain_decoding_general_info_type brain_decoding_general_info;
  using _sleep_features_type =
    rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _sleep_features_type sleep_features;
  using _comments_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _comments_type comments;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__brain_decoding_general_info(
    const healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> & _arg)
  {
    this->brain_decoding_general_info = _arg;
    return *this;
  }
  Type & set__sleep_features(
    const rosidl::Buffer<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->sleep_features = _arg;
    return *this;
  }
  Type & set__comments(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->comments = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t SLEEP_DETECT_SPINDLES =
    70u;
  static constexpr uint8_t SLEEP_SLOW_WAVE_ANALYSIS =
    71u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__BrainDecodingSleepStageInfo
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__BrainDecodingSleepStageInfo
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingSleepStageInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BrainDecodingSleepStageInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->brain_decoding_general_info != other.brain_decoding_general_info) {
      return false;
    }
    if (this->sleep_features != other.sleep_features) {
      return false;
    }
    if (this->comments != other.comments) {
      return false;
    }
    return true;
  }
  bool operator!=(const BrainDecodingSleepStageInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BrainDecodingSleepStageInfo_

// alias to use template instance with default allocator
using BrainDecodingSleepStageInfo =
  healthcare_msgs::msg::BrainDecodingSleepStageInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingSleepStageInfo_<ContainerAllocator>::SLEEP_DETECT_SPINDLES;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BrainDecodingSleepStageInfo_<ContainerAllocator>::SLEEP_SLOW_WAVE_ANALYSIS;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__STRUCT_HPP_
