// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/FilterBase.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/filter_base.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_FilterBase_savitzky_golay_filter
{
public:
  explicit Init_FilterBase_savitzky_golay_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::FilterBase savitzky_golay_filter(::healthcare_msgs::msg::FilterBase::_savitzky_golay_filter_type arg)
  {
    msg_.savitzky_golay_filter = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_notch_filter
{
public:
  explicit Init_FilterBase_notch_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  Init_FilterBase_savitzky_golay_filter notch_filter(::healthcare_msgs::msg::FilterBase::_notch_filter_type arg)
  {
    msg_.notch_filter = std::move(arg);
    return Init_FilterBase_savitzky_golay_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_moving_average_filter
{
public:
  explicit Init_FilterBase_moving_average_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  Init_FilterBase_notch_filter moving_average_filter(::healthcare_msgs::msg::FilterBase::_moving_average_filter_type arg)
  {
    msg_.moving_average_filter = std::move(arg);
    return Init_FilterBase_notch_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_low_pass_filter
{
public:
  explicit Init_FilterBase_low_pass_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  Init_FilterBase_moving_average_filter low_pass_filter(::healthcare_msgs::msg::FilterBase::_low_pass_filter_type arg)
  {
    msg_.low_pass_filter = std::move(arg);
    return Init_FilterBase_moving_average_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_kalman_filter
{
public:
  explicit Init_FilterBase_kalman_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  Init_FilterBase_low_pass_filter kalman_filter(::healthcare_msgs::msg::FilterBase::_kalman_filter_type arg)
  {
    msg_.kalman_filter = std::move(arg);
    return Init_FilterBase_low_pass_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_high_pass_filter
{
public:
  explicit Init_FilterBase_high_pass_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  Init_FilterBase_kalman_filter high_pass_filter(::healthcare_msgs::msg::FilterBase::_high_pass_filter_type arg)
  {
    msg_.high_pass_filter = std::move(arg);
    return Init_FilterBase_kalman_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_butter_worth_filter
{
public:
  explicit Init_FilterBase_butter_worth_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  Init_FilterBase_high_pass_filter butter_worth_filter(::healthcare_msgs::msg::FilterBase::_butter_worth_filter_type arg)
  {
    msg_.butter_worth_filter = std::move(arg);
    return Init_FilterBase_high_pass_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_band_pass_filter
{
public:
  explicit Init_FilterBase_band_pass_filter(::healthcare_msgs::msg::FilterBase & msg)
  : msg_(msg)
  {}
  Init_FilterBase_butter_worth_filter band_pass_filter(::healthcare_msgs::msg::FilterBase::_band_pass_filter_type arg)
  {
    msg_.band_pass_filter = std::move(arg);
    return Init_FilterBase_butter_worth_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

class Init_FilterBase_filters
{
public:
  Init_FilterBase_filters()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FilterBase_band_pass_filter filters(::healthcare_msgs::msg::FilterBase::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return Init_FilterBase_band_pass_filter(msg_);
  }

private:
  ::healthcare_msgs::msg::FilterBase msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::FilterBase>()
{
  return healthcare_msgs::msg::builder::Init_FilterBase_filters();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__BUILDER_HPP_
