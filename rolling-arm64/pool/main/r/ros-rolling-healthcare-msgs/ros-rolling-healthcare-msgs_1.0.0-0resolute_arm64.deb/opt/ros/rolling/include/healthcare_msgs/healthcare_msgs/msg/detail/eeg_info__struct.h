// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eeg_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__EEGInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_UV'.
enum
{
  healthcare_msgs__msg__EEGInfo__UNIT_UV = 1
};

/// Constant 'UNIT_MV'.
enum
{
  healthcare_msgs__msg__EEGInfo__UNIT_MV = 2
};

/// Constant 'UNIT_COUNTS'.
enum
{
  healthcare_msgs__msg__EEGInfo__UNIT_COUNTS = 3
};

/// Constant 'EEG_FEATURE_UNKNOWN'.
/**
  * EEG Preprocessing Enum
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_FEATURE_UNKNOWN = 0
};

/// Constant 'EEG_PREPROC_BANDPASS'.
/**
  * Bandpass filter applied
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_BANDPASS = 1
};

/// Constant 'EEG_PREPROC_NOTCH'.
/**
  * Notch filter (e.g., 50/60 Hz)
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_NOTCH = 2
};

/// Constant 'EEG_PREPROC_ICA'.
/**
  * Independent Component Analysis
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_ICA = 3
};

/// Constant 'EEG_PREPROC_CAR'.
/**
  * Common Average Reference
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_CAR = 4
};

/// Constant 'EEG_PREPROC_ARTEFACT_REJ'.
/**
  * Artifact rejection/interpolation
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_ARTEFACT_REJ = 5
};

/// Constant 'EEG_PREPROC_BASELINE_CORR'.
/**
  * Baseline correction
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_BASELINE_CORR = 6
};

/// Constant 'EEG_PREPROC_DOWNSAMPLE'.
/**
  * Downsampling
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_DOWNSAMPLE = 7
};

/// Constant 'EEG_PREPROC_SEGMENTED'.
/**
  * Epoching / segmentation
 */
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_PREPROC_SEGMENTED = 8
};

/// Constant 'EEG_FEATURE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EEGInfo__EEG_FEATURE_CUSTOM = 255
};

/// Constant 'MONTAGE_TYPE_UNKNOWN'.
/**
  * Montage Type Enum
 */
enum
{
  healthcare_msgs__msg__EEGInfo__MONTAGE_TYPE_UNKNOWN = 0
};

/// Constant 'MONTAGE_TYPE_BIPOLAR'.
enum
{
  healthcare_msgs__msg__EEGInfo__MONTAGE_TYPE_BIPOLAR = 1
};

/// Constant 'MONTAGE_TYPE_REFERENTIAL'.
enum
{
  healthcare_msgs__msg__EEGInfo__MONTAGE_TYPE_REFERENTIAL = 2
};

/// Constant 'MONTAGE_TYPE_AVERAGE_REF'.
enum
{
  healthcare_msgs__msg__EEGInfo__MONTAGE_TYPE_AVERAGE_REF = 3
};

/// Constant 'MONTAGE_TYPE_LAPLACIAN'.
enum
{
  healthcare_msgs__msg__EEGInfo__MONTAGE_TYPE_LAPLACIAN = 4
};

/// Constant 'PLACEMENT_METHOD_UNKNOWN'.
/**
  * Placement Method Enum
 */
enum
{
  healthcare_msgs__msg__EEGInfo__PLACEMENT_METHOD_UNKNOWN = 0
};

/// Constant 'PLACEMENT_METHOD_1020'.
enum
{
  healthcare_msgs__msg__EEGInfo__PLACEMENT_METHOD_1020 = 1
};

/// Constant 'PLACEMENT_METHOD_1010'.
enum
{
  healthcare_msgs__msg__EEGInfo__PLACEMENT_METHOD_1010 = 2
};

/// Constant 'PLACEMENT_METHOD_105'.
enum
{
  healthcare_msgs__msg__EEGInfo__PLACEMENT_METHOD_105 = 3
};

/// Constant 'PLACEMENT_METHOD_CUSTOM'.
enum
{
  healthcare_msgs__msg__EEGInfo__PLACEMENT_METHOD_CUSTOM = 255
};

/// Constant 'ELECTRODE_UNKNOWN'.
/**
  * Electrode Site Enum
 */
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_UNKNOWN = 0
};

/// Constant 'ELECTRODE_FP1'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_FP1 = 1
};

/// Constant 'ELECTRODE_FP2'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_FP2 = 2
};

/// Constant 'ELECTRODE_F3'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_F3 = 3
};

/// Constant 'ELECTRODE_F4'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_F4 = 4
};

/// Constant 'ELECTRODE_C3'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_C3 = 5
};

/// Constant 'ELECTRODE_C4'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_C4 = 6
};

/// Constant 'ELECTRODE_P3'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_P3 = 7
};

/// Constant 'ELECTRODE_P4'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_P4 = 8
};

/// Constant 'ELECTRODE_O1'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_O1 = 9
};

/// Constant 'ELECTRODE_O2'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_O2 = 10
};

/// Constant 'ELECTRODE_F7'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_F7 = 11
};

/// Constant 'ELECTRODE_F8'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_F8 = 12
};

/// Constant 'ELECTRODE_T3'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_T3 = 13
};

/// Constant 'ELECTRODE_T4'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_T4 = 14
};

/// Constant 'ELECTRODE_T5'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_T5 = 15
};

/// Constant 'ELECTRODE_T6'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_T6 = 16
};

/// Constant 'ELECTRODE_FZ'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_FZ = 17
};

/// Constant 'ELECTRODE_CZ'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_CZ = 18
};

/// Constant 'ELECTRODE_PZ'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PZ = 19
};

/// Constant 'ELECTRODE_OZ'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_OZ = 20
};

/// Constant 'ELECTRODE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_CUSTOM = 255
};

/// Constant 'ELECTRODE_PHYSICAL_UNKNOWN'.
/**
  * Electrode Physical Type Enum
 */
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_UNKNOWN = 0
};

/// Constant 'ELECTRODE_PHYSICAL_AGCL'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_AGCL = 1
};

/// Constant 'ELECTRODE_PHYSICAL_GOLD_CUP'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_GOLD_CUP = 2
};

/// Constant 'ELECTRODE_PHYSICAL_DRY'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_DRY = 3
};

/// Constant 'ELECTRODE_PHYSICAL_WET'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_WET = 4
};

/// Constant 'ELECTRODE_PHYSICAL_HYDROGEL'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_HYDROGEL = 5
};

/// Constant 'ELECTRODE_PHYSICAL_MICRONEEDLE'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_MICRONEEDLE = 6
};

/// Constant 'ELECTRODE_PHYSICAL_CUSTOM'.
enum
{
  healthcare_msgs__msg__EEGInfo__ELECTRODE_PHYSICAL_CUSTOM = 255
};

/// Constant 'SIGNAL_MODE_UNKNOWN'.
/**
  * Signal Mode Enum
 */
enum
{
  healthcare_msgs__msg__EEGInfo__SIGNAL_MODE_UNKNOWN = 0
};

/// Constant 'SIGNAL_MODE_SURFACE'.
enum
{
  healthcare_msgs__msg__EEGInfo__SIGNAL_MODE_SURFACE = 1
};

/// Constant 'SIGNAL_MODE_INTRACRANIAL'.
enum
{
  healthcare_msgs__msg__EEGInfo__SIGNAL_MODE_INTRACRANIAL = 2
};

/// Constant 'SIGNAL_MODE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EEGInfo__SIGNAL_MODE_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'selected_preprocessing'
// Member 'bipolar_active_sites'
// Member 'bipolar_reference_sites'
// Member 'reference_sites'
// Member 'placement_method'
// Member 'electrode_sites'
// Member 'electrode_physical_type'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/EEGInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EEGInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  /// Moved from EEG
  uint8_t channel_size;
  uint8_t units;
  rosidl_runtime_c__uint8__Sequence selected_preprocessing;
  uint8_t montage_type;
  /// Montage-specific metadata (use Electrode Site Enum)
  /// Only used if montage_type=BIPOLAR; length = channel_count
  rosidl_runtime_c__uint8__Sequence bipolar_active_sites;
  /// Only used if montage_type=BIPOLAR; length = channel_count
  rosidl_runtime_c__uint8__Sequence bipolar_reference_sites;
  /// Only used if montage_type=REFERENTIAL or AVERAGE_REF
  rosidl_runtime_c__uint8__Sequence reference_sites;
  /// Support multiple placements
  rosidl_runtime_c__uint8__Sequence placement_method;
  /// One per channel, in the order used in eeg[] data
  rosidl_runtime_c__uint8__Sequence electrode_sites;
  rosidl_runtime_c__uint8__Sequence electrode_physical_type;
  uint8_t signal_mode;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__EEGInfo;

// Struct for a sequence of healthcare_msgs__msg__EEGInfo.
typedef struct healthcare_msgs__msg__EEGInfo__Sequence
{
  healthcare_msgs__msg__EEGInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EEGInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__STRUCT_H_
