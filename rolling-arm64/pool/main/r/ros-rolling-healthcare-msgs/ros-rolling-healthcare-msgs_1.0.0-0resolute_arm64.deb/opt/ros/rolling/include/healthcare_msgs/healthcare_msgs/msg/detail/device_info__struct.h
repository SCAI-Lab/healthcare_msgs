// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/DeviceInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/device_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
// Member 'device_manufacturer'
// Member 'device_name'
// Member 'device_type'
// Member 'device_serial_number'
// Member 'measuring_unit'
#include "rosidl_runtime_c/string.h"
// Member 'mds'
#include "healthcare_msgs/msg/detail/medical_device_system__struct.h"

/// Struct defined in msg/DeviceInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__DeviceInfo
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String session_id;
  /// Medical Device System
  healthcare_msgs__msg__MedicalDeviceSystem mds;
  /// Device identity
  /// Name of the device manufacturer
  rosidl_runtime_c__String device_manufacturer;
  /// Name of the device
  rosidl_runtime_c__String device_name;
  /// Type or purpose of the device (e.g., heart rate sensor, pressure mat)
  rosidl_runtime_c__String device_type;
  /// Serial number for identification
  rosidl_runtime_c__String device_serial_number;
  /// Environmental requirements
  /// Minimal operating temperature
  float minimal_operation_temperature;
  /// Maximal operating temperature
  float maximal_operation_temperature;
  /// Max tolerated humidity from 0 to 1
  float maximal_relative_humidity;
  /// Minimal tolerated pressure
  float minimal_atmospheric_pressure;
  /// Max tolerated pressure
  float maximal_atmospheric_pressure;
  /// Measurement specs
  /// Unit of measurement (e.g. bpm, mmHg)
  rosidl_runtime_c__String measuring_unit;
  /// Sampling frequency in Hz
  uint16_t acquisition_rate_hz;
  /// Multiplicative factor; set to 1.0 if signal is already scaled
  float gain;
  /// Resolution in the given unit
  float resolution;
  /// Bits (e.g., 12, 16)
  uint8_t adc_resolution;
  /// Accuracy of the signal
  float accuracy;
  /// Max detectable value in the given unit
  float max_range;
  /// Min detectable value in the given unit
  float min_range;
  /// Number of samples per msg
  uint32_t window_size_samples;
  /// Number of samples per quality value
  uint32_t quality_window_size_samples;
  /// Step size (in ms) by which the analysis window moves forward in time
  float stride_length;
} healthcare_msgs__msg__DeviceInfo;

// Struct for a sequence of healthcare_msgs__msg__DeviceInfo.
typedef struct healthcare_msgs__msg__DeviceInfo__Sequence
{
  healthcare_msgs__msg__DeviceInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__DeviceInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__STRUCT_H_
