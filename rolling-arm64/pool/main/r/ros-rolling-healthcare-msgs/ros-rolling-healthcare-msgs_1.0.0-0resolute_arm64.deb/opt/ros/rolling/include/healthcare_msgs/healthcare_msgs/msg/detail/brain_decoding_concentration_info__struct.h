// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BrainDecodingConcentrationInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_concentration_info.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.h"
// Member 'comments'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/BrainDecodingConcentrationInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BrainDecodingConcentrationInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  healthcare_msgs__msg__BrainDecodingGeneralInfo brain_decoding_general_info;
  rosidl_runtime_c__String comments;
} healthcare_msgs__msg__BrainDecodingConcentrationInfo;

// Struct for a sequence of healthcare_msgs__msg__BrainDecodingConcentrationInfo.
typedef struct healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence
{
  healthcare_msgs__msg__BrainDecodingConcentrationInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BrainDecodingConcentrationInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__STRUCT_H_
