// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/ActivityDailyLife.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/activity_daily_life.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/activity_daily_life__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ActivityDailyLife & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: adl
  {
    out << "adl: ";
    rosidl_generator_traits::value_to_yaml(msg.adl, out);
    out << ", ";
  }

  // member: confidence
  {
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ActivityDailyLife & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: adl
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "adl: ";
    rosidl_generator_traits::value_to_yaml(msg.adl, out);
    out << "\n";
  }

  // member: confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ActivityDailyLife & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::ActivityDailyLife>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).header,
    std::forward<T>(msg).adl,
    std::forward<T>(msg).confidence);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::ActivityDailyLife>()
{
  return "healthcare_msgs::msg::ActivityDailyLife";
}

template<>
constexpr const char * name<healthcare_msgs::msg::ActivityDailyLife>()
{
  return "healthcare_msgs/msg/ActivityDailyLife";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::ActivityDailyLife>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::ActivityDailyLife>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<healthcare_msgs::msg::ActivityDailyLife>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::ActivityDailyLife>
{
  static constexpr std::size_t member_count = 3;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "header",
    "adl",
    "confidence",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__TRAITS_HPP_
