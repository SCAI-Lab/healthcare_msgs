// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BloodVolumePulse.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/blood_volume_pulse.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/blood_volume_pulse__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BloodVolumePulse_quality
{
public:
  explicit Init_BloodVolumePulse_quality(::healthcare_msgs::msg::BloodVolumePulse & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BloodVolumePulse quality(::healthcare_msgs::msg::BloodVolumePulse::_quality_type arg)
  {
    msg_.quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulse msg_;
};

class Init_BloodVolumePulse_bvp
{
public:
  explicit Init_BloodVolumePulse_bvp(::healthcare_msgs::msg::BloodVolumePulse & msg)
  : msg_(msg)
  {}
  Init_BloodVolumePulse_quality bvp(::healthcare_msgs::msg::BloodVolumePulse::_bvp_type arg)
  {
    msg_.bvp = std::move(arg);
    return Init_BloodVolumePulse_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulse msg_;
};

class Init_BloodVolumePulse_sample_size
{
public:
  explicit Init_BloodVolumePulse_sample_size(::healthcare_msgs::msg::BloodVolumePulse & msg)
  : msg_(msg)
  {}
  Init_BloodVolumePulse_bvp sample_size(::healthcare_msgs::msg::BloodVolumePulse::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_BloodVolumePulse_bvp(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulse msg_;
};

class Init_BloodVolumePulse_session_id
{
public:
  explicit Init_BloodVolumePulse_session_id(::healthcare_msgs::msg::BloodVolumePulse & msg)
  : msg_(msg)
  {}
  Init_BloodVolumePulse_sample_size session_id(::healthcare_msgs::msg::BloodVolumePulse::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_BloodVolumePulse_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulse msg_;
};

class Init_BloodVolumePulse_header
{
public:
  Init_BloodVolumePulse_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BloodVolumePulse_session_id header(::healthcare_msgs::msg::BloodVolumePulse::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_BloodVolumePulse_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulse msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BloodVolumePulse>()
{
  return healthcare_msgs::msg::builder::Init_BloodVolumePulse_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__BUILDER_HPP_
