// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BandPassFilter.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/band_pass_filter.h"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/BandPassFilter in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BandPassFilter
{
  std_msgs__msg__Header header;
  /// Lower bound
  float low_cutoff_frequency;
  /// Upper bound
  float high_cutoff_frequency;
  /// Filter order
  uint8_t order;
  /// Hz
  float sampling_rate;
  /// Optional: phase-preserving filter
  bool zero_phase;
} healthcare_msgs__msg__BandPassFilter;

// Struct for a sequence of healthcare_msgs__msg__BandPassFilter.
typedef struct healthcare_msgs__msg__BandPassFilter__Sequence
{
  healthcare_msgs__msg__BandPassFilter * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BandPassFilter__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__STRUCT_H_
