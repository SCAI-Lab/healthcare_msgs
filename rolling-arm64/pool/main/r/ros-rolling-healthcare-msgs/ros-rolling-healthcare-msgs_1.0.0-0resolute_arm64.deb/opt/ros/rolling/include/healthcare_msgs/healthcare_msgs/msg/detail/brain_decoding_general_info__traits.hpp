// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingGeneralInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/brain_decoding_general_info.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__TRAITS_HPP_

#include <stdint.h>

#include <array>
#include <cstddef>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.hpp"
#include "rosidl_runtime_cpp/buffer__traits.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BrainDecodingGeneralInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: windowing_function
  {
    out << "windowing_function: ";
    rosidl_generator_traits::value_to_yaml(msg.windowing_function, out);
    out << ", ";
  }

  // member: window_size
  {
    out << "window_size: ";
    rosidl_generator_traits::value_to_yaml(msg.window_size, out);
    out << ", ";
  }

  // member: window_overlap
  {
    out << "window_overlap: ";
    rosidl_generator_traits::value_to_yaml(msg.window_overlap, out);
    out << ", ";
  }

  // member: output_method
  {
    out << "output_method: ";
    rosidl_generator_traits::value_to_yaml(msg.output_method, out);
    out << ", ";
  }

  // member: num_windows_per_output
  {
    out << "num_windows_per_output: ";
    rosidl_generator_traits::value_to_yaml(msg.num_windows_per_output, out);
    out << ", ";
  }

  // member: classifier_model_name
  {
    out << "classifier_model_name: ";
    rosidl_generator_traits::value_to_yaml(msg.classifier_model_name, out);
    out << ", ";
  }

  // member: model_version
  {
    out << "model_version: ";
    rosidl_generator_traits::value_to_yaml(msg.model_version, out);
    out << ", ";
  }

  // member: selected_preprocessing
  {
    if (msg.selected_preprocessing.size() == 0) {
      out << "selected_preprocessing: []";
    } else {
      out << "selected_preprocessing: [";
      size_t pending_items = msg.selected_preprocessing.size();
      for (auto item : msg.selected_preprocessing) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: selected_features
  {
    if (msg.selected_features.size() == 0) {
      out << "selected_features: []";
    } else {
      out << "selected_features: [";
      size_t pending_items = msg.selected_features.size();
      for (auto item : msg.selected_features) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BrainDecodingGeneralInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: windowing_function
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "windowing_function: ";
    rosidl_generator_traits::value_to_yaml(msg.windowing_function, out);
    out << "\n";
  }

  // member: window_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "window_size: ";
    rosidl_generator_traits::value_to_yaml(msg.window_size, out);
    out << "\n";
  }

  // member: window_overlap
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "window_overlap: ";
    rosidl_generator_traits::value_to_yaml(msg.window_overlap, out);
    out << "\n";
  }

  // member: output_method
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "output_method: ";
    rosidl_generator_traits::value_to_yaml(msg.output_method, out);
    out << "\n";
  }

  // member: num_windows_per_output
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "num_windows_per_output: ";
    rosidl_generator_traits::value_to_yaml(msg.num_windows_per_output, out);
    out << "\n";
  }

  // member: classifier_model_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "classifier_model_name: ";
    rosidl_generator_traits::value_to_yaml(msg.classifier_model_name, out);
    out << "\n";
  }

  // member: model_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "model_version: ";
    rosidl_generator_traits::value_to_yaml(msg.model_version, out);
    out << "\n";
  }

  // member: selected_preprocessing
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.selected_preprocessing.size() == 0) {
      out << "selected_preprocessing: []\n";
    } else {
      out << "selected_preprocessing:\n";
      for (auto item : msg.selected_preprocessing) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: selected_features
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.selected_features.size() == 0) {
      out << "selected_features: []\n";
    } else {
      out << "selected_features:\n";
      for (auto item : msg.selected_features) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BrainDecodingGeneralInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

template<typename T, std::enable_if_t<std::is_same_v<std::decay_t<T>, healthcare_msgs::msg::BrainDecodingGeneralInfo>, int> = 0>
constexpr auto as_tuple_ref(T && msg)
{
  return std::forward_as_tuple(
    std::forward<T>(msg).windowing_function,
    std::forward<T>(msg).window_size,
    std::forward<T>(msg).window_overlap,
    std::forward<T>(msg).output_method,
    std::forward<T>(msg).num_windows_per_output,
    std::forward<T>(msg).classifier_model_name,
    std::forward<T>(msg).model_version,
    std::forward<T>(msg).selected_preprocessing,
    std::forward<T>(msg).selected_features);
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

template<>
constexpr const char * data_type<healthcare_msgs::msg::BrainDecodingGeneralInfo>()
{
  return "healthcare_msgs::msg::BrainDecodingGeneralInfo";
}

template<>
constexpr const char * name<healthcare_msgs::msg::BrainDecodingGeneralInfo>()
{
  return "healthcare_msgs/msg/BrainDecodingGeneralInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::BrainDecodingGeneralInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::BrainDecodingGeneralInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::BrainDecodingGeneralInfo>
  : std::true_type {};

template<>
struct MessageTraits<healthcare_msgs::msg::BrainDecodingGeneralInfo>
{
  static constexpr std::size_t member_count = 9;
  static constexpr std::array<std::string_view, member_count> member_names = {
    "windowing_function",
    "window_size",
    "window_overlap",
    "output_method",
    "num_windows_per_output",
    "classifier_model_name",
    "model_version",
    "selected_preprocessing",
    "selected_features",
  };
};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__TRAITS_HPP_
