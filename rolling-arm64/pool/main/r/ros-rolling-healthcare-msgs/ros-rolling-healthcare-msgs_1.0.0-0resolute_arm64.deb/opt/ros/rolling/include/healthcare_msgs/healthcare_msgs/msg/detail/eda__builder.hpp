// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EDA.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/eda.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/eda__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EDA_signal_quality
{
public:
  explicit Init_EDA_signal_quality(::healthcare_msgs::msg::EDA & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EDA signal_quality(::healthcare_msgs::msg::EDA::_signal_quality_type arg)
  {
    msg_.signal_quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EDA msg_;
};

class Init_EDA_eda
{
public:
  explicit Init_EDA_eda(::healthcare_msgs::msg::EDA & msg)
  : msg_(msg)
  {}
  Init_EDA_signal_quality eda(::healthcare_msgs::msg::EDA::_eda_type arg)
  {
    msg_.eda = std::move(arg);
    return Init_EDA_signal_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::EDA msg_;
};

class Init_EDA_scr
{
public:
  explicit Init_EDA_scr(::healthcare_msgs::msg::EDA & msg)
  : msg_(msg)
  {}
  Init_EDA_eda scr(::healthcare_msgs::msg::EDA::_scr_type arg)
  {
    msg_.scr = std::move(arg);
    return Init_EDA_eda(msg_);
  }

private:
  ::healthcare_msgs::msg::EDA msg_;
};

class Init_EDA_scl
{
public:
  explicit Init_EDA_scl(::healthcare_msgs::msg::EDA & msg)
  : msg_(msg)
  {}
  Init_EDA_scr scl(::healthcare_msgs::msg::EDA::_scl_type arg)
  {
    msg_.scl = std::move(arg);
    return Init_EDA_scr(msg_);
  }

private:
  ::healthcare_msgs::msg::EDA msg_;
};

class Init_EDA_sample_size
{
public:
  explicit Init_EDA_sample_size(::healthcare_msgs::msg::EDA & msg)
  : msg_(msg)
  {}
  Init_EDA_scl sample_size(::healthcare_msgs::msg::EDA::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_EDA_scl(msg_);
  }

private:
  ::healthcare_msgs::msg::EDA msg_;
};

class Init_EDA_session_id
{
public:
  explicit Init_EDA_session_id(::healthcare_msgs::msg::EDA & msg)
  : msg_(msg)
  {}
  Init_EDA_sample_size session_id(::healthcare_msgs::msg::EDA::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_EDA_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::EDA msg_;
};

class Init_EDA_header
{
public:
  Init_EDA_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EDA_session_id header(::healthcare_msgs::msg::EDA::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_EDA_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::EDA msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EDA>()
{
  return healthcare_msgs::msg::builder::Init_EDA_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA__BUILDER_HPP_
