// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BandPassFilter.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "healthcare_msgs/msg/band_pass_filter.hpp"


#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/band_pass_filter__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BandPassFilter_zero_phase
{
public:
  explicit Init_BandPassFilter_zero_phase(::healthcare_msgs::msg::BandPassFilter & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BandPassFilter zero_phase(::healthcare_msgs::msg::BandPassFilter::_zero_phase_type arg)
  {
    msg_.zero_phase = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BandPassFilter msg_;
};

class Init_BandPassFilter_sampling_rate
{
public:
  explicit Init_BandPassFilter_sampling_rate(::healthcare_msgs::msg::BandPassFilter & msg)
  : msg_(msg)
  {}
  Init_BandPassFilter_zero_phase sampling_rate(::healthcare_msgs::msg::BandPassFilter::_sampling_rate_type arg)
  {
    msg_.sampling_rate = std::move(arg);
    return Init_BandPassFilter_zero_phase(msg_);
  }

private:
  ::healthcare_msgs::msg::BandPassFilter msg_;
};

class Init_BandPassFilter_order
{
public:
  explicit Init_BandPassFilter_order(::healthcare_msgs::msg::BandPassFilter & msg)
  : msg_(msg)
  {}
  Init_BandPassFilter_sampling_rate order(::healthcare_msgs::msg::BandPassFilter::_order_type arg)
  {
    msg_.order = std::move(arg);
    return Init_BandPassFilter_sampling_rate(msg_);
  }

private:
  ::healthcare_msgs::msg::BandPassFilter msg_;
};

class Init_BandPassFilter_high_cutoff_frequency
{
public:
  explicit Init_BandPassFilter_high_cutoff_frequency(::healthcare_msgs::msg::BandPassFilter & msg)
  : msg_(msg)
  {}
  Init_BandPassFilter_order high_cutoff_frequency(::healthcare_msgs::msg::BandPassFilter::_high_cutoff_frequency_type arg)
  {
    msg_.high_cutoff_frequency = std::move(arg);
    return Init_BandPassFilter_order(msg_);
  }

private:
  ::healthcare_msgs::msg::BandPassFilter msg_;
};

class Init_BandPassFilter_low_cutoff_frequency
{
public:
  explicit Init_BandPassFilter_low_cutoff_frequency(::healthcare_msgs::msg::BandPassFilter & msg)
  : msg_(msg)
  {}
  Init_BandPassFilter_high_cutoff_frequency low_cutoff_frequency(::healthcare_msgs::msg::BandPassFilter::_low_cutoff_frequency_type arg)
  {
    msg_.low_cutoff_frequency = std::move(arg);
    return Init_BandPassFilter_high_cutoff_frequency(msg_);
  }

private:
  ::healthcare_msgs::msg::BandPassFilter msg_;
};

class Init_BandPassFilter_header
{
public:
  Init_BandPassFilter_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BandPassFilter_low_cutoff_frequency header(::healthcare_msgs::msg::BandPassFilter::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_BandPassFilter_low_cutoff_frequency(msg_);
  }

private:
  ::healthcare_msgs::msg::BandPassFilter msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BandPassFilter>()
{
  return healthcare_msgs::msg::builder::Init_BandPassFilter_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__BUILDER_HPP_
