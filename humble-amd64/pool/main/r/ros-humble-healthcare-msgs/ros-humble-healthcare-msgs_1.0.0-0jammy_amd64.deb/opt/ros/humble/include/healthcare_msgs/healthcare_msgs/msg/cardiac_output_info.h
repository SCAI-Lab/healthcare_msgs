// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/CardiacOutputInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__CARDIAC_OUTPUT_INFO_H_
#define HEALTHCARE_MSGS__MSG__CARDIAC_OUTPUT_INFO_H_

#include "healthcare_msgs/msg/detail/cardiac_output_info__struct.h"
#include "healthcare_msgs/msg/detail/cardiac_output_info__functions.h"
#include "healthcare_msgs/msg/detail/cardiac_output_info__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__CARDIAC_OUTPUT_INFO_H_
