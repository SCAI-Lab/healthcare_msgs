// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/FilterBase.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/filter_base__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `filters`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `band_pass_filter`
#include "healthcare_msgs/msg/detail/band_pass_filter__functions.h"
// Member `butter_worth_filter`
#include "healthcare_msgs/msg/detail/butter_worth_filter__functions.h"
// Member `high_pass_filter`
#include "healthcare_msgs/msg/detail/high_pass_filter__functions.h"
// Member `kalman_filter`
#include "healthcare_msgs/msg/detail/kalman_filter__functions.h"
// Member `low_pass_filter`
#include "healthcare_msgs/msg/detail/low_pass_filter__functions.h"
// Member `moving_average_filter`
#include "healthcare_msgs/msg/detail/moving_average_filter__functions.h"
// Member `notch_filter`
#include "healthcare_msgs/msg/detail/notch_filter__functions.h"
// Member `savitzky_golay_filter`
#include "healthcare_msgs/msg/detail/savitzky_golay_filter__functions.h"

bool
healthcare_msgs__msg__FilterBase__init(healthcare_msgs__msg__FilterBase * msg)
{
  if (!msg) {
    return false;
  }
  // filters
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->filters, 0)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // band_pass_filter
  if (!healthcare_msgs__msg__BandPassFilter__init(&msg->band_pass_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // butter_worth_filter
  if (!healthcare_msgs__msg__ButterWorthFilter__init(&msg->butter_worth_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // high_pass_filter
  if (!healthcare_msgs__msg__HighPassFilter__init(&msg->high_pass_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // kalman_filter
  if (!healthcare_msgs__msg__KalmanFilter__init(&msg->kalman_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // low_pass_filter
  if (!healthcare_msgs__msg__LowPassFilter__init(&msg->low_pass_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // moving_average_filter
  if (!healthcare_msgs__msg__MovingAverageFilter__init(&msg->moving_average_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // notch_filter
  if (!healthcare_msgs__msg__NotchFilter__init(&msg->notch_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  // savitzky_golay_filter
  if (!healthcare_msgs__msg__SavitzkyGolayFilter__init(&msg->savitzky_golay_filter)) {
    healthcare_msgs__msg__FilterBase__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__FilterBase__fini(healthcare_msgs__msg__FilterBase * msg)
{
  if (!msg) {
    return;
  }
  // filters
  rosidl_runtime_c__uint8__Sequence__fini(&msg->filters);
  // band_pass_filter
  healthcare_msgs__msg__BandPassFilter__fini(&msg->band_pass_filter);
  // butter_worth_filter
  healthcare_msgs__msg__ButterWorthFilter__fini(&msg->butter_worth_filter);
  // high_pass_filter
  healthcare_msgs__msg__HighPassFilter__fini(&msg->high_pass_filter);
  // kalman_filter
  healthcare_msgs__msg__KalmanFilter__fini(&msg->kalman_filter);
  // low_pass_filter
  healthcare_msgs__msg__LowPassFilter__fini(&msg->low_pass_filter);
  // moving_average_filter
  healthcare_msgs__msg__MovingAverageFilter__fini(&msg->moving_average_filter);
  // notch_filter
  healthcare_msgs__msg__NotchFilter__fini(&msg->notch_filter);
  // savitzky_golay_filter
  healthcare_msgs__msg__SavitzkyGolayFilter__fini(&msg->savitzky_golay_filter);
}

bool
healthcare_msgs__msg__FilterBase__are_equal(const healthcare_msgs__msg__FilterBase * lhs, const healthcare_msgs__msg__FilterBase * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // filters
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->filters), &(rhs->filters)))
  {
    return false;
  }
  // band_pass_filter
  if (!healthcare_msgs__msg__BandPassFilter__are_equal(
      &(lhs->band_pass_filter), &(rhs->band_pass_filter)))
  {
    return false;
  }
  // butter_worth_filter
  if (!healthcare_msgs__msg__ButterWorthFilter__are_equal(
      &(lhs->butter_worth_filter), &(rhs->butter_worth_filter)))
  {
    return false;
  }
  // high_pass_filter
  if (!healthcare_msgs__msg__HighPassFilter__are_equal(
      &(lhs->high_pass_filter), &(rhs->high_pass_filter)))
  {
    return false;
  }
  // kalman_filter
  if (!healthcare_msgs__msg__KalmanFilter__are_equal(
      &(lhs->kalman_filter), &(rhs->kalman_filter)))
  {
    return false;
  }
  // low_pass_filter
  if (!healthcare_msgs__msg__LowPassFilter__are_equal(
      &(lhs->low_pass_filter), &(rhs->low_pass_filter)))
  {
    return false;
  }
  // moving_average_filter
  if (!healthcare_msgs__msg__MovingAverageFilter__are_equal(
      &(lhs->moving_average_filter), &(rhs->moving_average_filter)))
  {
    return false;
  }
  // notch_filter
  if (!healthcare_msgs__msg__NotchFilter__are_equal(
      &(lhs->notch_filter), &(rhs->notch_filter)))
  {
    return false;
  }
  // savitzky_golay_filter
  if (!healthcare_msgs__msg__SavitzkyGolayFilter__are_equal(
      &(lhs->savitzky_golay_filter), &(rhs->savitzky_golay_filter)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__FilterBase__copy(
  const healthcare_msgs__msg__FilterBase * input,
  healthcare_msgs__msg__FilterBase * output)
{
  if (!input || !output) {
    return false;
  }
  // filters
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->filters), &(output->filters)))
  {
    return false;
  }
  // band_pass_filter
  if (!healthcare_msgs__msg__BandPassFilter__copy(
      &(input->band_pass_filter), &(output->band_pass_filter)))
  {
    return false;
  }
  // butter_worth_filter
  if (!healthcare_msgs__msg__ButterWorthFilter__copy(
      &(input->butter_worth_filter), &(output->butter_worth_filter)))
  {
    return false;
  }
  // high_pass_filter
  if (!healthcare_msgs__msg__HighPassFilter__copy(
      &(input->high_pass_filter), &(output->high_pass_filter)))
  {
    return false;
  }
  // kalman_filter
  if (!healthcare_msgs__msg__KalmanFilter__copy(
      &(input->kalman_filter), &(output->kalman_filter)))
  {
    return false;
  }
  // low_pass_filter
  if (!healthcare_msgs__msg__LowPassFilter__copy(
      &(input->low_pass_filter), &(output->low_pass_filter)))
  {
    return false;
  }
  // moving_average_filter
  if (!healthcare_msgs__msg__MovingAverageFilter__copy(
      &(input->moving_average_filter), &(output->moving_average_filter)))
  {
    return false;
  }
  // notch_filter
  if (!healthcare_msgs__msg__NotchFilter__copy(
      &(input->notch_filter), &(output->notch_filter)))
  {
    return false;
  }
  // savitzky_golay_filter
  if (!healthcare_msgs__msg__SavitzkyGolayFilter__copy(
      &(input->savitzky_golay_filter), &(output->savitzky_golay_filter)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__FilterBase *
healthcare_msgs__msg__FilterBase__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__FilterBase * msg = (healthcare_msgs__msg__FilterBase *)allocator.allocate(sizeof(healthcare_msgs__msg__FilterBase), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__FilterBase));
  bool success = healthcare_msgs__msg__FilterBase__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__FilterBase__destroy(healthcare_msgs__msg__FilterBase * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__FilterBase__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__FilterBase__Sequence__init(healthcare_msgs__msg__FilterBase__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__FilterBase * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__FilterBase *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__FilterBase), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__FilterBase__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__FilterBase__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__FilterBase__Sequence__fini(healthcare_msgs__msg__FilterBase__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__FilterBase__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__FilterBase__Sequence *
healthcare_msgs__msg__FilterBase__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__FilterBase__Sequence * array = (healthcare_msgs__msg__FilterBase__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__FilterBase__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__FilterBase__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__FilterBase__Sequence__destroy(healthcare_msgs__msg__FilterBase__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__FilterBase__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__FilterBase__Sequence__are_equal(const healthcare_msgs__msg__FilterBase__Sequence * lhs, const healthcare_msgs__msg__FilterBase__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__FilterBase__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__FilterBase__Sequence__copy(
  const healthcare_msgs__msg__FilterBase__Sequence * input,
  healthcare_msgs__msg__FilterBase__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__FilterBase);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__FilterBase * data =
      (healthcare_msgs__msg__FilterBase *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__FilterBase__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__FilterBase__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__FilterBase__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
