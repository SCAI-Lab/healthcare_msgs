// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__ADL_MODEL_CLASSIFICATION_RESULT_H_
#define HEALTHCARE_MSGS__MSG__ADL_MODEL_CLASSIFICATION_RESULT_H_

#include "healthcare_msgs/msg/detail/adl_model_classification_result__struct.h"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__functions.h"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__ADL_MODEL_CLASSIFICATION_RESULT_H_
