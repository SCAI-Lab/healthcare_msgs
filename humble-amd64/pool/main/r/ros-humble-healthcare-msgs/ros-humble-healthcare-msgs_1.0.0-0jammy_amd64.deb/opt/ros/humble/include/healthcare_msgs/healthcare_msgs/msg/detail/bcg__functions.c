// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/BCG.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/bcg__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `session_id`
#include "rosidl_runtime_c/string_functions.h"
// Member `bcg`
// Member `signal_quality`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
healthcare_msgs__msg__BCG__init(healthcare_msgs__msg__BCG * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    healthcare_msgs__msg__BCG__fini(msg);
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__init(&msg->session_id)) {
    healthcare_msgs__msg__BCG__fini(msg);
    return false;
  }
  // sample_size
  // bcg
  if (!rosidl_runtime_c__float__Sequence__init(&msg->bcg, 0)) {
    healthcare_msgs__msg__BCG__fini(msg);
    return false;
  }
  // signal_quality
  if (!rosidl_runtime_c__float__Sequence__init(&msg->signal_quality, 0)) {
    healthcare_msgs__msg__BCG__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__BCG__fini(healthcare_msgs__msg__BCG * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // session_id
  rosidl_runtime_c__String__fini(&msg->session_id);
  // sample_size
  // bcg
  rosidl_runtime_c__float__Sequence__fini(&msg->bcg);
  // signal_quality
  rosidl_runtime_c__float__Sequence__fini(&msg->signal_quality);
}

bool
healthcare_msgs__msg__BCG__are_equal(const healthcare_msgs__msg__BCG * lhs, const healthcare_msgs__msg__BCG * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->session_id), &(rhs->session_id)))
  {
    return false;
  }
  // sample_size
  if (lhs->sample_size != rhs->sample_size) {
    return false;
  }
  // bcg
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->bcg), &(rhs->bcg)))
  {
    return false;
  }
  // signal_quality
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->signal_quality), &(rhs->signal_quality)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__BCG__copy(
  const healthcare_msgs__msg__BCG * input,
  healthcare_msgs__msg__BCG * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__copy(
      &(input->session_id), &(output->session_id)))
  {
    return false;
  }
  // sample_size
  output->sample_size = input->sample_size;
  // bcg
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->bcg), &(output->bcg)))
  {
    return false;
  }
  // signal_quality
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->signal_quality), &(output->signal_quality)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__BCG *
healthcare_msgs__msg__BCG__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BCG * msg = (healthcare_msgs__msg__BCG *)allocator.allocate(sizeof(healthcare_msgs__msg__BCG), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__BCG));
  bool success = healthcare_msgs__msg__BCG__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__BCG__destroy(healthcare_msgs__msg__BCG * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__BCG__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__BCG__Sequence__init(healthcare_msgs__msg__BCG__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BCG * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__BCG *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__BCG), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__BCG__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__BCG__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__BCG__Sequence__fini(healthcare_msgs__msg__BCG__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__BCG__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__BCG__Sequence *
healthcare_msgs__msg__BCG__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__BCG__Sequence * array = (healthcare_msgs__msg__BCG__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__BCG__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__BCG__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__BCG__Sequence__destroy(healthcare_msgs__msg__BCG__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__BCG__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__BCG__Sequence__are_equal(const healthcare_msgs__msg__BCG__Sequence * lhs, const healthcare_msgs__msg__BCG__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__BCG__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__BCG__Sequence__copy(
  const healthcare_msgs__msg__BCG__Sequence * input,
  healthcare_msgs__msg__BCG__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__BCG);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__BCG * data =
      (healthcare_msgs__msg__BCG *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__BCG__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__BCG__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__BCG__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
