// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/HeartRateInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__HeartRateInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_BPM'.
/**
  * Beats per minute
 */
enum
{
  healthcare_msgs__msg__HeartRateInfo__UNIT_BPM = 1
};

/// Constant 'UNIT_HZ'.
/**
  * Hertz (e.g., for RR intervals or frequency domain HR)
 */
enum
{
  healthcare_msgs__msg__HeartRateInfo__UNIT_HZ = 2
};

/// Constant 'UNIT_CUSTOM'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__UNIT_CUSTOM = 255
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Sensor Placement Enum
 */
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_WRIST'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_WRIST = 1
};

/// Constant 'PLACEMENT_CHEST'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_CHEST = 2
};

/// Constant 'PLACEMENT_FINGER'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_FINGER = 3
};

/// Constant 'PLACEMENT_EARLOBE'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_EARLOBE = 4
};

/// Constant 'PLACEMENT_FOREHEAD'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_FOREHEAD = 5
};

/// Constant 'PLACEMENT_ANKLE'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_ANKLE = 6
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'METHOD_UNKNOWN'.
/**
  * Measurement Method Enum
 */
enum
{
  healthcare_msgs__msg__HeartRateInfo__METHOD_UNKNOWN = 0
};

/// Constant 'METHOD_PPG'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__METHOD_PPG = 1
};

/// Constant 'METHOD_ECG'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__METHOD_ECG = 2
};

/// Constant 'METHOD_BCG'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__METHOD_BCG = 3
};

/// Constant 'METHOD_RADAR'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__METHOD_RADAR = 4
};

/// Constant 'METHOD_CUSTOM'.
enum
{
  healthcare_msgs__msg__HeartRateInfo__METHOD_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'sensor_placement'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/HeartRateInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__HeartRateInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  /// Usually UNIT_BPM
  uint8_t unit;
  rosidl_runtime_c__uint8__Sequence sensor_placement;
  uint8_t measurement_method;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__HeartRateInfo;

// Struct for a sequence of healthcare_msgs__msg__HeartRateInfo.
typedef struct healthcare_msgs__msg__HeartRateInfo__Sequence
{
  healthcare_msgs__msg__HeartRateInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__HeartRateInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_INFO__STRUCT_H_
