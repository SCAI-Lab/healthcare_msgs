// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingERPInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BrainDecodingERPInfo_comments
{
public:
  explicit Init_BrainDecodingERPInfo_comments(::healthcare_msgs::msg::BrainDecodingERPInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BrainDecodingERPInfo comments(::healthcare_msgs::msg::BrainDecodingERPInfo::_comments_type arg)
  {
    msg_.comments = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingERPInfo msg_;
};

class Init_BrainDecodingERPInfo_erp_features
{
public:
  explicit Init_BrainDecodingERPInfo_erp_features(::healthcare_msgs::msg::BrainDecodingERPInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingERPInfo_comments erp_features(::healthcare_msgs::msg::BrainDecodingERPInfo::_erp_features_type arg)
  {
    msg_.erp_features = std::move(arg);
    return Init_BrainDecodingERPInfo_comments(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingERPInfo msg_;
};

class Init_BrainDecodingERPInfo_brain_decoding_general_info
{
public:
  explicit Init_BrainDecodingERPInfo_brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingERPInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingERPInfo_erp_features brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingERPInfo::_brain_decoding_general_info_type arg)
  {
    msg_.brain_decoding_general_info = std::move(arg);
    return Init_BrainDecodingERPInfo_erp_features(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingERPInfo msg_;
};

class Init_BrainDecodingERPInfo_device_info
{
public:
  Init_BrainDecodingERPInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BrainDecodingERPInfo_brain_decoding_general_info device_info(::healthcare_msgs::msg::BrainDecodingERPInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_BrainDecodingERPInfo_brain_decoding_general_info(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingERPInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BrainDecodingERPInfo>()
{
  return healthcare_msgs::msg::builder::Init_BrainDecodingERPInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_ERP_INFO__BUILDER_HPP_
