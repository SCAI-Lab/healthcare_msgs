// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/adl_model_classification_result__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `device_serial_number`
// Member `glossary`
// Member `model_type`
// Member `model_version`
#include "rosidl_runtime_c/string_functions.h"

bool
healthcare_msgs__msg__ADLModelClassificationResult__init(healthcare_msgs__msg__ADLModelClassificationResult * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    healthcare_msgs__msg__ADLModelClassificationResult__fini(msg);
    return false;
  }
  // device_serial_number
  if (!rosidl_runtime_c__String__Sequence__init(&msg->device_serial_number, 0)) {
    healthcare_msgs__msg__ADLModelClassificationResult__fini(msg);
    return false;
  }
  // glossary
  if (!rosidl_runtime_c__String__Sequence__init(&msg->glossary, 0)) {
    healthcare_msgs__msg__ADLModelClassificationResult__fini(msg);
    return false;
  }
  // class_amount
  // model_type
  if (!rosidl_runtime_c__String__Sequence__init(&msg->model_type, 0)) {
    healthcare_msgs__msg__ADLModelClassificationResult__fini(msg);
    return false;
  }
  // model_version
  if (!rosidl_runtime_c__String__Sequence__init(&msg->model_version, 0)) {
    healthcare_msgs__msg__ADLModelClassificationResult__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__ADLModelClassificationResult__fini(healthcare_msgs__msg__ADLModelClassificationResult * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // device_serial_number
  rosidl_runtime_c__String__Sequence__fini(&msg->device_serial_number);
  // glossary
  rosidl_runtime_c__String__Sequence__fini(&msg->glossary);
  // class_amount
  // model_type
  rosidl_runtime_c__String__Sequence__fini(&msg->model_type);
  // model_version
  rosidl_runtime_c__String__Sequence__fini(&msg->model_version);
}

bool
healthcare_msgs__msg__ADLModelClassificationResult__are_equal(const healthcare_msgs__msg__ADLModelClassificationResult * lhs, const healthcare_msgs__msg__ADLModelClassificationResult * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // device_serial_number
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->device_serial_number), &(rhs->device_serial_number)))
  {
    return false;
  }
  // glossary
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->glossary), &(rhs->glossary)))
  {
    return false;
  }
  // class_amount
  if (lhs->class_amount != rhs->class_amount) {
    return false;
  }
  // model_type
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->model_type), &(rhs->model_type)))
  {
    return false;
  }
  // model_version
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->model_version), &(rhs->model_version)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__ADLModelClassificationResult__copy(
  const healthcare_msgs__msg__ADLModelClassificationResult * input,
  healthcare_msgs__msg__ADLModelClassificationResult * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // device_serial_number
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->device_serial_number), &(output->device_serial_number)))
  {
    return false;
  }
  // glossary
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->glossary), &(output->glossary)))
  {
    return false;
  }
  // class_amount
  output->class_amount = input->class_amount;
  // model_type
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->model_type), &(output->model_type)))
  {
    return false;
  }
  // model_version
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->model_version), &(output->model_version)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__ADLModelClassificationResult *
healthcare_msgs__msg__ADLModelClassificationResult__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__ADLModelClassificationResult * msg = (healthcare_msgs__msg__ADLModelClassificationResult *)allocator.allocate(sizeof(healthcare_msgs__msg__ADLModelClassificationResult), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__ADLModelClassificationResult));
  bool success = healthcare_msgs__msg__ADLModelClassificationResult__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__ADLModelClassificationResult__destroy(healthcare_msgs__msg__ADLModelClassificationResult * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__ADLModelClassificationResult__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__ADLModelClassificationResult__Sequence__init(healthcare_msgs__msg__ADLModelClassificationResult__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__ADLModelClassificationResult * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__ADLModelClassificationResult *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__ADLModelClassificationResult), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__ADLModelClassificationResult__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__ADLModelClassificationResult__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__ADLModelClassificationResult__Sequence__fini(healthcare_msgs__msg__ADLModelClassificationResult__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__ADLModelClassificationResult__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__ADLModelClassificationResult__Sequence *
healthcare_msgs__msg__ADLModelClassificationResult__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__ADLModelClassificationResult__Sequence * array = (healthcare_msgs__msg__ADLModelClassificationResult__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__ADLModelClassificationResult__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__ADLModelClassificationResult__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__ADLModelClassificationResult__Sequence__destroy(healthcare_msgs__msg__ADLModelClassificationResult__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__ADLModelClassificationResult__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__ADLModelClassificationResult__Sequence__are_equal(const healthcare_msgs__msg__ADLModelClassificationResult__Sequence * lhs, const healthcare_msgs__msg__ADLModelClassificationResult__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__ADLModelClassificationResult__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__ADLModelClassificationResult__Sequence__copy(
  const healthcare_msgs__msg__ADLModelClassificationResult__Sequence * input,
  healthcare_msgs__msg__ADLModelClassificationResult__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__ADLModelClassificationResult);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__ADLModelClassificationResult * data =
      (healthcare_msgs__msg__ADLModelClassificationResult *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__ADLModelClassificationResult__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__ADLModelClassificationResult__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__ADLModelClassificationResult__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
