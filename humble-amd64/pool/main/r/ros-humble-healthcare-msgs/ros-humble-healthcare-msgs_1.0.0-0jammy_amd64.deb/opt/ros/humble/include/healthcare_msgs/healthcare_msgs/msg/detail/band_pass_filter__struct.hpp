// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/BandPassFilter.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__BandPassFilter __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__BandPassFilter __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BandPassFilter_
{
  using Type = BandPassFilter_<ContainerAllocator>;

  explicit BandPassFilter_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->low_cutoff_frequency = 0.0f;
      this->high_cutoff_frequency = 0.0f;
      this->order = 0;
      this->sampling_rate = 0.0f;
      this->zero_phase = false;
    }
  }

  explicit BandPassFilter_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->low_cutoff_frequency = 0.0f;
      this->high_cutoff_frequency = 0.0f;
      this->order = 0;
      this->sampling_rate = 0.0f;
      this->zero_phase = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _low_cutoff_frequency_type =
    float;
  _low_cutoff_frequency_type low_cutoff_frequency;
  using _high_cutoff_frequency_type =
    float;
  _high_cutoff_frequency_type high_cutoff_frequency;
  using _order_type =
    uint8_t;
  _order_type order;
  using _sampling_rate_type =
    float;
  _sampling_rate_type sampling_rate;
  using _zero_phase_type =
    bool;
  _zero_phase_type zero_phase;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__low_cutoff_frequency(
    const float & _arg)
  {
    this->low_cutoff_frequency = _arg;
    return *this;
  }
  Type & set__high_cutoff_frequency(
    const float & _arg)
  {
    this->high_cutoff_frequency = _arg;
    return *this;
  }
  Type & set__order(
    const uint8_t & _arg)
  {
    this->order = _arg;
    return *this;
  }
  Type & set__sampling_rate(
    const float & _arg)
  {
    this->sampling_rate = _arg;
    return *this;
  }
  Type & set__zero_phase(
    const bool & _arg)
  {
    this->zero_phase = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::BandPassFilter_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::BandPassFilter_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BandPassFilter_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BandPassFilter_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__BandPassFilter
    std::shared_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__BandPassFilter
    std::shared_ptr<healthcare_msgs::msg::BandPassFilter_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BandPassFilter_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->low_cutoff_frequency != other.low_cutoff_frequency) {
      return false;
    }
    if (this->high_cutoff_frequency != other.high_cutoff_frequency) {
      return false;
    }
    if (this->order != other.order) {
      return false;
    }
    if (this->sampling_rate != other.sampling_rate) {
      return false;
    }
    if (this->zero_phase != other.zero_phase) {
      return false;
    }
    return true;
  }
  bool operator!=(const BandPassFilter_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BandPassFilter_

// alias to use template instance with default allocator
using BandPassFilter =
  healthcare_msgs::msg::BandPassFilter_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BAND_PASS_FILTER__STRUCT_HPP_
