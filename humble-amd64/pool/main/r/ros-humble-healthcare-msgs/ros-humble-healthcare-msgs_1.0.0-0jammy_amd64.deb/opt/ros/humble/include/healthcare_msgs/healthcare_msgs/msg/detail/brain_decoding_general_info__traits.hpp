// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingGeneralInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BrainDecodingGeneralInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: windowing_function
  {
    out << "windowing_function: ";
    rosidl_generator_traits::value_to_yaml(msg.windowing_function, out);
    out << ", ";
  }

  // member: window_size
  {
    out << "window_size: ";
    rosidl_generator_traits::value_to_yaml(msg.window_size, out);
    out << ", ";
  }

  // member: window_overlap
  {
    out << "window_overlap: ";
    rosidl_generator_traits::value_to_yaml(msg.window_overlap, out);
    out << ", ";
  }

  // member: output_method
  {
    out << "output_method: ";
    rosidl_generator_traits::value_to_yaml(msg.output_method, out);
    out << ", ";
  }

  // member: num_windows_per_output
  {
    out << "num_windows_per_output: ";
    rosidl_generator_traits::value_to_yaml(msg.num_windows_per_output, out);
    out << ", ";
  }

  // member: classifier_model_name
  {
    out << "classifier_model_name: ";
    rosidl_generator_traits::value_to_yaml(msg.classifier_model_name, out);
    out << ", ";
  }

  // member: model_version
  {
    out << "model_version: ";
    rosidl_generator_traits::value_to_yaml(msg.model_version, out);
    out << ", ";
  }

  // member: selected_preprocessing
  {
    if (msg.selected_preprocessing.size() == 0) {
      out << "selected_preprocessing: []";
    } else {
      out << "selected_preprocessing: [";
      size_t pending_items = msg.selected_preprocessing.size();
      for (auto item : msg.selected_preprocessing) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: selected_features
  {
    if (msg.selected_features.size() == 0) {
      out << "selected_features: []";
    } else {
      out << "selected_features: [";
      size_t pending_items = msg.selected_features.size();
      for (auto item : msg.selected_features) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BrainDecodingGeneralInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: windowing_function
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "windowing_function: ";
    rosidl_generator_traits::value_to_yaml(msg.windowing_function, out);
    out << "\n";
  }

  // member: window_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "window_size: ";
    rosidl_generator_traits::value_to_yaml(msg.window_size, out);
    out << "\n";
  }

  // member: window_overlap
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "window_overlap: ";
    rosidl_generator_traits::value_to_yaml(msg.window_overlap, out);
    out << "\n";
  }

  // member: output_method
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "output_method: ";
    rosidl_generator_traits::value_to_yaml(msg.output_method, out);
    out << "\n";
  }

  // member: num_windows_per_output
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "num_windows_per_output: ";
    rosidl_generator_traits::value_to_yaml(msg.num_windows_per_output, out);
    out << "\n";
  }

  // member: classifier_model_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "classifier_model_name: ";
    rosidl_generator_traits::value_to_yaml(msg.classifier_model_name, out);
    out << "\n";
  }

  // member: model_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "model_version: ";
    rosidl_generator_traits::value_to_yaml(msg.model_version, out);
    out << "\n";
  }

  // member: selected_preprocessing
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.selected_preprocessing.size() == 0) {
      out << "selected_preprocessing: []\n";
    } else {
      out << "selected_preprocessing:\n";
      for (auto item : msg.selected_preprocessing) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: selected_features
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.selected_features.size() == 0) {
      out << "selected_features: []\n";
    } else {
      out << "selected_features:\n";
      for (auto item : msg.selected_features) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BrainDecodingGeneralInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::BrainDecodingGeneralInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::BrainDecodingGeneralInfo>()
{
  return "healthcare_msgs::msg::BrainDecodingGeneralInfo";
}

template<>
inline const char * name<healthcare_msgs::msg::BrainDecodingGeneralInfo>()
{
  return "healthcare_msgs/msg/BrainDecodingGeneralInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::BrainDecodingGeneralInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::BrainDecodingGeneralInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::BrainDecodingGeneralInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__TRAITS_HPP_
