// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/FilterBase.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'band_pass_filter'
#include "healthcare_msgs/msg/detail/band_pass_filter__struct.hpp"
// Member 'butter_worth_filter'
#include "healthcare_msgs/msg/detail/butter_worth_filter__struct.hpp"
// Member 'high_pass_filter'
#include "healthcare_msgs/msg/detail/high_pass_filter__struct.hpp"
// Member 'kalman_filter'
#include "healthcare_msgs/msg/detail/kalman_filter__struct.hpp"
// Member 'low_pass_filter'
#include "healthcare_msgs/msg/detail/low_pass_filter__struct.hpp"
// Member 'moving_average_filter'
#include "healthcare_msgs/msg/detail/moving_average_filter__struct.hpp"
// Member 'notch_filter'
#include "healthcare_msgs/msg/detail/notch_filter__struct.hpp"
// Member 'savitzky_golay_filter'
#include "healthcare_msgs/msg/detail/savitzky_golay_filter__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__FilterBase __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__FilterBase __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct FilterBase_
{
  using Type = FilterBase_<ContainerAllocator>;

  explicit FilterBase_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : band_pass_filter(_init),
    butter_worth_filter(_init),
    high_pass_filter(_init),
    kalman_filter(_init),
    low_pass_filter(_init),
    moving_average_filter(_init),
    notch_filter(_init),
    savitzky_golay_filter(_init)
  {
    (void)_init;
  }

  explicit FilterBase_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : band_pass_filter(_alloc, _init),
    butter_worth_filter(_alloc, _init),
    high_pass_filter(_alloc, _init),
    kalman_filter(_alloc, _init),
    low_pass_filter(_alloc, _init),
    moving_average_filter(_alloc, _init),
    notch_filter(_alloc, _init),
    savitzky_golay_filter(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _filters_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _filters_type filters;
  using _band_pass_filter_type =
    healthcare_msgs::msg::BandPassFilter_<ContainerAllocator>;
  _band_pass_filter_type band_pass_filter;
  using _butter_worth_filter_type =
    healthcare_msgs::msg::ButterWorthFilter_<ContainerAllocator>;
  _butter_worth_filter_type butter_worth_filter;
  using _high_pass_filter_type =
    healthcare_msgs::msg::HighPassFilter_<ContainerAllocator>;
  _high_pass_filter_type high_pass_filter;
  using _kalman_filter_type =
    healthcare_msgs::msg::KalmanFilter_<ContainerAllocator>;
  _kalman_filter_type kalman_filter;
  using _low_pass_filter_type =
    healthcare_msgs::msg::LowPassFilter_<ContainerAllocator>;
  _low_pass_filter_type low_pass_filter;
  using _moving_average_filter_type =
    healthcare_msgs::msg::MovingAverageFilter_<ContainerAllocator>;
  _moving_average_filter_type moving_average_filter;
  using _notch_filter_type =
    healthcare_msgs::msg::NotchFilter_<ContainerAllocator>;
  _notch_filter_type notch_filter;
  using _savitzky_golay_filter_type =
    healthcare_msgs::msg::SavitzkyGolayFilter_<ContainerAllocator>;
  _savitzky_golay_filter_type savitzky_golay_filter;

  // setters for named parameter idiom
  Type & set__filters(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->filters = _arg;
    return *this;
  }
  Type & set__band_pass_filter(
    const healthcare_msgs::msg::BandPassFilter_<ContainerAllocator> & _arg)
  {
    this->band_pass_filter = _arg;
    return *this;
  }
  Type & set__butter_worth_filter(
    const healthcare_msgs::msg::ButterWorthFilter_<ContainerAllocator> & _arg)
  {
    this->butter_worth_filter = _arg;
    return *this;
  }
  Type & set__high_pass_filter(
    const healthcare_msgs::msg::HighPassFilter_<ContainerAllocator> & _arg)
  {
    this->high_pass_filter = _arg;
    return *this;
  }
  Type & set__kalman_filter(
    const healthcare_msgs::msg::KalmanFilter_<ContainerAllocator> & _arg)
  {
    this->kalman_filter = _arg;
    return *this;
  }
  Type & set__low_pass_filter(
    const healthcare_msgs::msg::LowPassFilter_<ContainerAllocator> & _arg)
  {
    this->low_pass_filter = _arg;
    return *this;
  }
  Type & set__moving_average_filter(
    const healthcare_msgs::msg::MovingAverageFilter_<ContainerAllocator> & _arg)
  {
    this->moving_average_filter = _arg;
    return *this;
  }
  Type & set__notch_filter(
    const healthcare_msgs::msg::NotchFilter_<ContainerAllocator> & _arg)
  {
    this->notch_filter = _arg;
    return *this;
  }
  Type & set__savitzky_golay_filter(
    const healthcare_msgs::msg::SavitzkyGolayFilter_<ContainerAllocator> & _arg)
  {
    this->savitzky_golay_filter = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t TYPE_NONE =
    0u;
  static constexpr uint8_t TYPE_BAND_PASS =
    1u;
  static constexpr uint8_t TYPE_BUTTERWORTH =
    2u;
  static constexpr uint8_t TYPE_HIGH_PASS =
    3u;
  static constexpr uint8_t TYPE_KALMAN =
    4u;
  static constexpr uint8_t TYPE_LOW_PASS =
    5u;
  static constexpr uint8_t TYPE_MOVING_AVERAGE =
    6u;
  static constexpr uint8_t TYPE_NOTCH =
    7u;
  static constexpr uint8_t TYPE_SAVITZKY_GOLAY =
    8u;
  static constexpr uint8_t TYPE_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::FilterBase_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::FilterBase_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__FilterBase
    std::shared_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__FilterBase
    std::shared_ptr<healthcare_msgs::msg::FilterBase_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FilterBase_ & other) const
  {
    if (this->filters != other.filters) {
      return false;
    }
    if (this->band_pass_filter != other.band_pass_filter) {
      return false;
    }
    if (this->butter_worth_filter != other.butter_worth_filter) {
      return false;
    }
    if (this->high_pass_filter != other.high_pass_filter) {
      return false;
    }
    if (this->kalman_filter != other.kalman_filter) {
      return false;
    }
    if (this->low_pass_filter != other.low_pass_filter) {
      return false;
    }
    if (this->moving_average_filter != other.moving_average_filter) {
      return false;
    }
    if (this->notch_filter != other.notch_filter) {
      return false;
    }
    if (this->savitzky_golay_filter != other.savitzky_golay_filter) {
      return false;
    }
    return true;
  }
  bool operator!=(const FilterBase_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FilterBase_

// alias to use template instance with default allocator
using FilterBase =
  healthcare_msgs::msg::FilterBase_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_NONE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_BAND_PASS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_BUTTERWORTH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_HIGH_PASS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_KALMAN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_LOW_PASS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_MOVING_AVERAGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_NOTCH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_SAVITZKY_GOLAY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FilterBase_<ContainerAllocator>::TYPE_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__STRUCT_HPP_
