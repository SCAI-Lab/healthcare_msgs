// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/DeviceInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_DeviceInfo_stride_length
{
public:
  explicit Init_DeviceInfo_stride_length(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::DeviceInfo stride_length(::healthcare_msgs::msg::DeviceInfo::_stride_length_type arg)
  {
    msg_.stride_length = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_quality_window_size_samples
{
public:
  explicit Init_DeviceInfo_quality_window_size_samples(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_stride_length quality_window_size_samples(::healthcare_msgs::msg::DeviceInfo::_quality_window_size_samples_type arg)
  {
    msg_.quality_window_size_samples = std::move(arg);
    return Init_DeviceInfo_stride_length(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_window_size_samples
{
public:
  explicit Init_DeviceInfo_window_size_samples(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_quality_window_size_samples window_size_samples(::healthcare_msgs::msg::DeviceInfo::_window_size_samples_type arg)
  {
    msg_.window_size_samples = std::move(arg);
    return Init_DeviceInfo_quality_window_size_samples(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_min_range
{
public:
  explicit Init_DeviceInfo_min_range(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_window_size_samples min_range(::healthcare_msgs::msg::DeviceInfo::_min_range_type arg)
  {
    msg_.min_range = std::move(arg);
    return Init_DeviceInfo_window_size_samples(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_max_range
{
public:
  explicit Init_DeviceInfo_max_range(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_min_range max_range(::healthcare_msgs::msg::DeviceInfo::_max_range_type arg)
  {
    msg_.max_range = std::move(arg);
    return Init_DeviceInfo_min_range(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_accuracy
{
public:
  explicit Init_DeviceInfo_accuracy(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_max_range accuracy(::healthcare_msgs::msg::DeviceInfo::_accuracy_type arg)
  {
    msg_.accuracy = std::move(arg);
    return Init_DeviceInfo_max_range(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_adc_resolution
{
public:
  explicit Init_DeviceInfo_adc_resolution(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_accuracy adc_resolution(::healthcare_msgs::msg::DeviceInfo::_adc_resolution_type arg)
  {
    msg_.adc_resolution = std::move(arg);
    return Init_DeviceInfo_accuracy(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_resolution
{
public:
  explicit Init_DeviceInfo_resolution(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_adc_resolution resolution(::healthcare_msgs::msg::DeviceInfo::_resolution_type arg)
  {
    msg_.resolution = std::move(arg);
    return Init_DeviceInfo_adc_resolution(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_gain
{
public:
  explicit Init_DeviceInfo_gain(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_resolution gain(::healthcare_msgs::msg::DeviceInfo::_gain_type arg)
  {
    msg_.gain = std::move(arg);
    return Init_DeviceInfo_resolution(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_acquisition_rate_hz
{
public:
  explicit Init_DeviceInfo_acquisition_rate_hz(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_gain acquisition_rate_hz(::healthcare_msgs::msg::DeviceInfo::_acquisition_rate_hz_type arg)
  {
    msg_.acquisition_rate_hz = std::move(arg);
    return Init_DeviceInfo_gain(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_measuring_unit
{
public:
  explicit Init_DeviceInfo_measuring_unit(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_acquisition_rate_hz measuring_unit(::healthcare_msgs::msg::DeviceInfo::_measuring_unit_type arg)
  {
    msg_.measuring_unit = std::move(arg);
    return Init_DeviceInfo_acquisition_rate_hz(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_maximal_atmospheric_pressure
{
public:
  explicit Init_DeviceInfo_maximal_atmospheric_pressure(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_measuring_unit maximal_atmospheric_pressure(::healthcare_msgs::msg::DeviceInfo::_maximal_atmospheric_pressure_type arg)
  {
    msg_.maximal_atmospheric_pressure = std::move(arg);
    return Init_DeviceInfo_measuring_unit(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_minimal_atmospheric_pressure
{
public:
  explicit Init_DeviceInfo_minimal_atmospheric_pressure(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_maximal_atmospheric_pressure minimal_atmospheric_pressure(::healthcare_msgs::msg::DeviceInfo::_minimal_atmospheric_pressure_type arg)
  {
    msg_.minimal_atmospheric_pressure = std::move(arg);
    return Init_DeviceInfo_maximal_atmospheric_pressure(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_maximal_relative_humidity
{
public:
  explicit Init_DeviceInfo_maximal_relative_humidity(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_minimal_atmospheric_pressure maximal_relative_humidity(::healthcare_msgs::msg::DeviceInfo::_maximal_relative_humidity_type arg)
  {
    msg_.maximal_relative_humidity = std::move(arg);
    return Init_DeviceInfo_minimal_atmospheric_pressure(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_maximal_operation_temperature
{
public:
  explicit Init_DeviceInfo_maximal_operation_temperature(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_maximal_relative_humidity maximal_operation_temperature(::healthcare_msgs::msg::DeviceInfo::_maximal_operation_temperature_type arg)
  {
    msg_.maximal_operation_temperature = std::move(arg);
    return Init_DeviceInfo_maximal_relative_humidity(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_minimal_operation_temperature
{
public:
  explicit Init_DeviceInfo_minimal_operation_temperature(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_maximal_operation_temperature minimal_operation_temperature(::healthcare_msgs::msg::DeviceInfo::_minimal_operation_temperature_type arg)
  {
    msg_.minimal_operation_temperature = std::move(arg);
    return Init_DeviceInfo_maximal_operation_temperature(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_device_serial_number
{
public:
  explicit Init_DeviceInfo_device_serial_number(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_minimal_operation_temperature device_serial_number(::healthcare_msgs::msg::DeviceInfo::_device_serial_number_type arg)
  {
    msg_.device_serial_number = std::move(arg);
    return Init_DeviceInfo_minimal_operation_temperature(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_device_type
{
public:
  explicit Init_DeviceInfo_device_type(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_device_serial_number device_type(::healthcare_msgs::msg::DeviceInfo::_device_type_type arg)
  {
    msg_.device_type = std::move(arg);
    return Init_DeviceInfo_device_serial_number(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_device_name
{
public:
  explicit Init_DeviceInfo_device_name(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_device_type device_name(::healthcare_msgs::msg::DeviceInfo::_device_name_type arg)
  {
    msg_.device_name = std::move(arg);
    return Init_DeviceInfo_device_type(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_device_manufacturer
{
public:
  explicit Init_DeviceInfo_device_manufacturer(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_device_name device_manufacturer(::healthcare_msgs::msg::DeviceInfo::_device_manufacturer_type arg)
  {
    msg_.device_manufacturer = std::move(arg);
    return Init_DeviceInfo_device_name(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_mds
{
public:
  explicit Init_DeviceInfo_mds(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_device_manufacturer mds(::healthcare_msgs::msg::DeviceInfo::_mds_type arg)
  {
    msg_.mds = std::move(arg);
    return Init_DeviceInfo_device_manufacturer(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_session_id
{
public:
  explicit Init_DeviceInfo_session_id(::healthcare_msgs::msg::DeviceInfo & msg)
  : msg_(msg)
  {}
  Init_DeviceInfo_mds session_id(::healthcare_msgs::msg::DeviceInfo::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_DeviceInfo_mds(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

class Init_DeviceInfo_header
{
public:
  Init_DeviceInfo_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DeviceInfo_session_id header(::healthcare_msgs::msg::DeviceInfo::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_DeviceInfo_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::DeviceInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::DeviceInfo>()
{
  return healthcare_msgs::msg::builder::Init_DeviceInfo_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__BUILDER_HPP_
