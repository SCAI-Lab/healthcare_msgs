// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EMGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__EMGInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_MV'.
enum
{
  healthcare_msgs__msg__EMGInfo__UNIT_MV = 1
};

/// Constant 'UNIT_UV'.
enum
{
  healthcare_msgs__msg__EMGInfo__UNIT_UV = 2
};

/// Constant 'UNIT_COUNTS'.
enum
{
  healthcare_msgs__msg__EMGInfo__UNIT_COUNTS = 3
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Electrode Placement Enum
 */
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_BICEPS'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_BICEPS = 1
};

/// Constant 'PLACEMENT_TRICEPS'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_TRICEPS = 2
};

/// Constant 'PLACEMENT_FOREARM'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_FOREARM = 3
};

/// Constant 'PLACEMENT_CALF'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_CALF = 4
};

/// Constant 'PLACEMENT_BACK'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_BACK = 5
};

/// Constant 'PLACEMENT_ABDOMEN'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_ABDOMEN = 6
};

/// Constant 'PLACEMENT_QUADRICEPS'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_QUADRICEPS = 7
};

/// Constant 'PLACEMENT_HAMSTRING'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_HAMSTRING = 8
};

/// Constant 'PLACEMENT_FACE'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_FACE = 9
};

/// Constant 'PLACEMENT_NECK'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_NECK = 10
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__EMGInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'ELECTRODE_UNKNOWN'.
/**
  * Electrode Type Enum
 */
enum
{
  healthcare_msgs__msg__EMGInfo__ELECTRODE_UNKNOWN = 0
};

/// Constant 'ELECTRODE_SURFACE'.
enum
{
  healthcare_msgs__msg__EMGInfo__ELECTRODE_SURFACE = 1
};

/// Constant 'ELECTRODE_NEEDLE'.
enum
{
  healthcare_msgs__msg__EMGInfo__ELECTRODE_NEEDLE = 2
};

/// Constant 'ELECTRODE_WIRE'.
enum
{
  healthcare_msgs__msg__EMGInfo__ELECTRODE_WIRE = 3
};

/// Constant 'ELECTRODE_INTERFERENTIAL'.
enum
{
  healthcare_msgs__msg__EMGInfo__ELECTRODE_INTERFERENTIAL = 4
};

/// Constant 'ELECTRODE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EMGInfo__ELECTRODE_CUSTOM = 255
};

/// Constant 'DEVICE_UNKNOWN'.
/**
  * External Devices Enum (used during EMG recording)
 */
enum
{
  healthcare_msgs__msg__EMGInfo__DEVICE_UNKNOWN = 0
};

/// Constant 'DEVICE_TENS'.
/**
  * Transcutaneous electrical nerve stimulation
 */
enum
{
  healthcare_msgs__msg__EMGInfo__DEVICE_TENS = 1
};

/// Constant 'DEVICE_FES'.
/**
  * Functional electrical stimulation
 */
enum
{
  healthcare_msgs__msg__EMGInfo__DEVICE_FES = 2
};

/// Constant 'DEVICE_EMG_TRIGGER'.
/**
  * Trigger/timing system
 */
enum
{
  healthcare_msgs__msg__EMGInfo__DEVICE_EMG_TRIGGER = 3
};

/// Constant 'DEVICE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EMGInfo__DEVICE_CUSTOM = 255
};

/// Constant 'MODE_UNKNOWN'.
/**
  * Signal Mode Enum
 */
enum
{
  healthcare_msgs__msg__EMGInfo__MODE_UNKNOWN = 0
};

/// Constant 'MODE_SURFACE'.
enum
{
  healthcare_msgs__msg__EMGInfo__MODE_SURFACE = 1
};

/// Constant 'MODE_INTRAMUSCULAR'.
enum
{
  healthcare_msgs__msg__EMGInfo__MODE_INTRAMUSCULAR = 2
};

/// Constant 'MODE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EMGInfo__MODE_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'electrode_placement'
// Member 'electrode_type'
// Member 'external_devices'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/EMGInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EMGInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  uint8_t units;
  /// Support multiple placements
  rosidl_runtime_c__uint8__Sequence electrode_placement;
  rosidl_runtime_c__uint8__Sequence electrode_type;
  /// Use DEVICE_* enum
  rosidl_runtime_c__uint8__Sequence external_devices;
  uint8_t signal_mode;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__EMGInfo;

// Struct for a sequence of healthcare_msgs__msg__EMGInfo.
typedef struct healthcare_msgs__msg__EMGInfo__Sequence
{
  healthcare_msgs__msg__EMGInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EMGInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__STRUCT_H_
