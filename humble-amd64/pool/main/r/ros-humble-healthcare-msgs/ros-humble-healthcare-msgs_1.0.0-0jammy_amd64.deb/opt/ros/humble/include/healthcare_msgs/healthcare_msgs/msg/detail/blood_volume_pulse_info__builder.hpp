// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BloodVolumePulseInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/blood_volume_pulse_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BloodVolumePulseInfo_filters
{
public:
  explicit Init_BloodVolumePulseInfo_filters(::healthcare_msgs::msg::BloodVolumePulseInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BloodVolumePulseInfo filters(::healthcare_msgs::msg::BloodVolumePulseInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulseInfo msg_;
};

class Init_BloodVolumePulseInfo_sensor_placement
{
public:
  explicit Init_BloodVolumePulseInfo_sensor_placement(::healthcare_msgs::msg::BloodVolumePulseInfo & msg)
  : msg_(msg)
  {}
  Init_BloodVolumePulseInfo_filters sensor_placement(::healthcare_msgs::msg::BloodVolumePulseInfo::_sensor_placement_type arg)
  {
    msg_.sensor_placement = std::move(arg);
    return Init_BloodVolumePulseInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulseInfo msg_;
};

class Init_BloodVolumePulseInfo_unit
{
public:
  explicit Init_BloodVolumePulseInfo_unit(::healthcare_msgs::msg::BloodVolumePulseInfo & msg)
  : msg_(msg)
  {}
  Init_BloodVolumePulseInfo_sensor_placement unit(::healthcare_msgs::msg::BloodVolumePulseInfo::_unit_type arg)
  {
    msg_.unit = std::move(arg);
    return Init_BloodVolumePulseInfo_sensor_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulseInfo msg_;
};

class Init_BloodVolumePulseInfo_device_info
{
public:
  Init_BloodVolumePulseInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BloodVolumePulseInfo_unit device_info(::healthcare_msgs::msg::BloodVolumePulseInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_BloodVolumePulseInfo_unit(msg_);
  }

private:
  ::healthcare_msgs::msg::BloodVolumePulseInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BloodVolumePulseInfo>()
{
  return healthcare_msgs::msg::builder::Init_BloodVolumePulseInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE_INFO__BUILDER_HPP_
