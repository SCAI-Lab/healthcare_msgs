// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/BrainDecodingSleepStageInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BRAIN_DECODING_SLEEP_STAGE_INFO_H_
#define HEALTHCARE_MSGS__MSG__BRAIN_DECODING_SLEEP_STAGE_INFO_H_

#include "healthcare_msgs/msg/detail/brain_decoding_sleep_stage_info__struct.h"
#include "healthcare_msgs/msg/detail/brain_decoding_sleep_stage_info__functions.h"
#include "healthcare_msgs/msg/detail/brain_decoding_sleep_stage_info__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__BRAIN_DECODING_SLEEP_STAGE_INFO_H_
