// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/BCGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/bcg_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BCGInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: units
  {
    out << "units: ";
    rosidl_generator_traits::value_to_yaml(msg.units, out);
    out << ", ";
  }

  // member: sensor_placement
  {
    out << "sensor_placement: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_placement, out);
    out << ", ";
  }

  // member: sensing_direction
  {
    out << "sensing_direction: ";
    rosidl_generator_traits::value_to_yaml(msg.sensing_direction, out);
    out << ", ";
  }

  // member: sensing_modality
  {
    out << "sensing_modality: ";
    rosidl_generator_traits::value_to_yaml(msg.sensing_modality, out);
    out << ", ";
  }

  // member: measurement_system
  {
    out << "measurement_system: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_system, out);
    out << ", ";
  }

  // member: filters
  {
    out << "filters: ";
    to_flow_style_yaml(msg.filters, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BCGInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: units
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "units: ";
    rosidl_generator_traits::value_to_yaml(msg.units, out);
    out << "\n";
  }

  // member: sensor_placement
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_placement: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_placement, out);
    out << "\n";
  }

  // member: sensing_direction
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensing_direction: ";
    rosidl_generator_traits::value_to_yaml(msg.sensing_direction, out);
    out << "\n";
  }

  // member: sensing_modality
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensing_modality: ";
    rosidl_generator_traits::value_to_yaml(msg.sensing_modality, out);
    out << "\n";
  }

  // member: measurement_system
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_system: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_system, out);
    out << "\n";
  }

  // member: filters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filters:\n";
    to_block_style_yaml(msg.filters, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BCGInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::BCGInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::BCGInfo & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::BCGInfo>()
{
  return "healthcare_msgs::msg::BCGInfo";
}

template<>
inline const char * name<healthcare_msgs::msg::BCGInfo>()
{
  return "healthcare_msgs/msg/BCGInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::BCGInfo>
  : std::integral_constant<bool, has_fixed_size<healthcare_msgs::msg::DeviceInfo>::value && has_fixed_size<healthcare_msgs::msg::FilterBase>::value> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::BCGInfo>
  : std::integral_constant<bool, has_bounded_size<healthcare_msgs::msg::DeviceInfo>::value && has_bounded_size<healthcare_msgs::msg::FilterBase>::value> {};

template<>
struct is_message<healthcare_msgs::msg::BCGInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__TRAITS_HPP_
