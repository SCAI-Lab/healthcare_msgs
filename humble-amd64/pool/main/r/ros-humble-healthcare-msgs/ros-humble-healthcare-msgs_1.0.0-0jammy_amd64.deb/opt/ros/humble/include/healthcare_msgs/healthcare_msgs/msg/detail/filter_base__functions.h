// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from healthcare_msgs:msg/FilterBase.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__FUNCTIONS_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "healthcare_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Initialize msg/FilterBase message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * healthcare_msgs__msg__FilterBase
 * )) before or use
 * healthcare_msgs__msg__FilterBase__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__FilterBase__init(healthcare_msgs__msg__FilterBase * msg);

/// Finalize msg/FilterBase message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__FilterBase__fini(healthcare_msgs__msg__FilterBase * msg);

/// Create msg/FilterBase message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * healthcare_msgs__msg__FilterBase__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__FilterBase *
healthcare_msgs__msg__FilterBase__create();

/// Destroy msg/FilterBase message.
/**
 * It calls
 * healthcare_msgs__msg__FilterBase__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__FilterBase__destroy(healthcare_msgs__msg__FilterBase * msg);

/// Check for msg/FilterBase message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__FilterBase__are_equal(const healthcare_msgs__msg__FilterBase * lhs, const healthcare_msgs__msg__FilterBase * rhs);

/// Copy a msg/FilterBase message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__FilterBase__copy(
  const healthcare_msgs__msg__FilterBase * input,
  healthcare_msgs__msg__FilterBase * output);

/// Initialize array of msg/FilterBase messages.
/**
 * It allocates the memory for the number of elements and calls
 * healthcare_msgs__msg__FilterBase__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__FilterBase__Sequence__init(healthcare_msgs__msg__FilterBase__Sequence * array, size_t size);

/// Finalize array of msg/FilterBase messages.
/**
 * It calls
 * healthcare_msgs__msg__FilterBase__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__FilterBase__Sequence__fini(healthcare_msgs__msg__FilterBase__Sequence * array);

/// Create array of msg/FilterBase messages.
/**
 * It allocates the memory for the array and calls
 * healthcare_msgs__msg__FilterBase__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__FilterBase__Sequence *
healthcare_msgs__msg__FilterBase__Sequence__create(size_t size);

/// Destroy array of msg/FilterBase messages.
/**
 * It calls
 * healthcare_msgs__msg__FilterBase__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__FilterBase__Sequence__destroy(healthcare_msgs__msg__FilterBase__Sequence * array);

/// Check for msg/FilterBase message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__FilterBase__Sequence__are_equal(const healthcare_msgs__msg__FilterBase__Sequence * lhs, const healthcare_msgs__msg__FilterBase__Sequence * rhs);

/// Copy an array of msg/FilterBase messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__FilterBase__Sequence__copy(
  const healthcare_msgs__msg__FilterBase__Sequence * input,
  healthcare_msgs__msg__FilterBase__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__FILTER_BASE__FUNCTIONS_H_
