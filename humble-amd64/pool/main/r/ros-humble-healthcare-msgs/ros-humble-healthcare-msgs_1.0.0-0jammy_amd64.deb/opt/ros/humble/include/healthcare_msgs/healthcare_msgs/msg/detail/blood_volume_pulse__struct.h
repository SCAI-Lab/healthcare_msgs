﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BloodVolumePulse.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"
// Member 'bvp'
// Member 'quality'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/BloodVolumePulse in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BloodVolumePulse
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint16_t sample_size;
  /// Raw or filtered BVP signal [samples]×[wavelengths]
  rosidl_runtime_c__float__Sequence bvp;
  /// From 0 (poor) to 1 (excellent)
  rosidl_runtime_c__float__Sequence quality;
} healthcare_msgs__msg__BloodVolumePulse;

// Struct for a sequence of healthcare_msgs__msg__BloodVolumePulse.
typedef struct healthcare_msgs__msg__BloodVolumePulse__Sequence
{
  healthcare_msgs__msg__BloodVolumePulse * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BloodVolumePulse__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BLOOD_VOLUME_PULSE__STRUCT_H_
