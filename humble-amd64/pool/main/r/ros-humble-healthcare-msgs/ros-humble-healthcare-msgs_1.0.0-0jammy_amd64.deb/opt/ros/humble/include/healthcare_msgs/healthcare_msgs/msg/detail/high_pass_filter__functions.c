// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/HighPassFilter.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/high_pass_filter__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
healthcare_msgs__msg__HighPassFilter__init(healthcare_msgs__msg__HighPassFilter * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    healthcare_msgs__msg__HighPassFilter__fini(msg);
    return false;
  }
  // cutoff_frequency
  // order
  // sampling_rate
  // zero_phase
  return true;
}

void
healthcare_msgs__msg__HighPassFilter__fini(healthcare_msgs__msg__HighPassFilter * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // cutoff_frequency
  // order
  // sampling_rate
  // zero_phase
}

bool
healthcare_msgs__msg__HighPassFilter__are_equal(const healthcare_msgs__msg__HighPassFilter * lhs, const healthcare_msgs__msg__HighPassFilter * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // cutoff_frequency
  if (lhs->cutoff_frequency != rhs->cutoff_frequency) {
    return false;
  }
  // order
  if (lhs->order != rhs->order) {
    return false;
  }
  // sampling_rate
  if (lhs->sampling_rate != rhs->sampling_rate) {
    return false;
  }
  // zero_phase
  if (lhs->zero_phase != rhs->zero_phase) {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__HighPassFilter__copy(
  const healthcare_msgs__msg__HighPassFilter * input,
  healthcare_msgs__msg__HighPassFilter * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // cutoff_frequency
  output->cutoff_frequency = input->cutoff_frequency;
  // order
  output->order = input->order;
  // sampling_rate
  output->sampling_rate = input->sampling_rate;
  // zero_phase
  output->zero_phase = input->zero_phase;
  return true;
}

healthcare_msgs__msg__HighPassFilter *
healthcare_msgs__msg__HighPassFilter__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HighPassFilter * msg = (healthcare_msgs__msg__HighPassFilter *)allocator.allocate(sizeof(healthcare_msgs__msg__HighPassFilter), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__HighPassFilter));
  bool success = healthcare_msgs__msg__HighPassFilter__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__HighPassFilter__destroy(healthcare_msgs__msg__HighPassFilter * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__HighPassFilter__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__HighPassFilter__Sequence__init(healthcare_msgs__msg__HighPassFilter__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HighPassFilter * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__HighPassFilter *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__HighPassFilter), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__HighPassFilter__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__HighPassFilter__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__HighPassFilter__Sequence__fini(healthcare_msgs__msg__HighPassFilter__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__HighPassFilter__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__HighPassFilter__Sequence *
healthcare_msgs__msg__HighPassFilter__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HighPassFilter__Sequence * array = (healthcare_msgs__msg__HighPassFilter__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__HighPassFilter__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__HighPassFilter__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__HighPassFilter__Sequence__destroy(healthcare_msgs__msg__HighPassFilter__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__HighPassFilter__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__HighPassFilter__Sequence__are_equal(const healthcare_msgs__msg__HighPassFilter__Sequence * lhs, const healthcare_msgs__msg__HighPassFilter__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__HighPassFilter__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__HighPassFilter__Sequence__copy(
  const healthcare_msgs__msg__HighPassFilter__Sequence * input,
  healthcare_msgs__msg__HighPassFilter__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__HighPassFilter);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__HighPassFilter * data =
      (healthcare_msgs__msg__HighPassFilter *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__HighPassFilter__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__HighPassFilter__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__HighPassFilter__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
