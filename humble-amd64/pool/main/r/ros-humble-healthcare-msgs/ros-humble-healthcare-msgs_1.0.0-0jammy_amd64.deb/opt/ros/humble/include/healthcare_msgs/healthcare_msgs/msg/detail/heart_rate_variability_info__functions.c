// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/HeartRateVariabilityInfo.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/heart_rate_variability_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__functions.h"
// Member `sensor_placement`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `filters`
#include "healthcare_msgs/msg/detail/filter_base__functions.h"

bool
healthcare_msgs__msg__HeartRateVariabilityInfo__init(healthcare_msgs__msg__HeartRateVariabilityInfo * msg)
{
  if (!msg) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__init(&msg->device_info)) {
    healthcare_msgs__msg__HeartRateVariabilityInfo__fini(msg);
    return false;
  }
  // unit
  // measurement_method
  // sensor_placement
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->sensor_placement, 0)) {
    healthcare_msgs__msg__HeartRateVariabilityInfo__fini(msg);
    return false;
  }
  // hrv_domain
  // filters
  if (!healthcare_msgs__msg__FilterBase__init(&msg->filters)) {
    healthcare_msgs__msg__HeartRateVariabilityInfo__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__HeartRateVariabilityInfo__fini(healthcare_msgs__msg__HeartRateVariabilityInfo * msg)
{
  if (!msg) {
    return;
  }
  // device_info
  healthcare_msgs__msg__DeviceInfo__fini(&msg->device_info);
  // unit
  // measurement_method
  // sensor_placement
  rosidl_runtime_c__uint8__Sequence__fini(&msg->sensor_placement);
  // hrv_domain
  // filters
  healthcare_msgs__msg__FilterBase__fini(&msg->filters);
}

bool
healthcare_msgs__msg__HeartRateVariabilityInfo__are_equal(const healthcare_msgs__msg__HeartRateVariabilityInfo * lhs, const healthcare_msgs__msg__HeartRateVariabilityInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__are_equal(
      &(lhs->device_info), &(rhs->device_info)))
  {
    return false;
  }
  // unit
  if (lhs->unit != rhs->unit) {
    return false;
  }
  // measurement_method
  if (lhs->measurement_method != rhs->measurement_method) {
    return false;
  }
  // sensor_placement
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->sensor_placement), &(rhs->sensor_placement)))
  {
    return false;
  }
  // hrv_domain
  if (lhs->hrv_domain != rhs->hrv_domain) {
    return false;
  }
  // filters
  if (!healthcare_msgs__msg__FilterBase__are_equal(
      &(lhs->filters), &(rhs->filters)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__HeartRateVariabilityInfo__copy(
  const healthcare_msgs__msg__HeartRateVariabilityInfo * input,
  healthcare_msgs__msg__HeartRateVariabilityInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__copy(
      &(input->device_info), &(output->device_info)))
  {
    return false;
  }
  // unit
  output->unit = input->unit;
  // measurement_method
  output->measurement_method = input->measurement_method;
  // sensor_placement
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->sensor_placement), &(output->sensor_placement)))
  {
    return false;
  }
  // hrv_domain
  output->hrv_domain = input->hrv_domain;
  // filters
  if (!healthcare_msgs__msg__FilterBase__copy(
      &(input->filters), &(output->filters)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__HeartRateVariabilityInfo *
healthcare_msgs__msg__HeartRateVariabilityInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRateVariabilityInfo * msg = (healthcare_msgs__msg__HeartRateVariabilityInfo *)allocator.allocate(sizeof(healthcare_msgs__msg__HeartRateVariabilityInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__HeartRateVariabilityInfo));
  bool success = healthcare_msgs__msg__HeartRateVariabilityInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__HeartRateVariabilityInfo__destroy(healthcare_msgs__msg__HeartRateVariabilityInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__HeartRateVariabilityInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__init(healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRateVariabilityInfo * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__HeartRateVariabilityInfo *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__HeartRateVariabilityInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__HeartRateVariabilityInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__HeartRateVariabilityInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__fini(healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__HeartRateVariabilityInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence *
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * array = (healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__destroy(healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__are_equal(const healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * lhs, const healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__HeartRateVariabilityInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__copy(
  const healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * input,
  healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__HeartRateVariabilityInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__HeartRateVariabilityInfo * data =
      (healthcare_msgs__msg__HeartRateVariabilityInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__HeartRateVariabilityInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__HeartRateVariabilityInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__HeartRateVariabilityInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
