// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/eeg_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const EEGInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: channel_size
  {
    out << "channel_size: ";
    rosidl_generator_traits::value_to_yaml(msg.channel_size, out);
    out << ", ";
  }

  // member: units
  {
    out << "units: ";
    rosidl_generator_traits::value_to_yaml(msg.units, out);
    out << ", ";
  }

  // member: selected_preprocessing
  {
    if (msg.selected_preprocessing.size() == 0) {
      out << "selected_preprocessing: []";
    } else {
      out << "selected_preprocessing: [";
      size_t pending_items = msg.selected_preprocessing.size();
      for (auto item : msg.selected_preprocessing) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: montage_type
  {
    out << "montage_type: ";
    rosidl_generator_traits::value_to_yaml(msg.montage_type, out);
    out << ", ";
  }

  // member: bipolar_active_sites
  {
    if (msg.bipolar_active_sites.size() == 0) {
      out << "bipolar_active_sites: []";
    } else {
      out << "bipolar_active_sites: [";
      size_t pending_items = msg.bipolar_active_sites.size();
      for (auto item : msg.bipolar_active_sites) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: bipolar_reference_sites
  {
    if (msg.bipolar_reference_sites.size() == 0) {
      out << "bipolar_reference_sites: []";
    } else {
      out << "bipolar_reference_sites: [";
      size_t pending_items = msg.bipolar_reference_sites.size();
      for (auto item : msg.bipolar_reference_sites) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reference_sites
  {
    if (msg.reference_sites.size() == 0) {
      out << "reference_sites: []";
    } else {
      out << "reference_sites: [";
      size_t pending_items = msg.reference_sites.size();
      for (auto item : msg.reference_sites) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: placement_method
  {
    if (msg.placement_method.size() == 0) {
      out << "placement_method: []";
    } else {
      out << "placement_method: [";
      size_t pending_items = msg.placement_method.size();
      for (auto item : msg.placement_method) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: electrode_sites
  {
    if (msg.electrode_sites.size() == 0) {
      out << "electrode_sites: []";
    } else {
      out << "electrode_sites: [";
      size_t pending_items = msg.electrode_sites.size();
      for (auto item : msg.electrode_sites) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: electrode_physical_type
  {
    if (msg.electrode_physical_type.size() == 0) {
      out << "electrode_physical_type: []";
    } else {
      out << "electrode_physical_type: [";
      size_t pending_items = msg.electrode_physical_type.size();
      for (auto item : msg.electrode_physical_type) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: signal_mode
  {
    out << "signal_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.signal_mode, out);
    out << ", ";
  }

  // member: filters
  {
    out << "filters: ";
    to_flow_style_yaml(msg.filters, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EEGInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: channel_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "channel_size: ";
    rosidl_generator_traits::value_to_yaml(msg.channel_size, out);
    out << "\n";
  }

  // member: units
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "units: ";
    rosidl_generator_traits::value_to_yaml(msg.units, out);
    out << "\n";
  }

  // member: selected_preprocessing
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.selected_preprocessing.size() == 0) {
      out << "selected_preprocessing: []\n";
    } else {
      out << "selected_preprocessing:\n";
      for (auto item : msg.selected_preprocessing) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: montage_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "montage_type: ";
    rosidl_generator_traits::value_to_yaml(msg.montage_type, out);
    out << "\n";
  }

  // member: bipolar_active_sites
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.bipolar_active_sites.size() == 0) {
      out << "bipolar_active_sites: []\n";
    } else {
      out << "bipolar_active_sites:\n";
      for (auto item : msg.bipolar_active_sites) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: bipolar_reference_sites
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.bipolar_reference_sites.size() == 0) {
      out << "bipolar_reference_sites: []\n";
    } else {
      out << "bipolar_reference_sites:\n";
      for (auto item : msg.bipolar_reference_sites) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reference_sites
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reference_sites.size() == 0) {
      out << "reference_sites: []\n";
    } else {
      out << "reference_sites:\n";
      for (auto item : msg.reference_sites) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: placement_method
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.placement_method.size() == 0) {
      out << "placement_method: []\n";
    } else {
      out << "placement_method:\n";
      for (auto item : msg.placement_method) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: electrode_sites
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.electrode_sites.size() == 0) {
      out << "electrode_sites: []\n";
    } else {
      out << "electrode_sites:\n";
      for (auto item : msg.electrode_sites) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: electrode_physical_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.electrode_physical_type.size() == 0) {
      out << "electrode_physical_type: []\n";
    } else {
      out << "electrode_physical_type:\n";
      for (auto item : msg.electrode_physical_type) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: signal_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "signal_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.signal_mode, out);
    out << "\n";
  }

  // member: filters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filters:\n";
    to_block_style_yaml(msg.filters, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EEGInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::EEGInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::EEGInfo & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::EEGInfo>()
{
  return "healthcare_msgs::msg::EEGInfo";
}

template<>
inline const char * name<healthcare_msgs::msg::EEGInfo>()
{
  return "healthcare_msgs/msg/EEGInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::EEGInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::EEGInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::EEGInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__TRAITS_HPP_
