// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__FUNCTIONS_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "healthcare_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "healthcare_msgs/msg/detail/eeg_info__struct.h"

/// Initialize msg/EEGInfo message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * healthcare_msgs__msg__EEGInfo
 * )) before or use
 * healthcare_msgs__msg__EEGInfo__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EEGInfo__init(healthcare_msgs__msg__EEGInfo * msg);

/// Finalize msg/EEGInfo message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EEGInfo__fini(healthcare_msgs__msg__EEGInfo * msg);

/// Create msg/EEGInfo message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * healthcare_msgs__msg__EEGInfo__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__EEGInfo *
healthcare_msgs__msg__EEGInfo__create();

/// Destroy msg/EEGInfo message.
/**
 * It calls
 * healthcare_msgs__msg__EEGInfo__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EEGInfo__destroy(healthcare_msgs__msg__EEGInfo * msg);

/// Check for msg/EEGInfo message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EEGInfo__are_equal(const healthcare_msgs__msg__EEGInfo * lhs, const healthcare_msgs__msg__EEGInfo * rhs);

/// Copy a msg/EEGInfo message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EEGInfo__copy(
  const healthcare_msgs__msg__EEGInfo * input,
  healthcare_msgs__msg__EEGInfo * output);

/// Initialize array of msg/EEGInfo messages.
/**
 * It allocates the memory for the number of elements and calls
 * healthcare_msgs__msg__EEGInfo__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EEGInfo__Sequence__init(healthcare_msgs__msg__EEGInfo__Sequence * array, size_t size);

/// Finalize array of msg/EEGInfo messages.
/**
 * It calls
 * healthcare_msgs__msg__EEGInfo__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EEGInfo__Sequence__fini(healthcare_msgs__msg__EEGInfo__Sequence * array);

/// Create array of msg/EEGInfo messages.
/**
 * It allocates the memory for the array and calls
 * healthcare_msgs__msg__EEGInfo__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__EEGInfo__Sequence *
healthcare_msgs__msg__EEGInfo__Sequence__create(size_t size);

/// Destroy array of msg/EEGInfo messages.
/**
 * It calls
 * healthcare_msgs__msg__EEGInfo__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EEGInfo__Sequence__destroy(healthcare_msgs__msg__EEGInfo__Sequence * array);

/// Check for msg/EEGInfo message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EEGInfo__Sequence__are_equal(const healthcare_msgs__msg__EEGInfo__Sequence * lhs, const healthcare_msgs__msg__EEGInfo__Sequence * rhs);

/// Copy an array of msg/EEGInfo messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EEGInfo__Sequence__copy(
  const healthcare_msgs__msg__EEGInfo__Sequence * input,
  healthcare_msgs__msg__EEGInfo__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__FUNCTIONS_H_
