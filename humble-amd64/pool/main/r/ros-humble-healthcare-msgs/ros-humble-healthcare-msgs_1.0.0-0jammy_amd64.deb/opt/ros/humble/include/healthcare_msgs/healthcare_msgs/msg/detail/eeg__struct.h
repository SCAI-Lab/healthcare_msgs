// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EEG.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"
// Member 'eeg'
// Member 'quality'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/EEG in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EEG
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint16_t sample_size;
  /// Flattened raw or filtered EEG values: length = channel_count * sample_count. Access sample s of channel c as: eeg_flat
  rosidl_runtime_c__float__Sequence eeg;
  /// From 0 (poor) to 1 (excellent)
  rosidl_runtime_c__float__Sequence quality;
} healthcare_msgs__msg__EEG;

// Struct for a sequence of healthcare_msgs__msg__EEG.
typedef struct healthcare_msgs__msg__EEG__Sequence
{
  healthcare_msgs__msg__EEG * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EEG__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG__STRUCT_H_
