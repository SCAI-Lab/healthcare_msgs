// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/HeartRateVariability.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/heart_rate_variability__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_HeartRateVariability_quality
{
public:
  explicit Init_HeartRateVariability_quality(::healthcare_msgs::msg::HeartRateVariability & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::HeartRateVariability quality(::healthcare_msgs::msg::HeartRateVariability::_quality_type arg)
  {
    msg_.quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariability msg_;
};

class Init_HeartRateVariability_hrv
{
public:
  explicit Init_HeartRateVariability_hrv(::healthcare_msgs::msg::HeartRateVariability & msg)
  : msg_(msg)
  {}
  Init_HeartRateVariability_quality hrv(::healthcare_msgs::msg::HeartRateVariability::_hrv_type arg)
  {
    msg_.hrv = std::move(arg);
    return Init_HeartRateVariability_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariability msg_;
};

class Init_HeartRateVariability_sample_size
{
public:
  explicit Init_HeartRateVariability_sample_size(::healthcare_msgs::msg::HeartRateVariability & msg)
  : msg_(msg)
  {}
  Init_HeartRateVariability_hrv sample_size(::healthcare_msgs::msg::HeartRateVariability::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_HeartRateVariability_hrv(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariability msg_;
};

class Init_HeartRateVariability_session_id
{
public:
  explicit Init_HeartRateVariability_session_id(::healthcare_msgs::msg::HeartRateVariability & msg)
  : msg_(msg)
  {}
  Init_HeartRateVariability_sample_size session_id(::healthcare_msgs::msg::HeartRateVariability::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_HeartRateVariability_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariability msg_;
};

class Init_HeartRateVariability_header
{
public:
  Init_HeartRateVariability_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HeartRateVariability_session_id header(::healthcare_msgs::msg::HeartRateVariability::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_HeartRateVariability_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariability msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::HeartRateVariability>()
{
  return healthcare_msgs::msg::builder::Init_HeartRateVariability_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY__BUILDER_HPP_
