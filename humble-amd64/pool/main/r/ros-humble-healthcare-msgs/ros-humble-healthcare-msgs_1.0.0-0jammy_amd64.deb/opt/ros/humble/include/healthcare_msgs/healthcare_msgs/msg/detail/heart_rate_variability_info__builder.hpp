// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/HeartRateVariabilityInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/heart_rate_variability_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_HeartRateVariabilityInfo_filters
{
public:
  explicit Init_HeartRateVariabilityInfo_filters(::healthcare_msgs::msg::HeartRateVariabilityInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::HeartRateVariabilityInfo filters(::healthcare_msgs::msg::HeartRateVariabilityInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariabilityInfo msg_;
};

class Init_HeartRateVariabilityInfo_hrv_domain
{
public:
  explicit Init_HeartRateVariabilityInfo_hrv_domain(::healthcare_msgs::msg::HeartRateVariabilityInfo & msg)
  : msg_(msg)
  {}
  Init_HeartRateVariabilityInfo_filters hrv_domain(::healthcare_msgs::msg::HeartRateVariabilityInfo::_hrv_domain_type arg)
  {
    msg_.hrv_domain = std::move(arg);
    return Init_HeartRateVariabilityInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariabilityInfo msg_;
};

class Init_HeartRateVariabilityInfo_sensor_placement
{
public:
  explicit Init_HeartRateVariabilityInfo_sensor_placement(::healthcare_msgs::msg::HeartRateVariabilityInfo & msg)
  : msg_(msg)
  {}
  Init_HeartRateVariabilityInfo_hrv_domain sensor_placement(::healthcare_msgs::msg::HeartRateVariabilityInfo::_sensor_placement_type arg)
  {
    msg_.sensor_placement = std::move(arg);
    return Init_HeartRateVariabilityInfo_hrv_domain(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariabilityInfo msg_;
};

class Init_HeartRateVariabilityInfo_measurement_method
{
public:
  explicit Init_HeartRateVariabilityInfo_measurement_method(::healthcare_msgs::msg::HeartRateVariabilityInfo & msg)
  : msg_(msg)
  {}
  Init_HeartRateVariabilityInfo_sensor_placement measurement_method(::healthcare_msgs::msg::HeartRateVariabilityInfo::_measurement_method_type arg)
  {
    msg_.measurement_method = std::move(arg);
    return Init_HeartRateVariabilityInfo_sensor_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariabilityInfo msg_;
};

class Init_HeartRateVariabilityInfo_unit
{
public:
  explicit Init_HeartRateVariabilityInfo_unit(::healthcare_msgs::msg::HeartRateVariabilityInfo & msg)
  : msg_(msg)
  {}
  Init_HeartRateVariabilityInfo_measurement_method unit(::healthcare_msgs::msg::HeartRateVariabilityInfo::_unit_type arg)
  {
    msg_.unit = std::move(arg);
    return Init_HeartRateVariabilityInfo_measurement_method(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariabilityInfo msg_;
};

class Init_HeartRateVariabilityInfo_device_info
{
public:
  Init_HeartRateVariabilityInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HeartRateVariabilityInfo_unit device_info(::healthcare_msgs::msg::HeartRateVariabilityInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_HeartRateVariabilityInfo_unit(msg_);
  }

private:
  ::healthcare_msgs::msg::HeartRateVariabilityInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::HeartRateVariabilityInfo>()
{
  return healthcare_msgs::msg::builder::Init_HeartRateVariabilityInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__BUILDER_HPP_
