// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/ECGInfo.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/ecg_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__functions.h"
// Member `electrode_placement`
// Member `lead_type`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `filters`
#include "healthcare_msgs/msg/detail/filter_base__functions.h"

bool
healthcare_msgs__msg__ECGInfo__init(healthcare_msgs__msg__ECGInfo * msg)
{
  if (!msg) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__init(&msg->device_info)) {
    healthcare_msgs__msg__ECGInfo__fini(msg);
    return false;
  }
  // units
  // electrode_placement
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->electrode_placement, 0)) {
    healthcare_msgs__msg__ECGInfo__fini(msg);
    return false;
  }
  // lead_type
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->lead_type, 0)) {
    healthcare_msgs__msg__ECGInfo__fini(msg);
    return false;
  }
  // filters
  if (!healthcare_msgs__msg__FilterBase__init(&msg->filters)) {
    healthcare_msgs__msg__ECGInfo__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__ECGInfo__fini(healthcare_msgs__msg__ECGInfo * msg)
{
  if (!msg) {
    return;
  }
  // device_info
  healthcare_msgs__msg__DeviceInfo__fini(&msg->device_info);
  // units
  // electrode_placement
  rosidl_runtime_c__uint8__Sequence__fini(&msg->electrode_placement);
  // lead_type
  rosidl_runtime_c__uint8__Sequence__fini(&msg->lead_type);
  // filters
  healthcare_msgs__msg__FilterBase__fini(&msg->filters);
}

bool
healthcare_msgs__msg__ECGInfo__are_equal(const healthcare_msgs__msg__ECGInfo * lhs, const healthcare_msgs__msg__ECGInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__are_equal(
      &(lhs->device_info), &(rhs->device_info)))
  {
    return false;
  }
  // units
  if (lhs->units != rhs->units) {
    return false;
  }
  // electrode_placement
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->electrode_placement), &(rhs->electrode_placement)))
  {
    return false;
  }
  // lead_type
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->lead_type), &(rhs->lead_type)))
  {
    return false;
  }
  // filters
  if (!healthcare_msgs__msg__FilterBase__are_equal(
      &(lhs->filters), &(rhs->filters)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__ECGInfo__copy(
  const healthcare_msgs__msg__ECGInfo * input,
  healthcare_msgs__msg__ECGInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__copy(
      &(input->device_info), &(output->device_info)))
  {
    return false;
  }
  // units
  output->units = input->units;
  // electrode_placement
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->electrode_placement), &(output->electrode_placement)))
  {
    return false;
  }
  // lead_type
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->lead_type), &(output->lead_type)))
  {
    return false;
  }
  // filters
  if (!healthcare_msgs__msg__FilterBase__copy(
      &(input->filters), &(output->filters)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__ECGInfo *
healthcare_msgs__msg__ECGInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__ECGInfo * msg = (healthcare_msgs__msg__ECGInfo *)allocator.allocate(sizeof(healthcare_msgs__msg__ECGInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__ECGInfo));
  bool success = healthcare_msgs__msg__ECGInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__ECGInfo__destroy(healthcare_msgs__msg__ECGInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__ECGInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__ECGInfo__Sequence__init(healthcare_msgs__msg__ECGInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__ECGInfo * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__ECGInfo *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__ECGInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__ECGInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__ECGInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__ECGInfo__Sequence__fini(healthcare_msgs__msg__ECGInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__ECGInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__ECGInfo__Sequence *
healthcare_msgs__msg__ECGInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__ECGInfo__Sequence * array = (healthcare_msgs__msg__ECGInfo__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__ECGInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__ECGInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__ECGInfo__Sequence__destroy(healthcare_msgs__msg__ECGInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__ECGInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__ECGInfo__Sequence__are_equal(const healthcare_msgs__msg__ECGInfo__Sequence * lhs, const healthcare_msgs__msg__ECGInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__ECGInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__ECGInfo__Sequence__copy(
  const healthcare_msgs__msg__ECGInfo__Sequence * input,
  healthcare_msgs__msg__ECGInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__ECGInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__ECGInfo * data =
      (healthcare_msgs__msg__ECGInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__ECGInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__ECGInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__ECGInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
