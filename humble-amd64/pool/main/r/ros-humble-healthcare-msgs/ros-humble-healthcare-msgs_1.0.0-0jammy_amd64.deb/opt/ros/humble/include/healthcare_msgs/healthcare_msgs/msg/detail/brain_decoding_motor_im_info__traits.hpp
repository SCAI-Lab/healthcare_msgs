// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingMotorImInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/brain_decoding_motor_im_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BrainDecodingMotorImInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: brain_decoding_general_info
  {
    out << "brain_decoding_general_info: ";
    to_flow_style_yaml(msg.brain_decoding_general_info, out);
    out << ", ";
  }

  // member: mi_features
  {
    if (msg.mi_features.size() == 0) {
      out << "mi_features: []";
    } else {
      out << "mi_features: [";
      size_t pending_items = msg.mi_features.size();
      for (auto item : msg.mi_features) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: comments
  {
    out << "comments: ";
    rosidl_generator_traits::value_to_yaml(msg.comments, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BrainDecodingMotorImInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: brain_decoding_general_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brain_decoding_general_info:\n";
    to_block_style_yaml(msg.brain_decoding_general_info, out, indentation + 2);
  }

  // member: mi_features
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.mi_features.size() == 0) {
      out << "mi_features: []\n";
    } else {
      out << "mi_features:\n";
      for (auto item : msg.mi_features) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: comments
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comments: ";
    rosidl_generator_traits::value_to_yaml(msg.comments, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BrainDecodingMotorImInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::BrainDecodingMotorImInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::BrainDecodingMotorImInfo & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::BrainDecodingMotorImInfo>()
{
  return "healthcare_msgs::msg::BrainDecodingMotorImInfo";
}

template<>
inline const char * name<healthcare_msgs::msg::BrainDecodingMotorImInfo>()
{
  return "healthcare_msgs/msg/BrainDecodingMotorImInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::BrainDecodingMotorImInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::BrainDecodingMotorImInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::BrainDecodingMotorImInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__TRAITS_HPP_
