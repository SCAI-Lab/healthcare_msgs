// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/HeartRate.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/heart_rate__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `session_id`
#include "rosidl_runtime_c/string_functions.h"
// Member `heart_rate`
// Member `quality`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
healthcare_msgs__msg__HeartRate__init(healthcare_msgs__msg__HeartRate * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    healthcare_msgs__msg__HeartRate__fini(msg);
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__init(&msg->session_id)) {
    healthcare_msgs__msg__HeartRate__fini(msg);
    return false;
  }
  // sample_size
  // heart_rate
  if (!rosidl_runtime_c__float__Sequence__init(&msg->heart_rate, 0)) {
    healthcare_msgs__msg__HeartRate__fini(msg);
    return false;
  }
  // quality
  if (!rosidl_runtime_c__float__Sequence__init(&msg->quality, 0)) {
    healthcare_msgs__msg__HeartRate__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__HeartRate__fini(healthcare_msgs__msg__HeartRate * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // session_id
  rosidl_runtime_c__String__fini(&msg->session_id);
  // sample_size
  // heart_rate
  rosidl_runtime_c__float__Sequence__fini(&msg->heart_rate);
  // quality
  rosidl_runtime_c__float__Sequence__fini(&msg->quality);
}

bool
healthcare_msgs__msg__HeartRate__are_equal(const healthcare_msgs__msg__HeartRate * lhs, const healthcare_msgs__msg__HeartRate * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->session_id), &(rhs->session_id)))
  {
    return false;
  }
  // sample_size
  if (lhs->sample_size != rhs->sample_size) {
    return false;
  }
  // heart_rate
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->heart_rate), &(rhs->heart_rate)))
  {
    return false;
  }
  // quality
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->quality), &(rhs->quality)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__HeartRate__copy(
  const healthcare_msgs__msg__HeartRate * input,
  healthcare_msgs__msg__HeartRate * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__copy(
      &(input->session_id), &(output->session_id)))
  {
    return false;
  }
  // sample_size
  output->sample_size = input->sample_size;
  // heart_rate
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->heart_rate), &(output->heart_rate)))
  {
    return false;
  }
  // quality
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->quality), &(output->quality)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__HeartRate *
healthcare_msgs__msg__HeartRate__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRate * msg = (healthcare_msgs__msg__HeartRate *)allocator.allocate(sizeof(healthcare_msgs__msg__HeartRate), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__HeartRate));
  bool success = healthcare_msgs__msg__HeartRate__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__HeartRate__destroy(healthcare_msgs__msg__HeartRate * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__HeartRate__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__HeartRate__Sequence__init(healthcare_msgs__msg__HeartRate__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRate * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__HeartRate *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__HeartRate), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__HeartRate__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__HeartRate__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__HeartRate__Sequence__fini(healthcare_msgs__msg__HeartRate__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__HeartRate__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__HeartRate__Sequence *
healthcare_msgs__msg__HeartRate__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRate__Sequence * array = (healthcare_msgs__msg__HeartRate__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__HeartRate__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__HeartRate__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__HeartRate__Sequence__destroy(healthcare_msgs__msg__HeartRate__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__HeartRate__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__HeartRate__Sequence__are_equal(const healthcare_msgs__msg__HeartRate__Sequence * lhs, const healthcare_msgs__msg__HeartRate__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__HeartRate__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__HeartRate__Sequence__copy(
  const healthcare_msgs__msg__HeartRate__Sequence * input,
  healthcare_msgs__msg__HeartRate__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__HeartRate);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__HeartRate * data =
      (healthcare_msgs__msg__HeartRate *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__HeartRate__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__HeartRate__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__HeartRate__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
