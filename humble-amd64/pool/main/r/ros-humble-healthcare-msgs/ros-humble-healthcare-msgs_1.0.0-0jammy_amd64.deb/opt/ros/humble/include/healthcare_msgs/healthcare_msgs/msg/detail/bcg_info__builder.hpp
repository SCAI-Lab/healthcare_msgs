// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BCGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/bcg_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BCGInfo_filters
{
public:
  explicit Init_BCGInfo_filters(::healthcare_msgs::msg::BCGInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BCGInfo filters(::healthcare_msgs::msg::BCGInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BCGInfo msg_;
};

class Init_BCGInfo_measurement_system
{
public:
  explicit Init_BCGInfo_measurement_system(::healthcare_msgs::msg::BCGInfo & msg)
  : msg_(msg)
  {}
  Init_BCGInfo_filters measurement_system(::healthcare_msgs::msg::BCGInfo::_measurement_system_type arg)
  {
    msg_.measurement_system = std::move(arg);
    return Init_BCGInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::BCGInfo msg_;
};

class Init_BCGInfo_sensing_modality
{
public:
  explicit Init_BCGInfo_sensing_modality(::healthcare_msgs::msg::BCGInfo & msg)
  : msg_(msg)
  {}
  Init_BCGInfo_measurement_system sensing_modality(::healthcare_msgs::msg::BCGInfo::_sensing_modality_type arg)
  {
    msg_.sensing_modality = std::move(arg);
    return Init_BCGInfo_measurement_system(msg_);
  }

private:
  ::healthcare_msgs::msg::BCGInfo msg_;
};

class Init_BCGInfo_sensing_direction
{
public:
  explicit Init_BCGInfo_sensing_direction(::healthcare_msgs::msg::BCGInfo & msg)
  : msg_(msg)
  {}
  Init_BCGInfo_sensing_modality sensing_direction(::healthcare_msgs::msg::BCGInfo::_sensing_direction_type arg)
  {
    msg_.sensing_direction = std::move(arg);
    return Init_BCGInfo_sensing_modality(msg_);
  }

private:
  ::healthcare_msgs::msg::BCGInfo msg_;
};

class Init_BCGInfo_sensor_placement
{
public:
  explicit Init_BCGInfo_sensor_placement(::healthcare_msgs::msg::BCGInfo & msg)
  : msg_(msg)
  {}
  Init_BCGInfo_sensing_direction sensor_placement(::healthcare_msgs::msg::BCGInfo::_sensor_placement_type arg)
  {
    msg_.sensor_placement = std::move(arg);
    return Init_BCGInfo_sensing_direction(msg_);
  }

private:
  ::healthcare_msgs::msg::BCGInfo msg_;
};

class Init_BCGInfo_units
{
public:
  explicit Init_BCGInfo_units(::healthcare_msgs::msg::BCGInfo & msg)
  : msg_(msg)
  {}
  Init_BCGInfo_sensor_placement units(::healthcare_msgs::msg::BCGInfo::_units_type arg)
  {
    msg_.units = std::move(arg);
    return Init_BCGInfo_sensor_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::BCGInfo msg_;
};

class Init_BCGInfo_device_info
{
public:
  Init_BCGInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BCGInfo_units device_info(::healthcare_msgs::msg::BCGInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_BCGInfo_units(msg_);
  }

private:
  ::healthcare_msgs::msg::BCGInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BCGInfo>()
{
  return healthcare_msgs::msg::builder::Init_BCGInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__BUILDER_HPP_
