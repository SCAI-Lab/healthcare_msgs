﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/HeartRateVariabilityInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_MS'.
/**
  * Most time-domain metrics (e.g., RMSSD, SDNN)
 */
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__UNIT_MS = 1
};

/// Constant 'UNIT_MS2'.
/**
  * Poincaré SD1, SD2 sometimes reported this way
 */
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__UNIT_MS2 = 2
};

/// Constant 'UNIT_CUSTOM'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__UNIT_CUSTOM = 255
};

/// Constant 'METHOD_UNKNOWN'.
/**
  * Measurement Method Enum
 */
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__METHOD_UNKNOWN = 0
};

/// Constant 'METHOD_PPG'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__METHOD_PPG = 1
};

/// Constant 'METHOD_ECG'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__METHOD_ECG = 2
};

/// Constant 'METHOD_CUSTOM'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__METHOD_CUSTOM = 255
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Sensor Placement Enum
 */
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_CHEST'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__PLACEMENT_CHEST = 1
};

/// Constant 'PLACEMENT_WRIST'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__PLACEMENT_WRIST = 2
};

/// Constant 'PLACEMENT_FINGER'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__PLACEMENT_FINGER = 3
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'DOMAIN_UNKNOWN'.
/**
  * HRV domain (time/frequency)
 */
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__DOMAIN_UNKNOWN = 0
};

/// Constant 'DOMAIN_TIME'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__DOMAIN_TIME = 1
};

/// Constant 'DOMAIN_FREQ'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__DOMAIN_FREQ = 2
};

/// Constant 'DOMAIN_NONLINEAR'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__DOMAIN_NONLINEAR = 3
};

/// Constant 'DOMAIN_CUSTOM'.
enum
{
  healthcare_msgs__msg__HeartRateVariabilityInfo__DOMAIN_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'sensor_placement'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/HeartRateVariabilityInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__HeartRateVariabilityInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  uint8_t unit;
  uint8_t measurement_method;
  rosidl_runtime_c__uint8__Sequence sensor_placement;
  uint8_t hrv_domain;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__HeartRateVariabilityInfo;

// Struct for a sequence of healthcare_msgs__msg__HeartRateVariabilityInfo.
typedef struct healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence
{
  healthcare_msgs__msg__HeartRateVariabilityInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__STRUCT_H_
