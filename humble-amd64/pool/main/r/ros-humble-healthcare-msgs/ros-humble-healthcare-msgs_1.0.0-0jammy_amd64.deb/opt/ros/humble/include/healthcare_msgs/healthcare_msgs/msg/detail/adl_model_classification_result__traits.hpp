// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/adl_model_classification_result__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ADLModelClassificationResult & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: device_serial_number
  {
    if (msg.device_serial_number.size() == 0) {
      out << "device_serial_number: []";
    } else {
      out << "device_serial_number: [";
      size_t pending_items = msg.device_serial_number.size();
      for (auto item : msg.device_serial_number) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: glossary
  {
    if (msg.glossary.size() == 0) {
      out << "glossary: []";
    } else {
      out << "glossary: [";
      size_t pending_items = msg.glossary.size();
      for (auto item : msg.glossary) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: class_amount
  {
    out << "class_amount: ";
    rosidl_generator_traits::value_to_yaml(msg.class_amount, out);
    out << ", ";
  }

  // member: model_type
  {
    if (msg.model_type.size() == 0) {
      out << "model_type: []";
    } else {
      out << "model_type: [";
      size_t pending_items = msg.model_type.size();
      for (auto item : msg.model_type) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: model_version
  {
    if (msg.model_version.size() == 0) {
      out << "model_version: []";
    } else {
      out << "model_version: [";
      size_t pending_items = msg.model_version.size();
      for (auto item : msg.model_version) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ADLModelClassificationResult & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: device_serial_number
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.device_serial_number.size() == 0) {
      out << "device_serial_number: []\n";
    } else {
      out << "device_serial_number:\n";
      for (auto item : msg.device_serial_number) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: glossary
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.glossary.size() == 0) {
      out << "glossary: []\n";
    } else {
      out << "glossary:\n";
      for (auto item : msg.glossary) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: class_amount
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "class_amount: ";
    rosidl_generator_traits::value_to_yaml(msg.class_amount, out);
    out << "\n";
  }

  // member: model_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.model_type.size() == 0) {
      out << "model_type: []\n";
    } else {
      out << "model_type:\n";
      for (auto item : msg.model_type) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: model_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.model_version.size() == 0) {
      out << "model_version: []\n";
    } else {
      out << "model_version:\n";
      for (auto item : msg.model_version) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ADLModelClassificationResult & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::ADLModelClassificationResult & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::ADLModelClassificationResult & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::ADLModelClassificationResult>()
{
  return "healthcare_msgs::msg::ADLModelClassificationResult";
}

template<>
inline const char * name<healthcare_msgs::msg::ADLModelClassificationResult>()
{
  return "healthcare_msgs/msg/ADLModelClassificationResult";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::ADLModelClassificationResult>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::ADLModelClassificationResult>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::ADLModelClassificationResult>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__TRAITS_HPP_
