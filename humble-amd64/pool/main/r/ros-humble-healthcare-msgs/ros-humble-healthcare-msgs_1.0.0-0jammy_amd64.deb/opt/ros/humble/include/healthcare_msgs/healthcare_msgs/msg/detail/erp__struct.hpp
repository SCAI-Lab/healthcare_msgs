// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/ERP.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ERP__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ERP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__ERP __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__ERP __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ERP_
{
  using Type = ERP_<ContainerAllocator>;

  explicit ERP_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->sample_size = 0;
      this->confidence = 0.0f;
      this->quality = 0.0f;
      this->erp_label = 0;
    }
  }

  explicit ERP_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    session_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->session_id = "";
      this->sample_size = 0;
      this->confidence = 0.0f;
      this->quality = 0.0f;
      this->erp_label = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _session_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _session_id_type session_id;
  using _sample_size_type =
    uint16_t;
  _sample_size_type sample_size;
  using _confidence_type =
    float;
  _confidence_type confidence;
  using _quality_type =
    float;
  _quality_type quality;
  using _erp_label_type =
    uint8_t;
  _erp_label_type erp_label;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__session_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->session_id = _arg;
    return *this;
  }
  Type & set__sample_size(
    const uint16_t & _arg)
  {
    this->sample_size = _arg;
    return *this;
  }
  Type & set__confidence(
    const float & _arg)
  {
    this->confidence = _arg;
    return *this;
  }
  Type & set__quality(
    const float & _arg)
  {
    this->quality = _arg;
    return *this;
  }
  Type & set__erp_label(
    const uint8_t & _arg)
  {
    this->erp_label = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t ERP_LABEL_UNKNOWN =
    0u;
  static constexpr uint8_t ERP_LABEL_P1 =
    1u;
  static constexpr uint8_t ERP_LABEL_N1 =
    2u;
  static constexpr uint8_t ERP_LABEL_P2 =
    3u;
  static constexpr uint8_t ERP_LABEL_N2 =
    4u;
  static constexpr uint8_t ERP_LABEL_P3 =
    5u;
  static constexpr uint8_t ERP_LABEL_N400 =
    6u;
  static constexpr uint8_t ERP_LABEL_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::ERP_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::ERP_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ERP_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ERP_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__ERP
    std::shared_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__ERP
    std::shared_ptr<healthcare_msgs::msg::ERP_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ERP_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->session_id != other.session_id) {
      return false;
    }
    if (this->sample_size != other.sample_size) {
      return false;
    }
    if (this->confidence != other.confidence) {
      return false;
    }
    if (this->quality != other.quality) {
      return false;
    }
    if (this->erp_label != other.erp_label) {
      return false;
    }
    return true;
  }
  bool operator!=(const ERP_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ERP_

// alias to use template instance with default allocator
using ERP =
  healthcare_msgs::msg::ERP_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_P1;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_N1;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_P2;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_N2;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_P3;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_N400;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t ERP_<ContainerAllocator>::ERP_LABEL_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ERP__STRUCT_HPP_
