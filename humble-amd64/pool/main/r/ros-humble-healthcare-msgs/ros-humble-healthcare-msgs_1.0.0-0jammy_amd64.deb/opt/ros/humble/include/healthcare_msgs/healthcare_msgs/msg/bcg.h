// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/BCG.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BCG_H_
#define HEALTHCARE_MSGS__MSG__BCG_H_

#include "healthcare_msgs/msg/detail/bcg__struct.h"
#include "healthcare_msgs/msg/detail/bcg__functions.h"
#include "healthcare_msgs/msg/detail/bcg__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__BCG_H_
