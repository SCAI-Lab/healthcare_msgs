// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/Concentration.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__CONCENTRATION_H_
#define HEALTHCARE_MSGS__MSG__CONCENTRATION_H_

#include "healthcare_msgs/msg/detail/concentration__struct.h"
#include "healthcare_msgs/msg/detail/concentration__functions.h"
#include "healthcare_msgs/msg/detail/concentration__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__CONCENTRATION_H_
