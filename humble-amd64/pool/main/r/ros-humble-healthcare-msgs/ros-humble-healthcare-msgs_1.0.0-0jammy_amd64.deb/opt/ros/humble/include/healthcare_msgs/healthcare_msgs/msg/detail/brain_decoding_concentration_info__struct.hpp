// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingConcentrationInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__BrainDecodingConcentrationInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__BrainDecodingConcentrationInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BrainDecodingConcentrationInfo_
{
  using Type = BrainDecodingConcentrationInfo_<ContainerAllocator>;

  explicit BrainDecodingConcentrationInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    brain_decoding_general_info(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->comments = "";
    }
  }

  explicit BrainDecodingConcentrationInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    brain_decoding_general_info(_alloc, _init),
    comments(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->comments = "";
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _brain_decoding_general_info_type =
    healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator>;
  _brain_decoding_general_info_type brain_decoding_general_info;
  using _comments_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _comments_type comments;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__brain_decoding_general_info(
    const healthcare_msgs::msg::BrainDecodingGeneralInfo_<ContainerAllocator> & _arg)
  {
    this->brain_decoding_general_info = _arg;
    return *this;
  }
  Type & set__comments(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->comments = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__BrainDecodingConcentrationInfo
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__BrainDecodingConcentrationInfo
    std::shared_ptr<healthcare_msgs::msg::BrainDecodingConcentrationInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BrainDecodingConcentrationInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->brain_decoding_general_info != other.brain_decoding_general_info) {
      return false;
    }
    if (this->comments != other.comments) {
      return false;
    }
    return true;
  }
  bool operator!=(const BrainDecodingConcentrationInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BrainDecodingConcentrationInfo_

// alias to use template instance with default allocator
using BrainDecodingConcentrationInfo =
  healthcare_msgs::msg::BrainDecodingConcentrationInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__STRUCT_HPP_
