// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BCGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__BCGInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_MV'.
/**
  * Millivolts (less common for BCG)
 */
enum
{
  healthcare_msgs__msg__BCGInfo__UNIT_MV = 1
};

/// Constant 'UNIT_UV'.
/**
  * Microvolts (biopotential signals, maybe less common for BCG)
 */
enum
{
  healthcare_msgs__msg__BCGInfo__UNIT_UV = 2
};

/// Constant 'UNIT_COUNTS'.
/**
  * Raw ADC counts
 */
enum
{
  healthcare_msgs__msg__BCGInfo__UNIT_COUNTS = 3
};

/// Constant 'UNIT_M_S2'.
/**
  * Meters per second squared (acceleration)
 */
enum
{
  healthcare_msgs__msg__BCGInfo__UNIT_M_S2 = 4
};

/// Constant 'UNIT_NEWTON'.
/**
  * Newtons (force)
 */
enum
{
  healthcare_msgs__msg__BCGInfo__UNIT_NEWTON = 5
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Sensor Placement Enum
 */
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_CHEST'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_CHEST = 1
};

/// Constant 'PLACEMENT_BACK'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_BACK = 2
};

/// Constant 'PLACEMENT_MATTRESS'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_MATTRESS = 3
};

/// Constant 'PLACEMENT_CHAIR'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_CHAIR = 4
};

/// Constant 'PLACEMENT_ANKLE'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_ANKLE = 5
};

/// Constant 'PLACEMENT_FOOT'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_FOOT = 6
};

/// Constant 'PLACEMENT_WRIST'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_WRIST = 7
};

/// Constant 'PLACEMENT_ARM'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_ARM = 8
};

/// Constant 'PLACEMENT_DESK'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_DESK = 9
};

/// Constant 'PLACEMENT_CLOTHING'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_CLOTHING = 10
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__BCGInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'DIRECTION_UNKNOWN'.
/**
  * Sensing Direction Enum
 */
enum
{
  healthcare_msgs__msg__BCGInfo__DIRECTION_UNKNOWN = 0
};

/// Constant 'DIRECTION_DORSO_VENTRAL'.
/**
  * Front to back
 */
enum
{
  healthcare_msgs__msg__BCGInfo__DIRECTION_DORSO_VENTRAL = 1
};

/// Constant 'DIRECTION_LONGITUDINAL'.
/**
  * Head to toe
 */
enum
{
  healthcare_msgs__msg__BCGInfo__DIRECTION_LONGITUDINAL = 2
};

/// Constant 'DIRECTION_MEDIO_LATERAL'.
/**
  * Side to side
 */
enum
{
  healthcare_msgs__msg__BCGInfo__DIRECTION_MEDIO_LATERAL = 3
};

/// Constant 'DIRECTION_CUSTOM'.
enum
{
  healthcare_msgs__msg__BCGInfo__DIRECTION_CUSTOM = 255
};

/// Constant 'MODALITY_UNKNOWN'.
/**
  * Sensing Modality Enum
 */
enum
{
  healthcare_msgs__msg__BCGInfo__MODALITY_UNKNOWN = 0
};

/// Constant 'MODALITY_PIEZOELECTRIC_FILM'.
enum
{
  healthcare_msgs__msg__BCGInfo__MODALITY_PIEZOELECTRIC_FILM = 1
};

/// Constant 'MODALITY_FORCEPLATE'.
enum
{
  healthcare_msgs__msg__BCGInfo__MODALITY_FORCEPLATE = 2
};

/// Constant 'MODALITY_ACCELEROMETER'.
enum
{
  healthcare_msgs__msg__BCGInfo__MODALITY_ACCELEROMETER = 3
};

/// Constant 'MODALITY_PIEZOELECTRIC_CRYSTAL'.
enum
{
  healthcare_msgs__msg__BCGInfo__MODALITY_PIEZOELECTRIC_CRYSTAL = 4
};

/// Constant 'MODALITY_CUSTOM'.
enum
{
  healthcare_msgs__msg__BCGInfo__MODALITY_CUSTOM = 255
};

/// Constant 'SYSTEM_UNKNOWN'.
/**
  * Measurement System Enum
 */
enum
{
  healthcare_msgs__msg__BCGInfo__SYSTEM_UNKNOWN = 0
};

/// Constant 'SYSTEM_STARR'.
enum
{
  healthcare_msgs__msg__BCGInfo__SYSTEM_STARR = 1
};

/// Constant 'SYSTEM_NICKERSON'.
enum
{
  healthcare_msgs__msg__BCGInfo__SYSTEM_NICKERSON = 2
};

/// Constant 'SYSTEM_DOCK'.
enum
{
  healthcare_msgs__msg__BCGInfo__SYSTEM_DOCK = 3
};

/// Constant 'SYSTEM_CUSTOM'.
enum
{
  healthcare_msgs__msg__BCGInfo__SYSTEM_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/BCGInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BCGInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  uint8_t units;
  uint8_t sensor_placement;
  uint8_t sensing_direction;
  uint8_t sensing_modality;
  uint8_t measurement_system;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__BCGInfo;

// Struct for a sequence of healthcare_msgs__msg__BCGInfo.
typedef struct healthcare_msgs__msg__BCGInfo__Sequence
{
  healthcare_msgs__msg__BCGInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BCGInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__STRUCT_H_
