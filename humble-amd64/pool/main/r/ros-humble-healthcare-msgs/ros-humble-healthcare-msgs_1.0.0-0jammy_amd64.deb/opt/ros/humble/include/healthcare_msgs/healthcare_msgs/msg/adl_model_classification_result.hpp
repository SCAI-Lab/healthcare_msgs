// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__ADL_MODEL_CLASSIFICATION_RESULT_HPP_
#define HEALTHCARE_MSGS__MSG__ADL_MODEL_CLASSIFICATION_RESULT_HPP_

#include "healthcare_msgs/msg/detail/adl_model_classification_result__struct.hpp"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__builder.hpp"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__traits.hpp"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__type_support.hpp"

#endif  // HEALTHCARE_MSGS__MSG__ADL_MODEL_CLASSIFICATION_RESULT_HPP_
