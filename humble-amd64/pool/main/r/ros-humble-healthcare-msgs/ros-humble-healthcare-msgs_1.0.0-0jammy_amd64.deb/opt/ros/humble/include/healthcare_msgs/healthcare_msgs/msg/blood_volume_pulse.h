// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/BloodVolumePulse.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BLOOD_VOLUME_PULSE_H_
#define HEALTHCARE_MSGS__MSG__BLOOD_VOLUME_PULSE_H_

#include "healthcare_msgs/msg/detail/blood_volume_pulse__struct.h"
#include "healthcare_msgs/msg/detail/blood_volume_pulse__functions.h"
#include "healthcare_msgs/msg/detail/blood_volume_pulse__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__BLOOD_VOLUME_PULSE_H_
