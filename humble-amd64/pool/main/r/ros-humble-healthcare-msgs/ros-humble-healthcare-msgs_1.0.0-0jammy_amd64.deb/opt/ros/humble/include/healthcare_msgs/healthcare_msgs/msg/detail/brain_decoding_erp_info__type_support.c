// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/BrainDecodingERPInfo.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__functions.h"
#include "healthcare_msgs/msg/detail/brain_decoding_erp_info__struct.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/device_info.h"
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__rosidl_typesupport_introspection_c.h"
// Member `brain_decoding_general_info`
#include "healthcare_msgs/msg/brain_decoding_general_info.h"
// Member `brain_decoding_general_info`
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__rosidl_typesupport_introspection_c.h"
// Member `erp_features`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `comments`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__BrainDecodingERPInfo__init(message_memory);
}

void healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_fini_function(void * message_memory)
{
  healthcare_msgs__msg__BrainDecodingERPInfo__fini(message_memory);
}

size_t healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__size_function__BrainDecodingERPInfo__erp_features(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__get_const_function__BrainDecodingERPInfo__erp_features(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__get_function__BrainDecodingERPInfo__erp_features(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__fetch_function__BrainDecodingERPInfo__erp_features(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__get_const_function__BrainDecodingERPInfo__erp_features(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__assign_function__BrainDecodingERPInfo__erp_features(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__get_function__BrainDecodingERPInfo__erp_features(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__resize_function__BrainDecodingERPInfo__erp_features(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_member_array[4] = {
  {
    "device_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__BrainDecodingERPInfo, device_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "brain_decoding_general_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__BrainDecodingERPInfo, brain_decoding_general_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "erp_features",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__BrainDecodingERPInfo, erp_features),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__size_function__BrainDecodingERPInfo__erp_features,  // size() function pointer
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__get_const_function__BrainDecodingERPInfo__erp_features,  // get_const(index) function pointer
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__get_function__BrainDecodingERPInfo__erp_features,  // get(index) function pointer
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__fetch_function__BrainDecodingERPInfo__erp_features,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__assign_function__BrainDecodingERPInfo__erp_features,  // assign(index, value) function pointer
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__resize_function__BrainDecodingERPInfo__erp_features  // resize(index) function pointer
  },
  {
    "comments",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__BrainDecodingERPInfo, comments),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "BrainDecodingERPInfo",  // message name
  4,  // number of fields
  sizeof(healthcare_msgs__msg__BrainDecodingERPInfo),
  healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_member_array,  // message members
  healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, BrainDecodingERPInfo)() {
  healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, DeviceInfo)();
  healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, BrainDecodingGeneralInfo)();
  if (!healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__BrainDecodingERPInfo__rosidl_typesupport_introspection_c__BrainDecodingERPInfo_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
