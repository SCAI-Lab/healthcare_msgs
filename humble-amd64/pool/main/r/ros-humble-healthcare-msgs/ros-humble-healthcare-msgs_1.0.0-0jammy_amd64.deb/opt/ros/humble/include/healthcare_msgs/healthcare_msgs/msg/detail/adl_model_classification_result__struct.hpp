// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__ADLModelClassificationResult __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__ADLModelClassificationResult __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ADLModelClassificationResult_
{
  using Type = ADLModelClassificationResult_<ContainerAllocator>;

  explicit ADLModelClassificationResult_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->class_amount = 0;
    }
  }

  explicit ADLModelClassificationResult_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->class_amount = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _device_serial_number_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _device_serial_number_type device_serial_number;
  using _glossary_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _glossary_type glossary;
  using _class_amount_type =
    uint16_t;
  _class_amount_type class_amount;
  using _model_type_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _model_type_type model_type;
  using _model_version_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _model_version_type model_version;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__device_serial_number(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->device_serial_number = _arg;
    return *this;
  }
  Type & set__glossary(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->glossary = _arg;
    return *this;
  }
  Type & set__class_amount(
    const uint16_t & _arg)
  {
    this->class_amount = _arg;
    return *this;
  }
  Type & set__model_type(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->model_type = _arg;
    return *this;
  }
  Type & set__model_version(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->model_version = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__ADLModelClassificationResult
    std::shared_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__ADLModelClassificationResult
    std::shared_ptr<healthcare_msgs::msg::ADLModelClassificationResult_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ADLModelClassificationResult_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->device_serial_number != other.device_serial_number) {
      return false;
    }
    if (this->glossary != other.glossary) {
      return false;
    }
    if (this->class_amount != other.class_amount) {
      return false;
    }
    if (this->model_type != other.model_type) {
      return false;
    }
    if (this->model_version != other.model_version) {
      return false;
    }
    return true;
  }
  bool operator!=(const ADLModelClassificationResult_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ADLModelClassificationResult_

// alias to use template instance with default allocator
using ADLModelClassificationResult =
  healthcare_msgs::msg::ADLModelClassificationResult_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__STRUCT_HPP_
