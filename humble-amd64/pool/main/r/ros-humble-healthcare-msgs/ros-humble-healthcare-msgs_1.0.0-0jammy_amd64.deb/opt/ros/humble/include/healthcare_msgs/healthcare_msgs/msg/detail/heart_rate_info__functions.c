// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/HeartRateInfo.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/heart_rate_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `device_info`
#include "healthcare_msgs/msg/detail/device_info__functions.h"
// Member `sensor_placement`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `filters`
#include "healthcare_msgs/msg/detail/filter_base__functions.h"

bool
healthcare_msgs__msg__HeartRateInfo__init(healthcare_msgs__msg__HeartRateInfo * msg)
{
  if (!msg) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__init(&msg->device_info)) {
    healthcare_msgs__msg__HeartRateInfo__fini(msg);
    return false;
  }
  // unit
  // sensor_placement
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->sensor_placement, 0)) {
    healthcare_msgs__msg__HeartRateInfo__fini(msg);
    return false;
  }
  // measurement_method
  // filters
  if (!healthcare_msgs__msg__FilterBase__init(&msg->filters)) {
    healthcare_msgs__msg__HeartRateInfo__fini(msg);
    return false;
  }
  return true;
}

void
healthcare_msgs__msg__HeartRateInfo__fini(healthcare_msgs__msg__HeartRateInfo * msg)
{
  if (!msg) {
    return;
  }
  // device_info
  healthcare_msgs__msg__DeviceInfo__fini(&msg->device_info);
  // unit
  // sensor_placement
  rosidl_runtime_c__uint8__Sequence__fini(&msg->sensor_placement);
  // measurement_method
  // filters
  healthcare_msgs__msg__FilterBase__fini(&msg->filters);
}

bool
healthcare_msgs__msg__HeartRateInfo__are_equal(const healthcare_msgs__msg__HeartRateInfo * lhs, const healthcare_msgs__msg__HeartRateInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__are_equal(
      &(lhs->device_info), &(rhs->device_info)))
  {
    return false;
  }
  // unit
  if (lhs->unit != rhs->unit) {
    return false;
  }
  // sensor_placement
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->sensor_placement), &(rhs->sensor_placement)))
  {
    return false;
  }
  // measurement_method
  if (lhs->measurement_method != rhs->measurement_method) {
    return false;
  }
  // filters
  if (!healthcare_msgs__msg__FilterBase__are_equal(
      &(lhs->filters), &(rhs->filters)))
  {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__HeartRateInfo__copy(
  const healthcare_msgs__msg__HeartRateInfo * input,
  healthcare_msgs__msg__HeartRateInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // device_info
  if (!healthcare_msgs__msg__DeviceInfo__copy(
      &(input->device_info), &(output->device_info)))
  {
    return false;
  }
  // unit
  output->unit = input->unit;
  // sensor_placement
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->sensor_placement), &(output->sensor_placement)))
  {
    return false;
  }
  // measurement_method
  output->measurement_method = input->measurement_method;
  // filters
  if (!healthcare_msgs__msg__FilterBase__copy(
      &(input->filters), &(output->filters)))
  {
    return false;
  }
  return true;
}

healthcare_msgs__msg__HeartRateInfo *
healthcare_msgs__msg__HeartRateInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRateInfo * msg = (healthcare_msgs__msg__HeartRateInfo *)allocator.allocate(sizeof(healthcare_msgs__msg__HeartRateInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__HeartRateInfo));
  bool success = healthcare_msgs__msg__HeartRateInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__HeartRateInfo__destroy(healthcare_msgs__msg__HeartRateInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__HeartRateInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__HeartRateInfo__Sequence__init(healthcare_msgs__msg__HeartRateInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRateInfo * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__HeartRateInfo *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__HeartRateInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__HeartRateInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__HeartRateInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__HeartRateInfo__Sequence__fini(healthcare_msgs__msg__HeartRateInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__HeartRateInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__HeartRateInfo__Sequence *
healthcare_msgs__msg__HeartRateInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__HeartRateInfo__Sequence * array = (healthcare_msgs__msg__HeartRateInfo__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__HeartRateInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__HeartRateInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__HeartRateInfo__Sequence__destroy(healthcare_msgs__msg__HeartRateInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__HeartRateInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__HeartRateInfo__Sequence__are_equal(const healthcare_msgs__msg__HeartRateInfo__Sequence * lhs, const healthcare_msgs__msg__HeartRateInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__HeartRateInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__HeartRateInfo__Sequence__copy(
  const healthcare_msgs__msg__HeartRateInfo__Sequence * input,
  healthcare_msgs__msg__HeartRateInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__HeartRateInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__HeartRateInfo * data =
      (healthcare_msgs__msg__HeartRateInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__HeartRateInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__HeartRateInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__HeartRateInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
