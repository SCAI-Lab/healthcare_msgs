// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/Concentration.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/concentration__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `session_id`
#include "rosidl_runtime_c/string_functions.h"

bool
healthcare_msgs__msg__Concentration__init(healthcare_msgs__msg__Concentration * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    healthcare_msgs__msg__Concentration__fini(msg);
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__init(&msg->session_id)) {
    healthcare_msgs__msg__Concentration__fini(msg);
    return false;
  }
  // sample_size
  // concentration_score
  // confidence
  // is_concentrated
  // quality
  return true;
}

void
healthcare_msgs__msg__Concentration__fini(healthcare_msgs__msg__Concentration * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // session_id
  rosidl_runtime_c__String__fini(&msg->session_id);
  // sample_size
  // concentration_score
  // confidence
  // is_concentrated
  // quality
}

bool
healthcare_msgs__msg__Concentration__are_equal(const healthcare_msgs__msg__Concentration * lhs, const healthcare_msgs__msg__Concentration * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->session_id), &(rhs->session_id)))
  {
    return false;
  }
  // sample_size
  if (lhs->sample_size != rhs->sample_size) {
    return false;
  }
  // concentration_score
  if (lhs->concentration_score != rhs->concentration_score) {
    return false;
  }
  // confidence
  if (lhs->confidence != rhs->confidence) {
    return false;
  }
  // is_concentrated
  if (lhs->is_concentrated != rhs->is_concentrated) {
    return false;
  }
  // quality
  if (lhs->quality != rhs->quality) {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__Concentration__copy(
  const healthcare_msgs__msg__Concentration * input,
  healthcare_msgs__msg__Concentration * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__copy(
      &(input->session_id), &(output->session_id)))
  {
    return false;
  }
  // sample_size
  output->sample_size = input->sample_size;
  // concentration_score
  output->concentration_score = input->concentration_score;
  // confidence
  output->confidence = input->confidence;
  // is_concentrated
  output->is_concentrated = input->is_concentrated;
  // quality
  output->quality = input->quality;
  return true;
}

healthcare_msgs__msg__Concentration *
healthcare_msgs__msg__Concentration__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__Concentration * msg = (healthcare_msgs__msg__Concentration *)allocator.allocate(sizeof(healthcare_msgs__msg__Concentration), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__Concentration));
  bool success = healthcare_msgs__msg__Concentration__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__Concentration__destroy(healthcare_msgs__msg__Concentration * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__Concentration__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__Concentration__Sequence__init(healthcare_msgs__msg__Concentration__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__Concentration * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__Concentration *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__Concentration), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__Concentration__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__Concentration__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__Concentration__Sequence__fini(healthcare_msgs__msg__Concentration__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__Concentration__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__Concentration__Sequence *
healthcare_msgs__msg__Concentration__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__Concentration__Sequence * array = (healthcare_msgs__msg__Concentration__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__Concentration__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__Concentration__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__Concentration__Sequence__destroy(healthcare_msgs__msg__Concentration__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__Concentration__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__Concentration__Sequence__are_equal(const healthcare_msgs__msg__Concentration__Sequence * lhs, const healthcare_msgs__msg__Concentration__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__Concentration__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__Concentration__Sequence__copy(
  const healthcare_msgs__msg__Concentration__Sequence * input,
  healthcare_msgs__msg__Concentration__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__Concentration);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__Concentration * data =
      (healthcare_msgs__msg__Concentration *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__Concentration__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__Concentration__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__Concentration__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
