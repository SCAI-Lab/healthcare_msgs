// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/ECG.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ECG__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ECG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/ecg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_ECG_signal_quality
{
public:
  explicit Init_ECG_signal_quality(::healthcare_msgs::msg::ECG & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::ECG signal_quality(::healthcare_msgs::msg::ECG::_signal_quality_type arg)
  {
    msg_.signal_quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::ECG msg_;
};

class Init_ECG_ecg
{
public:
  explicit Init_ECG_ecg(::healthcare_msgs::msg::ECG & msg)
  : msg_(msg)
  {}
  Init_ECG_signal_quality ecg(::healthcare_msgs::msg::ECG::_ecg_type arg)
  {
    msg_.ecg = std::move(arg);
    return Init_ECG_signal_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::ECG msg_;
};

class Init_ECG_sample_size
{
public:
  explicit Init_ECG_sample_size(::healthcare_msgs::msg::ECG & msg)
  : msg_(msg)
  {}
  Init_ECG_ecg sample_size(::healthcare_msgs::msg::ECG::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_ECG_ecg(msg_);
  }

private:
  ::healthcare_msgs::msg::ECG msg_;
};

class Init_ECG_channel_size
{
public:
  explicit Init_ECG_channel_size(::healthcare_msgs::msg::ECG & msg)
  : msg_(msg)
  {}
  Init_ECG_sample_size channel_size(::healthcare_msgs::msg::ECG::_channel_size_type arg)
  {
    msg_.channel_size = std::move(arg);
    return Init_ECG_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::ECG msg_;
};

class Init_ECG_session_id
{
public:
  explicit Init_ECG_session_id(::healthcare_msgs::msg::ECG & msg)
  : msg_(msg)
  {}
  Init_ECG_channel_size session_id(::healthcare_msgs::msg::ECG::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_ECG_channel_size(msg_);
  }

private:
  ::healthcare_msgs::msg::ECG msg_;
};

class Init_ECG_header
{
public:
  Init_ECG_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ECG_session_id header(::healthcare_msgs::msg::ECG::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ECG_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::ECG msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::ECG>()
{
  return healthcare_msgs::msg::builder::Init_ECG_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ECG__BUILDER_HPP_
