// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/CardiacOutput.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/cardiac_output__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_CardiacOutput_quality
{
public:
  explicit Init_CardiacOutput_quality(::healthcare_msgs::msg::CardiacOutput & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::CardiacOutput quality(::healthcare_msgs::msg::CardiacOutput::_quality_type arg)
  {
    msg_.quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutput msg_;
};

class Init_CardiacOutput_cardiac_output
{
public:
  explicit Init_CardiacOutput_cardiac_output(::healthcare_msgs::msg::CardiacOutput & msg)
  : msg_(msg)
  {}
  Init_CardiacOutput_quality cardiac_output(::healthcare_msgs::msg::CardiacOutput::_cardiac_output_type arg)
  {
    msg_.cardiac_output = std::move(arg);
    return Init_CardiacOutput_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutput msg_;
};

class Init_CardiacOutput_sample_size
{
public:
  explicit Init_CardiacOutput_sample_size(::healthcare_msgs::msg::CardiacOutput & msg)
  : msg_(msg)
  {}
  Init_CardiacOutput_cardiac_output sample_size(::healthcare_msgs::msg::CardiacOutput::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_CardiacOutput_cardiac_output(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutput msg_;
};

class Init_CardiacOutput_session_id
{
public:
  explicit Init_CardiacOutput_session_id(::healthcare_msgs::msg::CardiacOutput & msg)
  : msg_(msg)
  {}
  Init_CardiacOutput_sample_size session_id(::healthcare_msgs::msg::CardiacOutput::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_CardiacOutput_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutput msg_;
};

class Init_CardiacOutput_header
{
public:
  Init_CardiacOutput_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CardiacOutput_session_id header(::healthcare_msgs::msg::CardiacOutput::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CardiacOutput_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutput msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::CardiacOutput>()
{
  return healthcare_msgs::msg::builder::Init_CardiacOutput_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT__BUILDER_HPP_
