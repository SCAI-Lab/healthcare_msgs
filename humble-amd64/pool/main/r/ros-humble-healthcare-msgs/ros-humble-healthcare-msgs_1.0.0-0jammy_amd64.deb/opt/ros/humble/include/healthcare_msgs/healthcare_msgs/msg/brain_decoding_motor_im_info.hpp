// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BRAIN_DECODING_MOTOR_IM_INFO_HPP_
#define HEALTHCARE_MSGS__MSG__BRAIN_DECODING_MOTOR_IM_INFO_HPP_

#include "healthcare_msgs/msg/detail/brain_decoding_motor_im_info__struct.hpp"
#include "healthcare_msgs/msg/detail/brain_decoding_motor_im_info__builder.hpp"
#include "healthcare_msgs/msg/detail/brain_decoding_motor_im_info__traits.hpp"
#include "healthcare_msgs/msg/detail/brain_decoding_motor_im_info__type_support.hpp"

#endif  // HEALTHCARE_MSGS__MSG__BRAIN_DECODING_MOTOR_IM_INFO_HPP_
