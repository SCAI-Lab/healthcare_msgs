// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/ERP.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ERP__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__ERP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'ERP_LABEL_UNKNOWN'.
/**
  * ERP Label Enum
  * Default / undefined
 */
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_UNKNOWN = 0
};

/// Constant 'ERP_LABEL_P1'.
/**
  * Early sensory positive peak (~50-100ms)
 */
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_P1 = 1
};

/// Constant 'ERP_LABEL_N1'.
/**
  * Early sensory negative peak (~100-150ms)
 */
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_N1 = 2
};

/// Constant 'ERP_LABEL_P2'.
/**
  * Secondary positive peak (~150-200ms)
 */
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_P2 = 3
};

/// Constant 'ERP_LABEL_N2'.
/**
  * Negative peak, cognitive processing (~200-300ms)
 */
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_N2 = 4
};

/// Constant 'ERP_LABEL_P3'.
/**
  * P300 component (~300-500ms), attention-related
 */
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_P3 = 5
};

/// Constant 'ERP_LABEL_N400'.
/**
  * Semantic incongruity (~400ms)
 */
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_N400 = 6
};

/// Constant 'ERP_LABEL_CUSTOM'.
enum
{
  healthcare_msgs__msg__ERP__ERP_LABEL_CUSTOM = 255
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ERP in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__ERP
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint16_t sample_size;
  /// Output Values
  ///  0-1 Optional model confidence
  float confidence;
  /// From 0 (poor) to 1 (excellent)
  float quality;
  /// Decision of the output model
  uint8_t erp_label;
} healthcare_msgs__msg__ERP;

// Struct for a sequence of healthcare_msgs__msg__ERP.
typedef struct healthcare_msgs__msg__ERP__Sequence
{
  healthcare_msgs__msg__ERP * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__ERP__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ERP__STRUCT_H_
