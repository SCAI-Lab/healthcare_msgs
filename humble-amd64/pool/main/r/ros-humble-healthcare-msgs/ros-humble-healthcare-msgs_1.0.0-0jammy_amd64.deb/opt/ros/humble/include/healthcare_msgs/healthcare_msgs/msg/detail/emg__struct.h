// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EMG.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EMG__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EMG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"
// Member 'emg'
// Member 'signal_quality'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/EMG in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EMG
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint8_t channel_size;
  uint16_t sample_size;
  /// Raw or filtered EMG values [channel]x[sample]
  rosidl_runtime_c__float__Sequence emg;
  /// From 0 (poor) to 1 (excellent)
  rosidl_runtime_c__float__Sequence signal_quality;
} healthcare_msgs__msg__EMG;

// Struct for a sequence of healthcare_msgs__msg__EMG.
typedef struct healthcare_msgs__msg__EMG__Sequence
{
  healthcare_msgs__msg__EMG * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EMG__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EMG__STRUCT_H_
