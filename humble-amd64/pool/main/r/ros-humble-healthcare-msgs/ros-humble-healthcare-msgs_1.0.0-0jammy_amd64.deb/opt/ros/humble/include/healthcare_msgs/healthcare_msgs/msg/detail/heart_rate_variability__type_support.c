// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/HeartRateVariability.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/heart_rate_variability__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/heart_rate_variability__functions.h"
#include "healthcare_msgs/msg/detail/heart_rate_variability__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `session_id`
#include "rosidl_runtime_c/string_functions.h"
// Member `hrv`
// Member `quality`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__HeartRateVariability__init(message_memory);
}

void healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_fini_function(void * message_memory)
{
  healthcare_msgs__msg__HeartRateVariability__fini(message_memory);
}

size_t healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__size_function__HeartRateVariability__hrv(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_const_function__HeartRateVariability__hrv(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_function__HeartRateVariability__hrv(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__fetch_function__HeartRateVariability__hrv(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_const_function__HeartRateVariability__hrv(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__assign_function__HeartRateVariability__hrv(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_function__HeartRateVariability__hrv(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__resize_function__HeartRateVariability__hrv(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__size_function__HeartRateVariability__quality(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_const_function__HeartRateVariability__quality(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_function__HeartRateVariability__quality(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__fetch_function__HeartRateVariability__quality(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_const_function__HeartRateVariability__quality(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__assign_function__HeartRateVariability__quality(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_function__HeartRateVariability__quality(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__resize_function__HeartRateVariability__quality(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_member_array[5] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__HeartRateVariability, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "session_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__HeartRateVariability, session_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sample_size",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__HeartRateVariability, sample_size),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "hrv",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__HeartRateVariability, hrv),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__size_function__HeartRateVariability__hrv,  // size() function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_const_function__HeartRateVariability__hrv,  // get_const(index) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_function__HeartRateVariability__hrv,  // get(index) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__fetch_function__HeartRateVariability__hrv,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__assign_function__HeartRateVariability__hrv,  // assign(index, value) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__resize_function__HeartRateVariability__hrv  // resize(index) function pointer
  },
  {
    "quality",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__HeartRateVariability, quality),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__size_function__HeartRateVariability__quality,  // size() function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_const_function__HeartRateVariability__quality,  // get_const(index) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__get_function__HeartRateVariability__quality,  // get(index) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__fetch_function__HeartRateVariability__quality,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__assign_function__HeartRateVariability__quality,  // assign(index, value) function pointer
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__resize_function__HeartRateVariability__quality  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "HeartRateVariability",  // message name
  5,  // number of fields
  sizeof(healthcare_msgs__msg__HeartRateVariability),
  healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_member_array,  // message members
  healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, HeartRateVariability)() {
  healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__HeartRateVariability__rosidl_typesupport_introspection_c__HeartRateVariability_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
