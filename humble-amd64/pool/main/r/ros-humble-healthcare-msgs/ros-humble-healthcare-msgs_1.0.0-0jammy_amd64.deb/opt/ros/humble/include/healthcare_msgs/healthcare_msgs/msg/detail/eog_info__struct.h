﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EOGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__EOGInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_UV'.
enum
{
  healthcare_msgs__msg__EOGInfo__UNIT_UV = 1
};

/// Constant 'UNIT_MV'.
enum
{
  healthcare_msgs__msg__EOGInfo__UNIT_MV = 2
};

/// Constant 'UNIT_COUNTS'.
enum
{
  healthcare_msgs__msg__EOGInfo__UNIT_COUNTS = 3
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Electrode Placement Enum
 */
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_LEFT_EYE'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_LEFT_EYE = 1
};

/// Constant 'PLACEMENT_RIGHT_EYE'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_RIGHT_EYE = 2
};

/// Constant 'PLACEMENT_FOREHEAD'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_FOREHEAD = 3
};

/// Constant 'PLACEMENT_TEMPLE_LEFT'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_TEMPLE_LEFT = 4
};

/// Constant 'PLACEMENT_TEMPLE_RIGHT'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_TEMPLE_RIGHT = 5
};

/// Constant 'PLACEMENT_ABOVE_EYE'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_ABOVE_EYE = 6
};

/// Constant 'PLACEMENT_BELOW_EYE'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_BELOW_EYE = 7
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__EOGInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'LEAD_UNKNOWN'.
/**
  * Lead Type Enum
 */
enum
{
  healthcare_msgs__msg__EOGInfo__LEAD_UNKNOWN = 0
};

/// Constant 'LEAD_BIPOLAR_HORIZONTAL'.
enum
{
  healthcare_msgs__msg__EOGInfo__LEAD_BIPOLAR_HORIZONTAL = 1
};

/// Constant 'LEAD_BIPOLAR_VERTICAL'.
enum
{
  healthcare_msgs__msg__EOGInfo__LEAD_BIPOLAR_VERTICAL = 2
};

/// Constant 'LEAD_UNIPOLAR'.
enum
{
  healthcare_msgs__msg__EOGInfo__LEAD_UNIPOLAR = 3
};

/// Constant 'LEAD_CORNEAL_RETINAL'.
enum
{
  healthcare_msgs__msg__EOGInfo__LEAD_CORNEAL_RETINAL = 4
};

/// Constant 'LEAD_CUSTOM'.
enum
{
  healthcare_msgs__msg__EOGInfo__LEAD_CUSTOM = 255
};

/// Constant 'MODE_UNKNOWN'.
/**
  * Signal Mode Enum
 */
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_UNKNOWN = 0
};

/// Constant 'MODE_SURFACE'.
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_SURFACE = 1
};

/// Constant 'MODE_BIPOLAR'.
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_BIPOLAR = 2
};

/// Constant 'MODE_UNIPOLAR'.
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_UNIPOLAR = 3
};

/// Constant 'MODE_CORNEAL_RETINAL'.
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_CORNEAL_RETINAL = 4
};

/// Constant 'MODE_INTRACULAR'.
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_INTRACULAR = 5
};

/// Constant 'MODE_DERIVED'.
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_DERIVED = 6
};

/// Constant 'MODE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EOGInfo__MODE_CUSTOM = 255
};

/// Constant 'LIGHTSOURCE_UNKNOWN'.
/**
  * Lighting Condition Enum (optional but useful in gaze tracking or visual response studies)
 */
enum
{
  healthcare_msgs__msg__EOGInfo__LIGHTSOURCE_UNKNOWN = 0
};

/// Constant 'LIGHTSOURCE_TUNGSTEN'.
enum
{
  healthcare_msgs__msg__EOGInfo__LIGHTSOURCE_TUNGSTEN = 1
};

/// Constant 'LIGHTSOURCE_HALOGEN'.
enum
{
  healthcare_msgs__msg__EOGInfo__LIGHTSOURCE_HALOGEN = 2
};

/// Constant 'LIGHTSOURCE_LED'.
enum
{
  healthcare_msgs__msg__EOGInfo__LIGHTSOURCE_LED = 3
};

/// Constant 'LIGHTSOURCE_FLUORESCENT'.
enum
{
  healthcare_msgs__msg__EOGInfo__LIGHTSOURCE_FLUORESCENT = 4
};

/// Constant 'LIGHTSOURCE_SUNLIGHT'.
enum
{
  healthcare_msgs__msg__EOGInfo__LIGHTSOURCE_SUNLIGHT = 5
};

/// Constant 'LIGHTSOURCE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EOGInfo__LIGHTSOURCE_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'electrode_placement'
// Member 'lead_type'
// Member 'length_light_dark_phase'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/EOGInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EOGInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  uint8_t units;
  /// Support multiple placements
  rosidl_runtime_c__uint8__Sequence electrode_placement;
  /// One per channel
  rosidl_runtime_c__uint8__Sequence lead_type;
  uint8_t signal_mode;
  uint8_t lightsource;
  /// cd/m²
  float gazefield_background_light_brightness;
  /// Alternating light/dark phases (e.g., for visual stimulation protocols)
  /// [light_sec1, dark_sec1, light_sec2, dark_sec2, ...]
  rosidl_runtime_c__float__Sequence length_light_dark_phase;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__EOGInfo;

// Struct for a sequence of healthcare_msgs__msg__EOGInfo.
typedef struct healthcare_msgs__msg__EOGInfo__Sequence
{
  healthcare_msgs__msg__EOGInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EOGInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EOG_INFO__STRUCT_H_
