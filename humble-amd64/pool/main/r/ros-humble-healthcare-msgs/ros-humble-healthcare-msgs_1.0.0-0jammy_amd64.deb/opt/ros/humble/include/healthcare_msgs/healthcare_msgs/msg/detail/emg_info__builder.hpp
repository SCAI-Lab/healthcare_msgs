// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EMGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/emg_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EMGInfo_filters
{
public:
  explicit Init_EMGInfo_filters(::healthcare_msgs::msg::EMGInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EMGInfo filters(::healthcare_msgs::msg::EMGInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EMGInfo msg_;
};

class Init_EMGInfo_signal_mode
{
public:
  explicit Init_EMGInfo_signal_mode(::healthcare_msgs::msg::EMGInfo & msg)
  : msg_(msg)
  {}
  Init_EMGInfo_filters signal_mode(::healthcare_msgs::msg::EMGInfo::_signal_mode_type arg)
  {
    msg_.signal_mode = std::move(arg);
    return Init_EMGInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::EMGInfo msg_;
};

class Init_EMGInfo_external_devices
{
public:
  explicit Init_EMGInfo_external_devices(::healthcare_msgs::msg::EMGInfo & msg)
  : msg_(msg)
  {}
  Init_EMGInfo_signal_mode external_devices(::healthcare_msgs::msg::EMGInfo::_external_devices_type arg)
  {
    msg_.external_devices = std::move(arg);
    return Init_EMGInfo_signal_mode(msg_);
  }

private:
  ::healthcare_msgs::msg::EMGInfo msg_;
};

class Init_EMGInfo_electrode_type
{
public:
  explicit Init_EMGInfo_electrode_type(::healthcare_msgs::msg::EMGInfo & msg)
  : msg_(msg)
  {}
  Init_EMGInfo_external_devices electrode_type(::healthcare_msgs::msg::EMGInfo::_electrode_type_type arg)
  {
    msg_.electrode_type = std::move(arg);
    return Init_EMGInfo_external_devices(msg_);
  }

private:
  ::healthcare_msgs::msg::EMGInfo msg_;
};

class Init_EMGInfo_electrode_placement
{
public:
  explicit Init_EMGInfo_electrode_placement(::healthcare_msgs::msg::EMGInfo & msg)
  : msg_(msg)
  {}
  Init_EMGInfo_electrode_type electrode_placement(::healthcare_msgs::msg::EMGInfo::_electrode_placement_type arg)
  {
    msg_.electrode_placement = std::move(arg);
    return Init_EMGInfo_electrode_type(msg_);
  }

private:
  ::healthcare_msgs::msg::EMGInfo msg_;
};

class Init_EMGInfo_units
{
public:
  explicit Init_EMGInfo_units(::healthcare_msgs::msg::EMGInfo & msg)
  : msg_(msg)
  {}
  Init_EMGInfo_electrode_placement units(::healthcare_msgs::msg::EMGInfo::_units_type arg)
  {
    msg_.units = std::move(arg);
    return Init_EMGInfo_electrode_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::EMGInfo msg_;
};

class Init_EMGInfo_device_info
{
public:
  Init_EMGInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EMGInfo_units device_info(::healthcare_msgs::msg::EMGInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_EMGInfo_units(msg_);
  }

private:
  ::healthcare_msgs::msg::EMGInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EMGInfo>()
{
  return healthcare_msgs::msg::builder::Init_EMGInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EMG_INFO__BUILDER_HPP_
