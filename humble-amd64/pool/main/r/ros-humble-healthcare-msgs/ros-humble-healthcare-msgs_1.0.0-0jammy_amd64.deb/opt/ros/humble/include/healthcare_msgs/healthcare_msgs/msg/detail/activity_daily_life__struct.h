// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/ActivityDailyLife.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'ADL_UNKNOWN'.
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_UNKNOWN = 0
};

/// Constant 'ADL_BATHING'.
/**
  * Basic ADL (Self-Care)
  * ICF d510
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_BATHING = 1
};

/// Constant 'ADL_DRESSING'.
/**
  * ICF d540
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_DRESSING = 2
};

/// Constant 'ADL_EATING'.
/**
  * ICF d550
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_EATING = 3
};

/// Constant 'ADL_TOILETING'.
/**
  * ICF d530
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_TOILETING = 4
};

/// Constant 'ADL_GROOMING'.
/**
  * ICF d520
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_GROOMING = 5
};

/// Constant 'ADL_TRANSFERRING'.
/**
  * ICF d420 (Changing basic body position)
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_TRANSFERRING = 6
};

/// Constant 'ADL_MOBILITY'.
/**
  * ICF d450 (Walking)
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_MOBILITY = 7
};

/// Constant 'ADL_CONTINENCE'.
/**
  * ICF d5301 (Regulating urination)
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_CONTINENCE = 8
};

/// Constant 'ADL_COOKING'.
/**
  * Instrumental ADL (Independent Living)
  * ICF d630
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_COOKING = 20
};

/// Constant 'ADL_CLEANING'.
/**
  * ICF d640
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_CLEANING = 21
};

/// Constant 'ADL_LAUNDRY'.
/**
  * ICF d6401
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_LAUNDRY = 22
};

/// Constant 'ADL_SHOPPING'.
/**
  * ICF d620
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_SHOPPING = 23
};

/// Constant 'ADL_USING_TRANSPORTATION'.
/**
  * ICF d470
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_USING_TRANSPORTATION = 24
};

/// Constant 'ADL_MANAGING_FINANCES'.
/**
  * ICF d860
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_MANAGING_FINANCES = 25
};

/// Constant 'ADL_USING_TELEPHONE'.
/**
  * ICF d360
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_USING_TELEPHONE = 26
};

/// Constant 'ADL_TAKING_MEDICATION'.
/**
  * ICF d5702
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_TAKING_MEDICATION = 27
};

/// Constant 'ADL_SOCIAL_INTERACTION'.
/**
  * Leisure & Social Participation
  * ICF d750
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_SOCIAL_INTERACTION = 40
};

/// Constant 'ADL_RECREATION'.
/**
  * ICF d920
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_RECREATION = 41
};

/// Constant 'ADL_COMMUNITY_ACTIVITY'.
/**
  * ICF d910
 */
enum
{
  healthcare_msgs__msg__ActivityDailyLife__ADL_COMMUNITY_ACTIVITY = 42
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ActivityDailyLife in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__ActivityDailyLife
{
  std_msgs__msg__Header header;
  /// Activity of daily life
  uint16_t adl;
  /// Model prediction confidence level from 0 (poor) to 1 (excellent)
  float confidence;
} healthcare_msgs__msg__ActivityDailyLife;

// Struct for a sequence of healthcare_msgs__msg__ActivityDailyLife.
typedef struct healthcare_msgs__msg__ActivityDailyLife__Sequence
{
  healthcare_msgs__msg__ActivityDailyLife * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__ActivityDailyLife__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__STRUCT_H_
