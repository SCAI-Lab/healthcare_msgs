// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingConcentrationInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BrainDecodingConcentrationInfo_comments
{
public:
  explicit Init_BrainDecodingConcentrationInfo_comments(::healthcare_msgs::msg::BrainDecodingConcentrationInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BrainDecodingConcentrationInfo comments(::healthcare_msgs::msg::BrainDecodingConcentrationInfo::_comments_type arg)
  {
    msg_.comments = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingConcentrationInfo msg_;
};

class Init_BrainDecodingConcentrationInfo_brain_decoding_general_info
{
public:
  explicit Init_BrainDecodingConcentrationInfo_brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingConcentrationInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingConcentrationInfo_comments brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingConcentrationInfo::_brain_decoding_general_info_type arg)
  {
    msg_.brain_decoding_general_info = std::move(arg);
    return Init_BrainDecodingConcentrationInfo_comments(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingConcentrationInfo msg_;
};

class Init_BrainDecodingConcentrationInfo_device_info
{
public:
  Init_BrainDecodingConcentrationInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BrainDecodingConcentrationInfo_brain_decoding_general_info device_info(::healthcare_msgs::msg::BrainDecodingConcentrationInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_BrainDecodingConcentrationInfo_brain_decoding_general_info(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingConcentrationInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BrainDecodingConcentrationInfo>()
{
  return healthcare_msgs::msg::builder::Init_BrainDecodingConcentrationInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_CONCENTRATION_INFO__BUILDER_HPP_
