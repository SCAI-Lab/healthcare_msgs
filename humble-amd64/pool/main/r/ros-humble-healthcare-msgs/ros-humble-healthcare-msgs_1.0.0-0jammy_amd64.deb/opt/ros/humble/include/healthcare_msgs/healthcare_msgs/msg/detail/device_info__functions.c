// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from healthcare_msgs:msg/DeviceInfo.idl
// generated code does not contain a copyright notice
#include "healthcare_msgs/msg/detail/device_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `session_id`
// Member `device_manufacturer`
// Member `device_name`
// Member `device_type`
// Member `device_serial_number`
// Member `measuring_unit`
#include "rosidl_runtime_c/string_functions.h"
// Member `mds`
#include "healthcare_msgs/msg/detail/medical_device_system__functions.h"

bool
healthcare_msgs__msg__DeviceInfo__init(healthcare_msgs__msg__DeviceInfo * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__init(&msg->session_id)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // mds
  if (!healthcare_msgs__msg__MedicalDeviceSystem__init(&msg->mds)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // device_manufacturer
  if (!rosidl_runtime_c__String__init(&msg->device_manufacturer)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // device_name
  if (!rosidl_runtime_c__String__init(&msg->device_name)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // device_type
  if (!rosidl_runtime_c__String__init(&msg->device_type)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // device_serial_number
  if (!rosidl_runtime_c__String__init(&msg->device_serial_number)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // minimal_operation_temperature
  // maximal_operation_temperature
  // maximal_relative_humidity
  // minimal_atmospheric_pressure
  // maximal_atmospheric_pressure
  // measuring_unit
  if (!rosidl_runtime_c__String__init(&msg->measuring_unit)) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
    return false;
  }
  // acquisition_rate_hz
  // gain
  // resolution
  // adc_resolution
  // accuracy
  // max_range
  // min_range
  // window_size_samples
  // quality_window_size_samples
  // stride_length
  return true;
}

void
healthcare_msgs__msg__DeviceInfo__fini(healthcare_msgs__msg__DeviceInfo * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // session_id
  rosidl_runtime_c__String__fini(&msg->session_id);
  // mds
  healthcare_msgs__msg__MedicalDeviceSystem__fini(&msg->mds);
  // device_manufacturer
  rosidl_runtime_c__String__fini(&msg->device_manufacturer);
  // device_name
  rosidl_runtime_c__String__fini(&msg->device_name);
  // device_type
  rosidl_runtime_c__String__fini(&msg->device_type);
  // device_serial_number
  rosidl_runtime_c__String__fini(&msg->device_serial_number);
  // minimal_operation_temperature
  // maximal_operation_temperature
  // maximal_relative_humidity
  // minimal_atmospheric_pressure
  // maximal_atmospheric_pressure
  // measuring_unit
  rosidl_runtime_c__String__fini(&msg->measuring_unit);
  // acquisition_rate_hz
  // gain
  // resolution
  // adc_resolution
  // accuracy
  // max_range
  // min_range
  // window_size_samples
  // quality_window_size_samples
  // stride_length
}

bool
healthcare_msgs__msg__DeviceInfo__are_equal(const healthcare_msgs__msg__DeviceInfo * lhs, const healthcare_msgs__msg__DeviceInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->session_id), &(rhs->session_id)))
  {
    return false;
  }
  // mds
  if (!healthcare_msgs__msg__MedicalDeviceSystem__are_equal(
      &(lhs->mds), &(rhs->mds)))
  {
    return false;
  }
  // device_manufacturer
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->device_manufacturer), &(rhs->device_manufacturer)))
  {
    return false;
  }
  // device_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->device_name), &(rhs->device_name)))
  {
    return false;
  }
  // device_type
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->device_type), &(rhs->device_type)))
  {
    return false;
  }
  // device_serial_number
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->device_serial_number), &(rhs->device_serial_number)))
  {
    return false;
  }
  // minimal_operation_temperature
  if (lhs->minimal_operation_temperature != rhs->minimal_operation_temperature) {
    return false;
  }
  // maximal_operation_temperature
  if (lhs->maximal_operation_temperature != rhs->maximal_operation_temperature) {
    return false;
  }
  // maximal_relative_humidity
  if (lhs->maximal_relative_humidity != rhs->maximal_relative_humidity) {
    return false;
  }
  // minimal_atmospheric_pressure
  if (lhs->minimal_atmospheric_pressure != rhs->minimal_atmospheric_pressure) {
    return false;
  }
  // maximal_atmospheric_pressure
  if (lhs->maximal_atmospheric_pressure != rhs->maximal_atmospheric_pressure) {
    return false;
  }
  // measuring_unit
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->measuring_unit), &(rhs->measuring_unit)))
  {
    return false;
  }
  // acquisition_rate_hz
  if (lhs->acquisition_rate_hz != rhs->acquisition_rate_hz) {
    return false;
  }
  // gain
  if (lhs->gain != rhs->gain) {
    return false;
  }
  // resolution
  if (lhs->resolution != rhs->resolution) {
    return false;
  }
  // adc_resolution
  if (lhs->adc_resolution != rhs->adc_resolution) {
    return false;
  }
  // accuracy
  if (lhs->accuracy != rhs->accuracy) {
    return false;
  }
  // max_range
  if (lhs->max_range != rhs->max_range) {
    return false;
  }
  // min_range
  if (lhs->min_range != rhs->min_range) {
    return false;
  }
  // window_size_samples
  if (lhs->window_size_samples != rhs->window_size_samples) {
    return false;
  }
  // quality_window_size_samples
  if (lhs->quality_window_size_samples != rhs->quality_window_size_samples) {
    return false;
  }
  // stride_length
  if (lhs->stride_length != rhs->stride_length) {
    return false;
  }
  return true;
}

bool
healthcare_msgs__msg__DeviceInfo__copy(
  const healthcare_msgs__msg__DeviceInfo * input,
  healthcare_msgs__msg__DeviceInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // session_id
  if (!rosidl_runtime_c__String__copy(
      &(input->session_id), &(output->session_id)))
  {
    return false;
  }
  // mds
  if (!healthcare_msgs__msg__MedicalDeviceSystem__copy(
      &(input->mds), &(output->mds)))
  {
    return false;
  }
  // device_manufacturer
  if (!rosidl_runtime_c__String__copy(
      &(input->device_manufacturer), &(output->device_manufacturer)))
  {
    return false;
  }
  // device_name
  if (!rosidl_runtime_c__String__copy(
      &(input->device_name), &(output->device_name)))
  {
    return false;
  }
  // device_type
  if (!rosidl_runtime_c__String__copy(
      &(input->device_type), &(output->device_type)))
  {
    return false;
  }
  // device_serial_number
  if (!rosidl_runtime_c__String__copy(
      &(input->device_serial_number), &(output->device_serial_number)))
  {
    return false;
  }
  // minimal_operation_temperature
  output->minimal_operation_temperature = input->minimal_operation_temperature;
  // maximal_operation_temperature
  output->maximal_operation_temperature = input->maximal_operation_temperature;
  // maximal_relative_humidity
  output->maximal_relative_humidity = input->maximal_relative_humidity;
  // minimal_atmospheric_pressure
  output->minimal_atmospheric_pressure = input->minimal_atmospheric_pressure;
  // maximal_atmospheric_pressure
  output->maximal_atmospheric_pressure = input->maximal_atmospheric_pressure;
  // measuring_unit
  if (!rosidl_runtime_c__String__copy(
      &(input->measuring_unit), &(output->measuring_unit)))
  {
    return false;
  }
  // acquisition_rate_hz
  output->acquisition_rate_hz = input->acquisition_rate_hz;
  // gain
  output->gain = input->gain;
  // resolution
  output->resolution = input->resolution;
  // adc_resolution
  output->adc_resolution = input->adc_resolution;
  // accuracy
  output->accuracy = input->accuracy;
  // max_range
  output->max_range = input->max_range;
  // min_range
  output->min_range = input->min_range;
  // window_size_samples
  output->window_size_samples = input->window_size_samples;
  // quality_window_size_samples
  output->quality_window_size_samples = input->quality_window_size_samples;
  // stride_length
  output->stride_length = input->stride_length;
  return true;
}

healthcare_msgs__msg__DeviceInfo *
healthcare_msgs__msg__DeviceInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__DeviceInfo * msg = (healthcare_msgs__msg__DeviceInfo *)allocator.allocate(sizeof(healthcare_msgs__msg__DeviceInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(healthcare_msgs__msg__DeviceInfo));
  bool success = healthcare_msgs__msg__DeviceInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
healthcare_msgs__msg__DeviceInfo__destroy(healthcare_msgs__msg__DeviceInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    healthcare_msgs__msg__DeviceInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
healthcare_msgs__msg__DeviceInfo__Sequence__init(healthcare_msgs__msg__DeviceInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__DeviceInfo * data = NULL;

  if (size) {
    data = (healthcare_msgs__msg__DeviceInfo *)allocator.zero_allocate(size, sizeof(healthcare_msgs__msg__DeviceInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = healthcare_msgs__msg__DeviceInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        healthcare_msgs__msg__DeviceInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
healthcare_msgs__msg__DeviceInfo__Sequence__fini(healthcare_msgs__msg__DeviceInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      healthcare_msgs__msg__DeviceInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

healthcare_msgs__msg__DeviceInfo__Sequence *
healthcare_msgs__msg__DeviceInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  healthcare_msgs__msg__DeviceInfo__Sequence * array = (healthcare_msgs__msg__DeviceInfo__Sequence *)allocator.allocate(sizeof(healthcare_msgs__msg__DeviceInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = healthcare_msgs__msg__DeviceInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
healthcare_msgs__msg__DeviceInfo__Sequence__destroy(healthcare_msgs__msg__DeviceInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    healthcare_msgs__msg__DeviceInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
healthcare_msgs__msg__DeviceInfo__Sequence__are_equal(const healthcare_msgs__msg__DeviceInfo__Sequence * lhs, const healthcare_msgs__msg__DeviceInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!healthcare_msgs__msg__DeviceInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
healthcare_msgs__msg__DeviceInfo__Sequence__copy(
  const healthcare_msgs__msg__DeviceInfo__Sequence * input,
  healthcare_msgs__msg__DeviceInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(healthcare_msgs__msg__DeviceInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    healthcare_msgs__msg__DeviceInfo * data =
      (healthcare_msgs__msg__DeviceInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!healthcare_msgs__msg__DeviceInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          healthcare_msgs__msg__DeviceInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!healthcare_msgs__msg__DeviceInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
