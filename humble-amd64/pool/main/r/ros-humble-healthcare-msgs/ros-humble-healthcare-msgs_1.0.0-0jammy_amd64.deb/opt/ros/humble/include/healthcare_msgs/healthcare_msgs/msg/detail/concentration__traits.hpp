// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/Concentration.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/concentration__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Concentration & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: session_id
  {
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << ", ";
  }

  // member: sample_size
  {
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << ", ";
  }

  // member: concentration_score
  {
    out << "concentration_score: ";
    rosidl_generator_traits::value_to_yaml(msg.concentration_score, out);
    out << ", ";
  }

  // member: confidence
  {
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
    out << ", ";
  }

  // member: is_concentrated
  {
    out << "is_concentrated: ";
    rosidl_generator_traits::value_to_yaml(msg.is_concentrated, out);
    out << ", ";
  }

  // member: quality
  {
    out << "quality: ";
    rosidl_generator_traits::value_to_yaml(msg.quality, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Concentration & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: session_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << "\n";
  }

  // member: sample_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sample_size: ";
    rosidl_generator_traits::value_to_yaml(msg.sample_size, out);
    out << "\n";
  }

  // member: concentration_score
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "concentration_score: ";
    rosidl_generator_traits::value_to_yaml(msg.concentration_score, out);
    out << "\n";
  }

  // member: confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
    out << "\n";
  }

  // member: is_concentrated
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_concentrated: ";
    rosidl_generator_traits::value_to_yaml(msg.is_concentrated, out);
    out << "\n";
  }

  // member: quality
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "quality: ";
    rosidl_generator_traits::value_to_yaml(msg.quality, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Concentration & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::Concentration & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::Concentration & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::Concentration>()
{
  return "healthcare_msgs::msg::Concentration";
}

template<>
inline const char * name<healthcare_msgs::msg::Concentration>()
{
  return "healthcare_msgs/msg/Concentration";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::Concentration>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::Concentration>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::Concentration>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__TRAITS_HPP_
