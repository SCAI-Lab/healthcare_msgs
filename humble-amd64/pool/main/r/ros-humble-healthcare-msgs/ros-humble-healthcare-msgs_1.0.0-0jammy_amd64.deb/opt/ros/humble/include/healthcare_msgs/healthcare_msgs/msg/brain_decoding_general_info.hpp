// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BRAIN_DECODING_GENERAL_INFO_HPP_
#define HEALTHCARE_MSGS__MSG__BRAIN_DECODING_GENERAL_INFO_HPP_

#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.hpp"
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__builder.hpp"
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__traits.hpp"
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__type_support.hpp"

#endif  // HEALTHCARE_MSGS__MSG__BRAIN_DECODING_GENERAL_INFO_HPP_
