// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/ERP.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ERP__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ERP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/erp__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_ERP_erp_label
{
public:
  explicit Init_ERP_erp_label(::healthcare_msgs::msg::ERP & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::ERP erp_label(::healthcare_msgs::msg::ERP::_erp_label_type arg)
  {
    msg_.erp_label = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::ERP msg_;
};

class Init_ERP_quality
{
public:
  explicit Init_ERP_quality(::healthcare_msgs::msg::ERP & msg)
  : msg_(msg)
  {}
  Init_ERP_erp_label quality(::healthcare_msgs::msg::ERP::_quality_type arg)
  {
    msg_.quality = std::move(arg);
    return Init_ERP_erp_label(msg_);
  }

private:
  ::healthcare_msgs::msg::ERP msg_;
};

class Init_ERP_confidence
{
public:
  explicit Init_ERP_confidence(::healthcare_msgs::msg::ERP & msg)
  : msg_(msg)
  {}
  Init_ERP_quality confidence(::healthcare_msgs::msg::ERP::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_ERP_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::ERP msg_;
};

class Init_ERP_sample_size
{
public:
  explicit Init_ERP_sample_size(::healthcare_msgs::msg::ERP & msg)
  : msg_(msg)
  {}
  Init_ERP_confidence sample_size(::healthcare_msgs::msg::ERP::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_ERP_confidence(msg_);
  }

private:
  ::healthcare_msgs::msg::ERP msg_;
};

class Init_ERP_session_id
{
public:
  explicit Init_ERP_session_id(::healthcare_msgs::msg::ERP & msg)
  : msg_(msg)
  {}
  Init_ERP_sample_size session_id(::healthcare_msgs::msg::ERP::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_ERP_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::ERP msg_;
};

class Init_ERP_header
{
public:
  Init_ERP_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ERP_session_id header(::healthcare_msgs::msg::ERP::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ERP_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::ERP msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::ERP>()
{
  return healthcare_msgs::msg::builder::Init_ERP_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ERP__BUILDER_HPP_
