// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/CardiacOutputInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/cardiac_output_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_CardiacOutputInfo_filters
{
public:
  explicit Init_CardiacOutputInfo_filters(::healthcare_msgs::msg::CardiacOutputInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::CardiacOutputInfo filters(::healthcare_msgs::msg::CardiacOutputInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutputInfo msg_;
};

class Init_CardiacOutputInfo_measurement_method
{
public:
  explicit Init_CardiacOutputInfo_measurement_method(::healthcare_msgs::msg::CardiacOutputInfo & msg)
  : msg_(msg)
  {}
  Init_CardiacOutputInfo_filters measurement_method(::healthcare_msgs::msg::CardiacOutputInfo::_measurement_method_type arg)
  {
    msg_.measurement_method = std::move(arg);
    return Init_CardiacOutputInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutputInfo msg_;
};

class Init_CardiacOutputInfo_sensor_placement
{
public:
  explicit Init_CardiacOutputInfo_sensor_placement(::healthcare_msgs::msg::CardiacOutputInfo & msg)
  : msg_(msg)
  {}
  Init_CardiacOutputInfo_measurement_method sensor_placement(::healthcare_msgs::msg::CardiacOutputInfo::_sensor_placement_type arg)
  {
    msg_.sensor_placement = std::move(arg);
    return Init_CardiacOutputInfo_measurement_method(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutputInfo msg_;
};

class Init_CardiacOutputInfo_unit
{
public:
  explicit Init_CardiacOutputInfo_unit(::healthcare_msgs::msg::CardiacOutputInfo & msg)
  : msg_(msg)
  {}
  Init_CardiacOutputInfo_sensor_placement unit(::healthcare_msgs::msg::CardiacOutputInfo::_unit_type arg)
  {
    msg_.unit = std::move(arg);
    return Init_CardiacOutputInfo_sensor_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutputInfo msg_;
};

class Init_CardiacOutputInfo_device_info
{
public:
  Init_CardiacOutputInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CardiacOutputInfo_unit device_info(::healthcare_msgs::msg::CardiacOutputInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_CardiacOutputInfo_unit(msg_);
  }

private:
  ::healthcare_msgs::msg::CardiacOutputInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::CardiacOutputInfo>()
{
  return healthcare_msgs::msg::builder::Init_CardiacOutputInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CARDIAC_OUTPUT_INFO__BUILDER_HPP_
