// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__CONCENTRATION_HPP_
#define HEALTHCARE_MSGS__MSG__CONCENTRATION_HPP_

#include "healthcare_msgs/msg/detail/concentration__struct.hpp"
#include "healthcare_msgs/msg/detail/concentration__builder.hpp"
#include "healthcare_msgs/msg/detail/concentration__traits.hpp"
#include "healthcare_msgs/msg/detail/concentration__type_support.hpp"

#endif  // HEALTHCARE_MSGS__MSG__CONCENTRATION_HPP_
