// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/ActivityDailyLife.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/activity_daily_life__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/activity_daily_life__functions.h"
#include "healthcare_msgs/msg/detail/activity_daily_life__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__ActivityDailyLife__init(message_memory);
}

void healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_fini_function(void * message_memory)
{
  healthcare_msgs__msg__ActivityDailyLife__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_member_array[3] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ActivityDailyLife, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "adl",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ActivityDailyLife, adl),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ActivityDailyLife, confidence),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "ActivityDailyLife",  // message name
  3,  // number of fields
  sizeof(healthcare_msgs__msg__ActivityDailyLife),
  healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_member_array,  // message members
  healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, ActivityDailyLife)() {
  healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__ActivityDailyLife__rosidl_typesupport_introspection_c__ActivityDailyLife_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
