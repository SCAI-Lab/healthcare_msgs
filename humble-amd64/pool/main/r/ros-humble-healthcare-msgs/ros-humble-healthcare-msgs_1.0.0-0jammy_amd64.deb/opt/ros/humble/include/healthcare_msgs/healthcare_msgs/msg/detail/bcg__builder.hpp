// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BCG.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BCG__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BCG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/bcg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BCG_signal_quality
{
public:
  explicit Init_BCG_signal_quality(::healthcare_msgs::msg::BCG & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BCG signal_quality(::healthcare_msgs::msg::BCG::_signal_quality_type arg)
  {
    msg_.signal_quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BCG msg_;
};

class Init_BCG_bcg
{
public:
  explicit Init_BCG_bcg(::healthcare_msgs::msg::BCG & msg)
  : msg_(msg)
  {}
  Init_BCG_signal_quality bcg(::healthcare_msgs::msg::BCG::_bcg_type arg)
  {
    msg_.bcg = std::move(arg);
    return Init_BCG_signal_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::BCG msg_;
};

class Init_BCG_sample_size
{
public:
  explicit Init_BCG_sample_size(::healthcare_msgs::msg::BCG & msg)
  : msg_(msg)
  {}
  Init_BCG_bcg sample_size(::healthcare_msgs::msg::BCG::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_BCG_bcg(msg_);
  }

private:
  ::healthcare_msgs::msg::BCG msg_;
};

class Init_BCG_session_id
{
public:
  explicit Init_BCG_session_id(::healthcare_msgs::msg::BCG & msg)
  : msg_(msg)
  {}
  Init_BCG_sample_size session_id(::healthcare_msgs::msg::BCG::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_BCG_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::BCG msg_;
};

class Init_BCG_header
{
public:
  Init_BCG_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BCG_session_id header(::healthcare_msgs::msg::BCG::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_BCG_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::BCG msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BCG>()
{
  return healthcare_msgs::msg::builder::Init_BCG_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BCG__BUILDER_HPP_
