// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/ActivityDailyLife.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__ACTIVITY_DAILY_LIFE_H_
#define HEALTHCARE_MSGS__MSG__ACTIVITY_DAILY_LIFE_H_

#include "healthcare_msgs/msg/detail/activity_daily_life__struct.h"
#include "healthcare_msgs/msg/detail/activity_daily_life__functions.h"
#include "healthcare_msgs/msg/detail/activity_daily_life__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__ACTIVITY_DAILY_LIFE_H_
