// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__ACTIVITY_DAILY_LIFE_HPP_
#define HEALTHCARE_MSGS__MSG__ACTIVITY_DAILY_LIFE_HPP_

#include "healthcare_msgs/msg/detail/activity_daily_life__struct.hpp"
#include "healthcare_msgs/msg/detail/activity_daily_life__builder.hpp"
#include "healthcare_msgs/msg/detail/activity_daily_life__traits.hpp"
#include "healthcare_msgs/msg/detail/activity_daily_life__type_support.hpp"

#endif  // HEALTHCARE_MSGS__MSG__ACTIVITY_DAILY_LIFE_HPP_
