// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/adl_model_classification_result__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_ADLModelClassificationResult_model_version
{
public:
  explicit Init_ADLModelClassificationResult_model_version(::healthcare_msgs::msg::ADLModelClassificationResult & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::ADLModelClassificationResult model_version(::healthcare_msgs::msg::ADLModelClassificationResult::_model_version_type arg)
  {
    msg_.model_version = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::ADLModelClassificationResult msg_;
};

class Init_ADLModelClassificationResult_model_type
{
public:
  explicit Init_ADLModelClassificationResult_model_type(::healthcare_msgs::msg::ADLModelClassificationResult & msg)
  : msg_(msg)
  {}
  Init_ADLModelClassificationResult_model_version model_type(::healthcare_msgs::msg::ADLModelClassificationResult::_model_type_type arg)
  {
    msg_.model_type = std::move(arg);
    return Init_ADLModelClassificationResult_model_version(msg_);
  }

private:
  ::healthcare_msgs::msg::ADLModelClassificationResult msg_;
};

class Init_ADLModelClassificationResult_class_amount
{
public:
  explicit Init_ADLModelClassificationResult_class_amount(::healthcare_msgs::msg::ADLModelClassificationResult & msg)
  : msg_(msg)
  {}
  Init_ADLModelClassificationResult_model_type class_amount(::healthcare_msgs::msg::ADLModelClassificationResult::_class_amount_type arg)
  {
    msg_.class_amount = std::move(arg);
    return Init_ADLModelClassificationResult_model_type(msg_);
  }

private:
  ::healthcare_msgs::msg::ADLModelClassificationResult msg_;
};

class Init_ADLModelClassificationResult_glossary
{
public:
  explicit Init_ADLModelClassificationResult_glossary(::healthcare_msgs::msg::ADLModelClassificationResult & msg)
  : msg_(msg)
  {}
  Init_ADLModelClassificationResult_class_amount glossary(::healthcare_msgs::msg::ADLModelClassificationResult::_glossary_type arg)
  {
    msg_.glossary = std::move(arg);
    return Init_ADLModelClassificationResult_class_amount(msg_);
  }

private:
  ::healthcare_msgs::msg::ADLModelClassificationResult msg_;
};

class Init_ADLModelClassificationResult_device_serial_number
{
public:
  explicit Init_ADLModelClassificationResult_device_serial_number(::healthcare_msgs::msg::ADLModelClassificationResult & msg)
  : msg_(msg)
  {}
  Init_ADLModelClassificationResult_glossary device_serial_number(::healthcare_msgs::msg::ADLModelClassificationResult::_device_serial_number_type arg)
  {
    msg_.device_serial_number = std::move(arg);
    return Init_ADLModelClassificationResult_glossary(msg_);
  }

private:
  ::healthcare_msgs::msg::ADLModelClassificationResult msg_;
};

class Init_ADLModelClassificationResult_header
{
public:
  Init_ADLModelClassificationResult_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ADLModelClassificationResult_device_serial_number header(::healthcare_msgs::msg::ADLModelClassificationResult::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ADLModelClassificationResult_device_serial_number(msg_);
  }

private:
  ::healthcare_msgs::msg::ADLModelClassificationResult msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::ADLModelClassificationResult>()
{
  return healthcare_msgs::msg::builder::Init_ADLModelClassificationResult_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ADL_MODEL_CLASSIFICATION_RESULT__BUILDER_HPP_
