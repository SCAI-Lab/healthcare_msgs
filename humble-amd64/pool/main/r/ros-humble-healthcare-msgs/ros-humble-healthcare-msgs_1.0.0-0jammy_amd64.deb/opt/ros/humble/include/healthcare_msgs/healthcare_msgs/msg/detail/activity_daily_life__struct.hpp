// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/ActivityDailyLife.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__ActivityDailyLife __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__ActivityDailyLife __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ActivityDailyLife_
{
  using Type = ActivityDailyLife_<ContainerAllocator>;

  explicit ActivityDailyLife_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->adl = 0;
      this->confidence = 0.0f;
    }
  }

  explicit ActivityDailyLife_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->adl = 0;
      this->confidence = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _adl_type =
    uint16_t;
  _adl_type adl;
  using _confidence_type =
    float;
  _confidence_type confidence;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__adl(
    const uint16_t & _arg)
  {
    this->adl = _arg;
    return *this;
  }
  Type & set__confidence(
    const float & _arg)
  {
    this->confidence = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint16_t ADL_UNKNOWN =
    0u;
  static constexpr uint16_t ADL_BATHING =
    1u;
  static constexpr uint16_t ADL_DRESSING =
    2u;
  static constexpr uint16_t ADL_EATING =
    3u;
  static constexpr uint16_t ADL_TOILETING =
    4u;
  static constexpr uint16_t ADL_GROOMING =
    5u;
  static constexpr uint16_t ADL_TRANSFERRING =
    6u;
  static constexpr uint16_t ADL_MOBILITY =
    7u;
  static constexpr uint16_t ADL_CONTINENCE =
    8u;
  static constexpr uint16_t ADL_COOKING =
    20u;
  static constexpr uint16_t ADL_CLEANING =
    21u;
  static constexpr uint16_t ADL_LAUNDRY =
    22u;
  static constexpr uint16_t ADL_SHOPPING =
    23u;
  static constexpr uint16_t ADL_USING_TRANSPORTATION =
    24u;
  static constexpr uint16_t ADL_MANAGING_FINANCES =
    25u;
  static constexpr uint16_t ADL_USING_TELEPHONE =
    26u;
  static constexpr uint16_t ADL_TAKING_MEDICATION =
    27u;
  static constexpr uint16_t ADL_SOCIAL_INTERACTION =
    40u;
  static constexpr uint16_t ADL_RECREATION =
    41u;
  static constexpr uint16_t ADL_COMMUNITY_ACTIVITY =
    42u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__ActivityDailyLife
    std::shared_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__ActivityDailyLife
    std::shared_ptr<healthcare_msgs::msg::ActivityDailyLife_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ActivityDailyLife_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->adl != other.adl) {
      return false;
    }
    if (this->confidence != other.confidence) {
      return false;
    }
    return true;
  }
  bool operator!=(const ActivityDailyLife_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ActivityDailyLife_

// alias to use template instance with default allocator
using ActivityDailyLife =
  healthcare_msgs::msg::ActivityDailyLife_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_BATHING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_DRESSING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_EATING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_TOILETING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_GROOMING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_TRANSFERRING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_MOBILITY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_CONTINENCE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_COOKING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_CLEANING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_LAUNDRY;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_SHOPPING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_USING_TRANSPORTATION;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_MANAGING_FINANCES;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_USING_TELEPHONE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_TAKING_MEDICATION;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_SOCIAL_INTERACTION;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_RECREATION;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint16_t ActivityDailyLife_<ContainerAllocator>::ADL_COMMUNITY_ACTIVITY;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__STRUCT_HPP_
