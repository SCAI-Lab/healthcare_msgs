// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/BCGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__BCGInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__BCGInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BCGInfo_
{
  using Type = BCGInfo_<ContainerAllocator>;

  explicit BCGInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    filters(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
      this->sensor_placement = 0;
      this->sensing_direction = 0;
      this->sensing_modality = 0;
      this->measurement_system = 0;
    }
  }

  explicit BCGInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    filters(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->units = 0;
      this->sensor_placement = 0;
      this->sensing_direction = 0;
      this->sensing_modality = 0;
      this->measurement_system = 0;
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _units_type =
    uint8_t;
  _units_type units;
  using _sensor_placement_type =
    uint8_t;
  _sensor_placement_type sensor_placement;
  using _sensing_direction_type =
    uint8_t;
  _sensing_direction_type sensing_direction;
  using _sensing_modality_type =
    uint8_t;
  _sensing_modality_type sensing_modality;
  using _measurement_system_type =
    uint8_t;
  _measurement_system_type measurement_system;
  using _filters_type =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator>;
  _filters_type filters;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__units(
    const uint8_t & _arg)
  {
    this->units = _arg;
    return *this;
  }
  Type & set__sensor_placement(
    const uint8_t & _arg)
  {
    this->sensor_placement = _arg;
    return *this;
  }
  Type & set__sensing_direction(
    const uint8_t & _arg)
  {
    this->sensing_direction = _arg;
    return *this;
  }
  Type & set__sensing_modality(
    const uint8_t & _arg)
  {
    this->sensing_modality = _arg;
    return *this;
  }
  Type & set__measurement_system(
    const uint8_t & _arg)
  {
    this->measurement_system = _arg;
    return *this;
  }
  Type & set__filters(
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> & _arg)
  {
    this->filters = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t UNIT_UNKNOWN =
    0u;
  static constexpr uint8_t UNIT_MV =
    1u;
  static constexpr uint8_t UNIT_UV =
    2u;
  static constexpr uint8_t UNIT_COUNTS =
    3u;
  static constexpr uint8_t UNIT_M_S2 =
    4u;
  static constexpr uint8_t UNIT_NEWTON =
    5u;
  static constexpr uint8_t PLACEMENT_UNKNOWN =
    0u;
  static constexpr uint8_t PLACEMENT_CHEST =
    1u;
  static constexpr uint8_t PLACEMENT_BACK =
    2u;
  static constexpr uint8_t PLACEMENT_MATTRESS =
    3u;
  static constexpr uint8_t PLACEMENT_CHAIR =
    4u;
  static constexpr uint8_t PLACEMENT_ANKLE =
    5u;
  static constexpr uint8_t PLACEMENT_FOOT =
    6u;
  static constexpr uint8_t PLACEMENT_WRIST =
    7u;
  static constexpr uint8_t PLACEMENT_ARM =
    8u;
  static constexpr uint8_t PLACEMENT_DESK =
    9u;
  static constexpr uint8_t PLACEMENT_CLOTHING =
    10u;
  static constexpr uint8_t PLACEMENT_CUSTOM =
    255u;
  static constexpr uint8_t DIRECTION_UNKNOWN =
    0u;
  static constexpr uint8_t DIRECTION_DORSO_VENTRAL =
    1u;
  static constexpr uint8_t DIRECTION_LONGITUDINAL =
    2u;
  static constexpr uint8_t DIRECTION_MEDIO_LATERAL =
    3u;
  static constexpr uint8_t DIRECTION_CUSTOM =
    255u;
  static constexpr uint8_t MODALITY_UNKNOWN =
    0u;
  static constexpr uint8_t MODALITY_PIEZOELECTRIC_FILM =
    1u;
  static constexpr uint8_t MODALITY_FORCEPLATE =
    2u;
  static constexpr uint8_t MODALITY_ACCELEROMETER =
    3u;
  static constexpr uint8_t MODALITY_PIEZOELECTRIC_CRYSTAL =
    4u;
  static constexpr uint8_t MODALITY_CUSTOM =
    255u;
  static constexpr uint8_t SYSTEM_UNKNOWN =
    0u;
  static constexpr uint8_t SYSTEM_STARR =
    1u;
  static constexpr uint8_t SYSTEM_NICKERSON =
    2u;
  static constexpr uint8_t SYSTEM_DOCK =
    3u;
  static constexpr uint8_t SYSTEM_CUSTOM =
    255u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::BCGInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::BCGInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BCGInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::BCGInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__BCGInfo
    std::shared_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__BCGInfo
    std::shared_ptr<healthcare_msgs::msg::BCGInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BCGInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->units != other.units) {
      return false;
    }
    if (this->sensor_placement != other.sensor_placement) {
      return false;
    }
    if (this->sensing_direction != other.sensing_direction) {
      return false;
    }
    if (this->sensing_modality != other.sensing_modality) {
      return false;
    }
    if (this->measurement_system != other.measurement_system) {
      return false;
    }
    if (this->filters != other.filters) {
      return false;
    }
    return true;
  }
  bool operator!=(const BCGInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BCGInfo_

// alias to use template instance with default allocator
using BCGInfo =
  healthcare_msgs::msg::BCGInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::UNIT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::UNIT_MV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::UNIT_UV;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::UNIT_COUNTS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::UNIT_M_S2;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::UNIT_NEWTON;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_CHEST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_BACK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_MATTRESS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_CHAIR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_ANKLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_FOOT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_WRIST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_ARM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_DESK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_CLOTHING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::PLACEMENT_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::DIRECTION_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::DIRECTION_DORSO_VENTRAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::DIRECTION_LONGITUDINAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::DIRECTION_MEDIO_LATERAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::DIRECTION_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::MODALITY_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::MODALITY_PIEZOELECTRIC_FILM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::MODALITY_FORCEPLATE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::MODALITY_ACCELEROMETER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::MODALITY_PIEZOELECTRIC_CRYSTAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::MODALITY_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::SYSTEM_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::SYSTEM_STARR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::SYSTEM_NICKERSON;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::SYSTEM_DOCK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BCGInfo_<ContainerAllocator>::SYSTEM_CUSTOM;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BCG_INFO__STRUCT_HPP_
