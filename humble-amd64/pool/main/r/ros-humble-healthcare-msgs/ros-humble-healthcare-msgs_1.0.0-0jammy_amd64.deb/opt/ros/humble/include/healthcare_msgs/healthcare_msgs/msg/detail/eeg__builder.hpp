// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EEG.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/eeg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EEG_quality
{
public:
  explicit Init_EEG_quality(::healthcare_msgs::msg::EEG & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EEG quality(::healthcare_msgs::msg::EEG::_quality_type arg)
  {
    msg_.quality = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EEG msg_;
};

class Init_EEG_eeg
{
public:
  explicit Init_EEG_eeg(::healthcare_msgs::msg::EEG & msg)
  : msg_(msg)
  {}
  Init_EEG_quality eeg(::healthcare_msgs::msg::EEG::_eeg_type arg)
  {
    msg_.eeg = std::move(arg);
    return Init_EEG_quality(msg_);
  }

private:
  ::healthcare_msgs::msg::EEG msg_;
};

class Init_EEG_sample_size
{
public:
  explicit Init_EEG_sample_size(::healthcare_msgs::msg::EEG & msg)
  : msg_(msg)
  {}
  Init_EEG_eeg sample_size(::healthcare_msgs::msg::EEG::_sample_size_type arg)
  {
    msg_.sample_size = std::move(arg);
    return Init_EEG_eeg(msg_);
  }

private:
  ::healthcare_msgs::msg::EEG msg_;
};

class Init_EEG_session_id
{
public:
  explicit Init_EEG_session_id(::healthcare_msgs::msg::EEG & msg)
  : msg_(msg)
  {}
  Init_EEG_sample_size session_id(::healthcare_msgs::msg::EEG::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_EEG_sample_size(msg_);
  }

private:
  ::healthcare_msgs::msg::EEG msg_;
};

class Init_EEG_header
{
public:
  Init_EEG_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EEG_session_id header(::healthcare_msgs::msg::EEG::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_EEG_session_id(msg_);
  }

private:
  ::healthcare_msgs::msg::EEG msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EEG>()
{
  return healthcare_msgs::msg::builder::Init_EEG_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG__BUILDER_HPP_
