// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/ECGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNIT_UNKNOWN'.
/**
  * Units Enum
 */
enum
{
  healthcare_msgs__msg__ECGInfo__UNIT_UNKNOWN = 0
};

/// Constant 'UNIT_MV'.
enum
{
  healthcare_msgs__msg__ECGInfo__UNIT_MV = 1
};

/// Constant 'UNIT_UV'.
enum
{
  healthcare_msgs__msg__ECGInfo__UNIT_UV = 2
};

/// Constant 'UNIT_COUNTS'.
enum
{
  healthcare_msgs__msg__ECGInfo__UNIT_COUNTS = 3
};

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Electrode Placement Enum
 */
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_LIMB'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_LIMB = 1
};

/// Constant 'PLACEMENT_WRIST_ANKLE'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_WRIST_ANKLE = 2
};

/// Constant 'PLACEMENT_CHEST'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_CHEST = 3
};

/// Constant 'PLACEMENT_TORSO'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_TORSO = 4
};

/// Constant 'PLACEMENT_ABDOMEN'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_ABDOMEN = 5
};

/// Constant 'PLACEMENT_BACK'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_BACK = 6
};

/// Constant 'PLACEMENT_EAR'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_EAR = 7
};

/// Constant 'PLACEMENT_NECK'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_NECK = 8
};

/// Constant 'PLACEMENT_LEFT_ARM'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_LEFT_ARM = 9
};

/// Constant 'PLACEMENT_RIGHT_ARM'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_RIGHT_ARM = 10
};

/// Constant 'PLACEMENT_LEFT_LEG'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_LEFT_LEG = 11
};

/// Constant 'PLACEMENT_RIGHT_LEG'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_RIGHT_LEG = 12
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__ECGInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'LEAD_UNKNOWN'.
/**
  * Lead Types Enum
 */
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_UNKNOWN = 0
};

/// Constant 'LEAD_I'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_I = 1
};

/// Constant 'LEAD_II'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_II = 2
};

/// Constant 'LEAD_III'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_III = 3
};

/// Constant 'LEAD_AVR'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_AVR = 4
};

/// Constant 'LEAD_AVL'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_AVL = 5
};

/// Constant 'LEAD_AVF'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_AVF = 6
};

/// Constant 'LEAD_V1'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_V1 = 7
};

/// Constant 'LEAD_V2'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_V2 = 8
};

/// Constant 'LEAD_V3'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_V3 = 9
};

/// Constant 'LEAD_V4'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_V4 = 10
};

/// Constant 'LEAD_V5'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_V5 = 11
};

/// Constant 'LEAD_V6'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_V6 = 12
};

/// Constant 'LEAD_CUSTOM'.
enum
{
  healthcare_msgs__msg__ECGInfo__LEAD_CUSTOM = 255
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'electrode_placement'
// Member 'lead_type'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/ECGInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__ECGInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  uint8_t units;
  /// Support multiple placements
  rosidl_runtime_c__uint8__Sequence electrode_placement;
  rosidl_runtime_c__uint8__Sequence lead_type;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__ECGInfo;

// Struct for a sequence of healthcare_msgs__msg__ECGInfo.
typedef struct healthcare_msgs__msg__ECGInfo__Sequence
{
  healthcare_msgs__msg__ECGInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__ECGInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ECG_INFO__STRUCT_H_
