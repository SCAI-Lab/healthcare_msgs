// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EEGInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/eeg_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EEGInfo_filters
{
public:
  explicit Init_EEGInfo_filters(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EEGInfo filters(::healthcare_msgs::msg::EEGInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_signal_mode
{
public:
  explicit Init_EEGInfo_signal_mode(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_filters signal_mode(::healthcare_msgs::msg::EEGInfo::_signal_mode_type arg)
  {
    msg_.signal_mode = std::move(arg);
    return Init_EEGInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_electrode_physical_type
{
public:
  explicit Init_EEGInfo_electrode_physical_type(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_signal_mode electrode_physical_type(::healthcare_msgs::msg::EEGInfo::_electrode_physical_type_type arg)
  {
    msg_.electrode_physical_type = std::move(arg);
    return Init_EEGInfo_signal_mode(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_electrode_sites
{
public:
  explicit Init_EEGInfo_electrode_sites(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_electrode_physical_type electrode_sites(::healthcare_msgs::msg::EEGInfo::_electrode_sites_type arg)
  {
    msg_.electrode_sites = std::move(arg);
    return Init_EEGInfo_electrode_physical_type(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_placement_method
{
public:
  explicit Init_EEGInfo_placement_method(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_electrode_sites placement_method(::healthcare_msgs::msg::EEGInfo::_placement_method_type arg)
  {
    msg_.placement_method = std::move(arg);
    return Init_EEGInfo_electrode_sites(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_reference_sites
{
public:
  explicit Init_EEGInfo_reference_sites(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_placement_method reference_sites(::healthcare_msgs::msg::EEGInfo::_reference_sites_type arg)
  {
    msg_.reference_sites = std::move(arg);
    return Init_EEGInfo_placement_method(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_bipolar_reference_sites
{
public:
  explicit Init_EEGInfo_bipolar_reference_sites(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_reference_sites bipolar_reference_sites(::healthcare_msgs::msg::EEGInfo::_bipolar_reference_sites_type arg)
  {
    msg_.bipolar_reference_sites = std::move(arg);
    return Init_EEGInfo_reference_sites(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_bipolar_active_sites
{
public:
  explicit Init_EEGInfo_bipolar_active_sites(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_bipolar_reference_sites bipolar_active_sites(::healthcare_msgs::msg::EEGInfo::_bipolar_active_sites_type arg)
  {
    msg_.bipolar_active_sites = std::move(arg);
    return Init_EEGInfo_bipolar_reference_sites(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_montage_type
{
public:
  explicit Init_EEGInfo_montage_type(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_bipolar_active_sites montage_type(::healthcare_msgs::msg::EEGInfo::_montage_type_type arg)
  {
    msg_.montage_type = std::move(arg);
    return Init_EEGInfo_bipolar_active_sites(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_selected_preprocessing
{
public:
  explicit Init_EEGInfo_selected_preprocessing(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_montage_type selected_preprocessing(::healthcare_msgs::msg::EEGInfo::_selected_preprocessing_type arg)
  {
    msg_.selected_preprocessing = std::move(arg);
    return Init_EEGInfo_montage_type(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_units
{
public:
  explicit Init_EEGInfo_units(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_selected_preprocessing units(::healthcare_msgs::msg::EEGInfo::_units_type arg)
  {
    msg_.units = std::move(arg);
    return Init_EEGInfo_selected_preprocessing(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_channel_size
{
public:
  explicit Init_EEGInfo_channel_size(::healthcare_msgs::msg::EEGInfo & msg)
  : msg_(msg)
  {}
  Init_EEGInfo_units channel_size(::healthcare_msgs::msg::EEGInfo::_channel_size_type arg)
  {
    msg_.channel_size = std::move(arg);
    return Init_EEGInfo_units(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

class Init_EEGInfo_device_info
{
public:
  Init_EEGInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EEGInfo_channel_size device_info(::healthcare_msgs::msg::EEGInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_EEGInfo_channel_size(msg_);
  }

private:
  ::healthcare_msgs::msg::EEGInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EEGInfo>()
{
  return healthcare_msgs::msg::builder::Init_EEGInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EEG_INFO__BUILDER_HPP_
