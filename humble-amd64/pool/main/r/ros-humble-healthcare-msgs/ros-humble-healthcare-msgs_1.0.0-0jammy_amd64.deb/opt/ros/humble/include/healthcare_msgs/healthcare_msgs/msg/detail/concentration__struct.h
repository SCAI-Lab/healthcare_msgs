// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/Concentration.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'session_id'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/Concentration in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__Concentration
{
  std_msgs__msg__Header header;
  /// Match DeviceInfo's session_id
  rosidl_runtime_c__String session_id;
  uint16_t sample_size;
  /// Output Values
  /// 0-1 normalized concentration
  float concentration_score;
  /// 0-1 Optional model confidence
  float confidence;
  /// Decision of the output model
  bool is_concentrated;
  /// From 0 (poor) to 1 (excellent) takes into account not only the signal quality, but also other factors, e.g. whether some sensor might be wrongly connected
  float quality;
} healthcare_msgs__msg__Concentration;

// Struct for a sequence of healthcare_msgs__msg__Concentration.
typedef struct healthcare_msgs__msg__Concentration__Sequence
{
  healthcare_msgs__msg__Concentration * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__Concentration__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__CONCENTRATION__STRUCT_H_
