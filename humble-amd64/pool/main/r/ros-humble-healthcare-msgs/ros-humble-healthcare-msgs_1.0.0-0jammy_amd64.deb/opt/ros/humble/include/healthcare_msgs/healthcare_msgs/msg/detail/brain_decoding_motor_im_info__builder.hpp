// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingMotorImInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/brain_decoding_motor_im_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BrainDecodingMotorImInfo_comments
{
public:
  explicit Init_BrainDecodingMotorImInfo_comments(::healthcare_msgs::msg::BrainDecodingMotorImInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BrainDecodingMotorImInfo comments(::healthcare_msgs::msg::BrainDecodingMotorImInfo::_comments_type arg)
  {
    msg_.comments = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingMotorImInfo msg_;
};

class Init_BrainDecodingMotorImInfo_mi_features
{
public:
  explicit Init_BrainDecodingMotorImInfo_mi_features(::healthcare_msgs::msg::BrainDecodingMotorImInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingMotorImInfo_comments mi_features(::healthcare_msgs::msg::BrainDecodingMotorImInfo::_mi_features_type arg)
  {
    msg_.mi_features = std::move(arg);
    return Init_BrainDecodingMotorImInfo_comments(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingMotorImInfo msg_;
};

class Init_BrainDecodingMotorImInfo_brain_decoding_general_info
{
public:
  explicit Init_BrainDecodingMotorImInfo_brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingMotorImInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingMotorImInfo_mi_features brain_decoding_general_info(::healthcare_msgs::msg::BrainDecodingMotorImInfo::_brain_decoding_general_info_type arg)
  {
    msg_.brain_decoding_general_info = std::move(arg);
    return Init_BrainDecodingMotorImInfo_mi_features(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingMotorImInfo msg_;
};

class Init_BrainDecodingMotorImInfo_device_info
{
public:
  Init_BrainDecodingMotorImInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BrainDecodingMotorImInfo_brain_decoding_general_info device_info(::healthcare_msgs::msg::BrainDecodingMotorImInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_BrainDecodingMotorImInfo_brain_decoding_general_info(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingMotorImInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BrainDecodingMotorImInfo>()
{
  return healthcare_msgs::msg::builder::Init_BrainDecodingMotorImInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_MOTOR_IM_INFO__BUILDER_HPP_
