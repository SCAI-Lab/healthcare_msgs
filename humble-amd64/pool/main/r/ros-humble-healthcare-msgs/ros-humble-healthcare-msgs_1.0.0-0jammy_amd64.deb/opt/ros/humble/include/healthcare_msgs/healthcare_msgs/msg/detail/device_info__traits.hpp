// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/DeviceInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'mds'
#include "healthcare_msgs/msg/detail/medical_device_system__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DeviceInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: session_id
  {
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << ", ";
  }

  // member: mds
  {
    out << "mds: ";
    to_flow_style_yaml(msg.mds, out);
    out << ", ";
  }

  // member: device_manufacturer
  {
    out << "device_manufacturer: ";
    rosidl_generator_traits::value_to_yaml(msg.device_manufacturer, out);
    out << ", ";
  }

  // member: device_name
  {
    out << "device_name: ";
    rosidl_generator_traits::value_to_yaml(msg.device_name, out);
    out << ", ";
  }

  // member: device_type
  {
    out << "device_type: ";
    rosidl_generator_traits::value_to_yaml(msg.device_type, out);
    out << ", ";
  }

  // member: device_serial_number
  {
    out << "device_serial_number: ";
    rosidl_generator_traits::value_to_yaml(msg.device_serial_number, out);
    out << ", ";
  }

  // member: minimal_operation_temperature
  {
    out << "minimal_operation_temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.minimal_operation_temperature, out);
    out << ", ";
  }

  // member: maximal_operation_temperature
  {
    out << "maximal_operation_temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.maximal_operation_temperature, out);
    out << ", ";
  }

  // member: maximal_relative_humidity
  {
    out << "maximal_relative_humidity: ";
    rosidl_generator_traits::value_to_yaml(msg.maximal_relative_humidity, out);
    out << ", ";
  }

  // member: minimal_atmospheric_pressure
  {
    out << "minimal_atmospheric_pressure: ";
    rosidl_generator_traits::value_to_yaml(msg.minimal_atmospheric_pressure, out);
    out << ", ";
  }

  // member: maximal_atmospheric_pressure
  {
    out << "maximal_atmospheric_pressure: ";
    rosidl_generator_traits::value_to_yaml(msg.maximal_atmospheric_pressure, out);
    out << ", ";
  }

  // member: measuring_unit
  {
    out << "measuring_unit: ";
    rosidl_generator_traits::value_to_yaml(msg.measuring_unit, out);
    out << ", ";
  }

  // member: acquisition_rate_hz
  {
    out << "acquisition_rate_hz: ";
    rosidl_generator_traits::value_to_yaml(msg.acquisition_rate_hz, out);
    out << ", ";
  }

  // member: gain
  {
    out << "gain: ";
    rosidl_generator_traits::value_to_yaml(msg.gain, out);
    out << ", ";
  }

  // member: resolution
  {
    out << "resolution: ";
    rosidl_generator_traits::value_to_yaml(msg.resolution, out);
    out << ", ";
  }

  // member: adc_resolution
  {
    out << "adc_resolution: ";
    rosidl_generator_traits::value_to_yaml(msg.adc_resolution, out);
    out << ", ";
  }

  // member: accuracy
  {
    out << "accuracy: ";
    rosidl_generator_traits::value_to_yaml(msg.accuracy, out);
    out << ", ";
  }

  // member: max_range
  {
    out << "max_range: ";
    rosidl_generator_traits::value_to_yaml(msg.max_range, out);
    out << ", ";
  }

  // member: min_range
  {
    out << "min_range: ";
    rosidl_generator_traits::value_to_yaml(msg.min_range, out);
    out << ", ";
  }

  // member: window_size_samples
  {
    out << "window_size_samples: ";
    rosidl_generator_traits::value_to_yaml(msg.window_size_samples, out);
    out << ", ";
  }

  // member: quality_window_size_samples
  {
    out << "quality_window_size_samples: ";
    rosidl_generator_traits::value_to_yaml(msg.quality_window_size_samples, out);
    out << ", ";
  }

  // member: stride_length
  {
    out << "stride_length: ";
    rosidl_generator_traits::value_to_yaml(msg.stride_length, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DeviceInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: session_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "session_id: ";
    rosidl_generator_traits::value_to_yaml(msg.session_id, out);
    out << "\n";
  }

  // member: mds
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mds:\n";
    to_block_style_yaml(msg.mds, out, indentation + 2);
  }

  // member: device_manufacturer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_manufacturer: ";
    rosidl_generator_traits::value_to_yaml(msg.device_manufacturer, out);
    out << "\n";
  }

  // member: device_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_name: ";
    rosidl_generator_traits::value_to_yaml(msg.device_name, out);
    out << "\n";
  }

  // member: device_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_type: ";
    rosidl_generator_traits::value_to_yaml(msg.device_type, out);
    out << "\n";
  }

  // member: device_serial_number
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_serial_number: ";
    rosidl_generator_traits::value_to_yaml(msg.device_serial_number, out);
    out << "\n";
  }

  // member: minimal_operation_temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "minimal_operation_temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.minimal_operation_temperature, out);
    out << "\n";
  }

  // member: maximal_operation_temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "maximal_operation_temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.maximal_operation_temperature, out);
    out << "\n";
  }

  // member: maximal_relative_humidity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "maximal_relative_humidity: ";
    rosidl_generator_traits::value_to_yaml(msg.maximal_relative_humidity, out);
    out << "\n";
  }

  // member: minimal_atmospheric_pressure
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "minimal_atmospheric_pressure: ";
    rosidl_generator_traits::value_to_yaml(msg.minimal_atmospheric_pressure, out);
    out << "\n";
  }

  // member: maximal_atmospheric_pressure
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "maximal_atmospheric_pressure: ";
    rosidl_generator_traits::value_to_yaml(msg.maximal_atmospheric_pressure, out);
    out << "\n";
  }

  // member: measuring_unit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measuring_unit: ";
    rosidl_generator_traits::value_to_yaml(msg.measuring_unit, out);
    out << "\n";
  }

  // member: acquisition_rate_hz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acquisition_rate_hz: ";
    rosidl_generator_traits::value_to_yaml(msg.acquisition_rate_hz, out);
    out << "\n";
  }

  // member: gain
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gain: ";
    rosidl_generator_traits::value_to_yaml(msg.gain, out);
    out << "\n";
  }

  // member: resolution
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "resolution: ";
    rosidl_generator_traits::value_to_yaml(msg.resolution, out);
    out << "\n";
  }

  // member: adc_resolution
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "adc_resolution: ";
    rosidl_generator_traits::value_to_yaml(msg.adc_resolution, out);
    out << "\n";
  }

  // member: accuracy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accuracy: ";
    rosidl_generator_traits::value_to_yaml(msg.accuracy, out);
    out << "\n";
  }

  // member: max_range
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "max_range: ";
    rosidl_generator_traits::value_to_yaml(msg.max_range, out);
    out << "\n";
  }

  // member: min_range
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "min_range: ";
    rosidl_generator_traits::value_to_yaml(msg.min_range, out);
    out << "\n";
  }

  // member: window_size_samples
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "window_size_samples: ";
    rosidl_generator_traits::value_to_yaml(msg.window_size_samples, out);
    out << "\n";
  }

  // member: quality_window_size_samples
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "quality_window_size_samples: ";
    rosidl_generator_traits::value_to_yaml(msg.quality_window_size_samples, out);
    out << "\n";
  }

  // member: stride_length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stride_length: ";
    rosidl_generator_traits::value_to_yaml(msg.stride_length, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DeviceInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::DeviceInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::DeviceInfo & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::DeviceInfo>()
{
  return "healthcare_msgs::msg::DeviceInfo";
}

template<>
inline const char * name<healthcare_msgs::msg::DeviceInfo>()
{
  return "healthcare_msgs/msg/DeviceInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::DeviceInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::DeviceInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::DeviceInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__DEVICE_INFO__TRAITS_HPP_
