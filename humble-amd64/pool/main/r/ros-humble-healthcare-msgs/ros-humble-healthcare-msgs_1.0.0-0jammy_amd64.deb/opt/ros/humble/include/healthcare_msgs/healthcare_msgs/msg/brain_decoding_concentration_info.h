// generated from rosidl_generator_c/resource/idl.h.em
// with input from healthcare_msgs:msg/BrainDecodingConcentrationInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BRAIN_DECODING_CONCENTRATION_INFO_H_
#define HEALTHCARE_MSGS__MSG__BRAIN_DECODING_CONCENTRATION_INFO_H_

#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__struct.h"
#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__functions.h"
#include "healthcare_msgs/msg/detail/brain_decoding_concentration_info__type_support.h"

#endif  // HEALTHCARE_MSGS__MSG__BRAIN_DECODING_CONCENTRATION_INFO_H_
