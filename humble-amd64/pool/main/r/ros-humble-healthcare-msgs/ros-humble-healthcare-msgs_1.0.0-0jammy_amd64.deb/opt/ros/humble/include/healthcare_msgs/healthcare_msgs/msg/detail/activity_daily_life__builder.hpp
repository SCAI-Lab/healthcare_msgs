// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/ActivityDailyLife.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/activity_daily_life__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_ActivityDailyLife_confidence
{
public:
  explicit Init_ActivityDailyLife_confidence(::healthcare_msgs::msg::ActivityDailyLife & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::ActivityDailyLife confidence(::healthcare_msgs::msg::ActivityDailyLife::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::ActivityDailyLife msg_;
};

class Init_ActivityDailyLife_adl
{
public:
  explicit Init_ActivityDailyLife_adl(::healthcare_msgs::msg::ActivityDailyLife & msg)
  : msg_(msg)
  {}
  Init_ActivityDailyLife_confidence adl(::healthcare_msgs::msg::ActivityDailyLife::_adl_type arg)
  {
    msg_.adl = std::move(arg);
    return Init_ActivityDailyLife_confidence(msg_);
  }

private:
  ::healthcare_msgs::msg::ActivityDailyLife msg_;
};

class Init_ActivityDailyLife_header
{
public:
  Init_ActivityDailyLife_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ActivityDailyLife_adl header(::healthcare_msgs::msg::ActivityDailyLife::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ActivityDailyLife_adl(msg_);
  }

private:
  ::healthcare_msgs::msg::ActivityDailyLife msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::ActivityDailyLife>()
{
  return healthcare_msgs::msg::builder::Init_ActivityDailyLife_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__ACTIVITY_DAILY_LIFE__BUILDER_HPP_
