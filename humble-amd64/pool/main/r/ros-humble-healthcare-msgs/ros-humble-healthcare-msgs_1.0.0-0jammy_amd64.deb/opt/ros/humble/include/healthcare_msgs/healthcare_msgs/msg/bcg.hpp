// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__BCG_HPP_
#define HEALTHCARE_MSGS__MSG__BCG_HPP_

#include "healthcare_msgs/msg/detail/bcg__struct.hpp"
#include "healthcare_msgs/msg/detail/bcg__builder.hpp"
#include "healthcare_msgs/msg/detail/bcg__traits.hpp"
#include "healthcare_msgs/msg/detail/bcg__type_support.hpp"

#endif  // HEALTHCARE_MSGS__MSG__BCG_HPP_
