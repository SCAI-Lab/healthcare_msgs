// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/ButterWorthFilter.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ButterWorthFilter in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__ButterWorthFilter
{
  std_msgs__msg__Header header;
  /// Hz
  float cutoff_frequency;
  /// Filter order
  uint8_t order;
  /// Hz
  float sampling_rate;
  /// True if using filtfilt-style bidirectional filter
  bool zero_phase;
} healthcare_msgs__msg__ButterWorthFilter;

// Struct for a sequence of healthcare_msgs__msg__ButterWorthFilter.
typedef struct healthcare_msgs__msg__ButterWorthFilter__Sequence
{
  healthcare_msgs__msg__ButterWorthFilter * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__ButterWorthFilter__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BUTTER_WORTH_FILTER__STRUCT_H_
