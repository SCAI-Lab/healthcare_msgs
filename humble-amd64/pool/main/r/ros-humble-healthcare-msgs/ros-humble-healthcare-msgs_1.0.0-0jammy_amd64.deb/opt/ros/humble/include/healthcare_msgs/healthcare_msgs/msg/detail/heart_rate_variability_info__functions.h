// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from healthcare_msgs:msg/HeartRateVariabilityInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__FUNCTIONS_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "healthcare_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "healthcare_msgs/msg/detail/heart_rate_variability_info__struct.h"

/// Initialize msg/HeartRateVariabilityInfo message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * healthcare_msgs__msg__HeartRateVariabilityInfo
 * )) before or use
 * healthcare_msgs__msg__HeartRateVariabilityInfo__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRateVariabilityInfo__init(healthcare_msgs__msg__HeartRateVariabilityInfo * msg);

/// Finalize msg/HeartRateVariabilityInfo message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRateVariabilityInfo__fini(healthcare_msgs__msg__HeartRateVariabilityInfo * msg);

/// Create msg/HeartRateVariabilityInfo message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * healthcare_msgs__msg__HeartRateVariabilityInfo__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__HeartRateVariabilityInfo *
healthcare_msgs__msg__HeartRateVariabilityInfo__create();

/// Destroy msg/HeartRateVariabilityInfo message.
/**
 * It calls
 * healthcare_msgs__msg__HeartRateVariabilityInfo__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRateVariabilityInfo__destroy(healthcare_msgs__msg__HeartRateVariabilityInfo * msg);

/// Check for msg/HeartRateVariabilityInfo message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRateVariabilityInfo__are_equal(const healthcare_msgs__msg__HeartRateVariabilityInfo * lhs, const healthcare_msgs__msg__HeartRateVariabilityInfo * rhs);

/// Copy a msg/HeartRateVariabilityInfo message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRateVariabilityInfo__copy(
  const healthcare_msgs__msg__HeartRateVariabilityInfo * input,
  healthcare_msgs__msg__HeartRateVariabilityInfo * output);

/// Initialize array of msg/HeartRateVariabilityInfo messages.
/**
 * It allocates the memory for the number of elements and calls
 * healthcare_msgs__msg__HeartRateVariabilityInfo__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__init(healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * array, size_t size);

/// Finalize array of msg/HeartRateVariabilityInfo messages.
/**
 * It calls
 * healthcare_msgs__msg__HeartRateVariabilityInfo__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__fini(healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * array);

/// Create array of msg/HeartRateVariabilityInfo messages.
/**
 * It allocates the memory for the array and calls
 * healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence *
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__create(size_t size);

/// Destroy array of msg/HeartRateVariabilityInfo messages.
/**
 * It calls
 * healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__destroy(healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * array);

/// Check for msg/HeartRateVariabilityInfo message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__are_equal(const healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * lhs, const healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * rhs);

/// Copy an array of msg/HeartRateVariabilityInfo messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence__copy(
  const healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * input,
  healthcare_msgs__msg__HeartRateVariabilityInfo__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__FUNCTIONS_H_
