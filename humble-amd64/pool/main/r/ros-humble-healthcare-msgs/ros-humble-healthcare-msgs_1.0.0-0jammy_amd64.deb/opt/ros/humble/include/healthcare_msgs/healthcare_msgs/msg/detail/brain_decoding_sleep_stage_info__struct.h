// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/BrainDecodingSleepStageInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'SLEEP_DETECT_SPINDLES'.
/**
  * Sleep-specific features
 */
enum
{
  healthcare_msgs__msg__BrainDecodingSleepStageInfo__SLEEP_DETECT_SPINDLES = 70
};

/// Constant 'SLEEP_SLOW_WAVE_ANALYSIS'.
enum
{
  healthcare_msgs__msg__BrainDecodingSleepStageInfo__SLEEP_SLOW_WAVE_ANALYSIS = 71
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'brain_decoding_general_info'
#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.h"
// Member 'sleep_features'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'comments'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/BrainDecodingSleepStageInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__BrainDecodingSleepStageInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  healthcare_msgs__msg__BrainDecodingGeneralInfo brain_decoding_general_info;
  rosidl_runtime_c__uint8__Sequence sleep_features;
  rosidl_runtime_c__String comments;
} healthcare_msgs__msg__BrainDecodingSleepStageInfo;

// Struct for a sequence of healthcare_msgs__msg__BrainDecodingSleepStageInfo.
typedef struct healthcare_msgs__msg__BrainDecodingSleepStageInfo__Sequence
{
  healthcare_msgs__msg__BrainDecodingSleepStageInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__BrainDecodingSleepStageInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_SLEEP_STAGE_INFO__STRUCT_H_
