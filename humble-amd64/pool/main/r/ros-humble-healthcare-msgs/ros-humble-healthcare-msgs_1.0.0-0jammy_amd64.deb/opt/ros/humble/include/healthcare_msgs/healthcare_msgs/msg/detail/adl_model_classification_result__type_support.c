// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from healthcare_msgs:msg/ADLModelClassificationResult.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "healthcare_msgs/msg/detail/adl_model_classification_result__rosidl_typesupport_introspection_c.h"
#include "healthcare_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__functions.h"
#include "healthcare_msgs/msg/detail/adl_model_classification_result__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `device_serial_number`
// Member `glossary`
// Member `model_type`
// Member `model_version`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  healthcare_msgs__msg__ADLModelClassificationResult__init(message_memory);
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_fini_function(void * message_memory)
{
  healthcare_msgs__msg__ADLModelClassificationResult__fini(message_memory);
}

size_t healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__device_serial_number(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__device_serial_number(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__device_serial_number(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__device_serial_number(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__device_serial_number(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__device_serial_number(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__device_serial_number(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__device_serial_number(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__glossary(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__glossary(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__glossary(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__glossary(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__glossary(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__glossary(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__glossary(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__glossary(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__model_type(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__model_type(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__model_type(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__model_type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__model_type(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__model_type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__model_type(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__model_type(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

size_t healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__model_version(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__model_version(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__model_version(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__model_version(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__model_version(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__model_version(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__model_version(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__model_version(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_member_array[6] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ADLModelClassificationResult, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "device_serial_number",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ADLModelClassificationResult, device_serial_number),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__device_serial_number,  // size() function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__device_serial_number,  // get_const(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__device_serial_number,  // get(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__device_serial_number,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__device_serial_number,  // assign(index, value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__device_serial_number  // resize(index) function pointer
  },
  {
    "glossary",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ADLModelClassificationResult, glossary),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__glossary,  // size() function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__glossary,  // get_const(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__glossary,  // get(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__glossary,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__glossary,  // assign(index, value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__glossary  // resize(index) function pointer
  },
  {
    "class_amount",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ADLModelClassificationResult, class_amount),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "model_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ADLModelClassificationResult, model_type),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__model_type,  // size() function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__model_type,  // get_const(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__model_type,  // get(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__model_type,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__model_type,  // assign(index, value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__model_type  // resize(index) function pointer
  },
  {
    "model_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(healthcare_msgs__msg__ADLModelClassificationResult, model_version),  // bytes offset in struct
    NULL,  // default value
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__size_function__ADLModelClassificationResult__model_version,  // size() function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_const_function__ADLModelClassificationResult__model_version,  // get_const(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__get_function__ADLModelClassificationResult__model_version,  // get(index) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__fetch_function__ADLModelClassificationResult__model_version,  // fetch(index, &value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__assign_function__ADLModelClassificationResult__model_version,  // assign(index, value) function pointer
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__resize_function__ADLModelClassificationResult__model_version  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_members = {
  "healthcare_msgs__msg",  // message namespace
  "ADLModelClassificationResult",  // message name
  6,  // number of fields
  sizeof(healthcare_msgs__msg__ADLModelClassificationResult),
  healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_member_array,  // message members
  healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_init_function,  // function to initialize message memory (memory has to be allocated)
  healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_type_support_handle = {
  0,
  &healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_healthcare_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, healthcare_msgs, msg, ADLModelClassificationResult)() {
  healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_type_support_handle.typesupport_identifier) {
    healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &healthcare_msgs__msg__ADLModelClassificationResult__rosidl_typesupport_introspection_c__ADLModelClassificationResult_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
