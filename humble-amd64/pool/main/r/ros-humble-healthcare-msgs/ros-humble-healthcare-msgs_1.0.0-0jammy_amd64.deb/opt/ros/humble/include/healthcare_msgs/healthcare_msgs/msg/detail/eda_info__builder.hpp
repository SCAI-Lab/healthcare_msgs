// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/EDAInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/eda_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_EDAInfo_filters
{
public:
  explicit Init_EDAInfo_filters(::healthcare_msgs::msg::EDAInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::EDAInfo filters(::healthcare_msgs::msg::EDAInfo::_filters_type arg)
  {
    msg_.filters = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::EDAInfo msg_;
};

class Init_EDAInfo_current_form
{
public:
  explicit Init_EDAInfo_current_form(::healthcare_msgs::msg::EDAInfo & msg)
  : msg_(msg)
  {}
  Init_EDAInfo_filters current_form(::healthcare_msgs::msg::EDAInfo::_current_form_type arg)
  {
    msg_.current_form = std::move(arg);
    return Init_EDAInfo_filters(msg_);
  }

private:
  ::healthcare_msgs::msg::EDAInfo msg_;
};

class Init_EDAInfo_measuring_technique
{
public:
  explicit Init_EDAInfo_measuring_technique(::healthcare_msgs::msg::EDAInfo & msg)
  : msg_(msg)
  {}
  Init_EDAInfo_current_form measuring_technique(::healthcare_msgs::msg::EDAInfo::_measuring_technique_type arg)
  {
    msg_.measuring_technique = std::move(arg);
    return Init_EDAInfo_current_form(msg_);
  }

private:
  ::healthcare_msgs::msg::EDAInfo msg_;
};

class Init_EDAInfo_electrode_type
{
public:
  explicit Init_EDAInfo_electrode_type(::healthcare_msgs::msg::EDAInfo & msg)
  : msg_(msg)
  {}
  Init_EDAInfo_measuring_technique electrode_type(::healthcare_msgs::msg::EDAInfo::_electrode_type_type arg)
  {
    msg_.electrode_type = std::move(arg);
    return Init_EDAInfo_measuring_technique(msg_);
  }

private:
  ::healthcare_msgs::msg::EDAInfo msg_;
};

class Init_EDAInfo_electrode_placement
{
public:
  explicit Init_EDAInfo_electrode_placement(::healthcare_msgs::msg::EDAInfo & msg)
  : msg_(msg)
  {}
  Init_EDAInfo_electrode_type electrode_placement(::healthcare_msgs::msg::EDAInfo::_electrode_placement_type arg)
  {
    msg_.electrode_placement = std::move(arg);
    return Init_EDAInfo_electrode_type(msg_);
  }

private:
  ::healthcare_msgs::msg::EDAInfo msg_;
};

class Init_EDAInfo_device_info
{
public:
  Init_EDAInfo_device_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EDAInfo_electrode_placement device_info(::healthcare_msgs::msg::EDAInfo::_device_info_type arg)
  {
    msg_.device_info = std::move(arg);
    return Init_EDAInfo_electrode_placement(msg_);
  }

private:
  ::healthcare_msgs::msg::EDAInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::EDAInfo>()
{
  return healthcare_msgs::msg::builder::Init_EDAInfo_device_info();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__BUILDER_HPP_
