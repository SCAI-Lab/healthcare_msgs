// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from healthcare_msgs:msg/EDAInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__STRUCT_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'PLACEMENT_UNKNOWN'.
/**
  * Electrode Placement Enum
 */
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_UNKNOWN = 0
};

/// Constant 'PLACEMENT_PALM'.
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_PALM = 1
};

/// Constant 'PLACEMENT_FINGERTIP'.
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_FINGERTIP = 2
};

/// Constant 'PLACEMENT_WRIST'.
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_WRIST = 3
};

/// Constant 'PLACEMENT_FOREARM'.
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_FOREARM = 4
};

/// Constant 'PLACEMENT_SOLE'.
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_SOLE = 5
};

/// Constant 'PLACEMENT_SHOULDER'.
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_SHOULDER = 6
};

/// Constant 'PLACEMENT_CUSTOM'.
enum
{
  healthcare_msgs__msg__EDAInfo__PLACEMENT_CUSTOM = 255
};

/// Constant 'ELECTRODE_TYPE_UNKNOWN'.
/**
  * Electrode Type Enum
 */
enum
{
  healthcare_msgs__msg__EDAInfo__ELECTRODE_TYPE_UNKNOWN = 0
};

/// Constant 'ELECTRODE_TYPE_SURFACE'.
enum
{
  healthcare_msgs__msg__EDAInfo__ELECTRODE_TYPE_SURFACE = 1
};

/// Constant 'ELECTRODE_TYPE_INTRACUTANEOUS'.
enum
{
  healthcare_msgs__msg__EDAInfo__ELECTRODE_TYPE_INTRACUTANEOUS = 2
};

/// Constant 'ELECTRODE_TYPE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EDAInfo__ELECTRODE_TYPE_CUSTOM = 255
};

/// Constant 'TECHNIQUE_UNKNOWN'.
/**
  * Measuring Technique Enum
 */
enum
{
  healthcare_msgs__msg__EDAInfo__TECHNIQUE_UNKNOWN = 0
};

/// Constant 'TECHNIQUE_ENDOSOMATIC'.
enum
{
  healthcare_msgs__msg__EDAInfo__TECHNIQUE_ENDOSOMATIC = 1
};

/// Constant 'TECHNIQUE_EXOSOMATIC'.
enum
{
  healthcare_msgs__msg__EDAInfo__TECHNIQUE_EXOSOMATIC = 2
};

/// Constant 'TECHNIQUE_CUSTOM'.
enum
{
  healthcare_msgs__msg__EDAInfo__TECHNIQUE_CUSTOM = 255
};

/// Constant 'CURRENT_UNKNOWN'.
/**
  * Current Form Enum
 */
enum
{
  healthcare_msgs__msg__EDAInfo__CURRENT_UNKNOWN = 0
};

/// Constant 'CURRENT_DC'.
enum
{
  healthcare_msgs__msg__EDAInfo__CURRENT_DC = 1
};

/// Constant 'CURRENT_AC'.
enum
{
  healthcare_msgs__msg__EDAInfo__CURRENT_AC = 2
};

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.h"
// Member 'electrode_placement'
// Member 'electrode_type'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.h"

/// Struct defined in msg/EDAInfo in the package healthcare_msgs.
typedef struct healthcare_msgs__msg__EDAInfo
{
  healthcare_msgs__msg__DeviceInfo device_info;
  /// Support multiple placements
  rosidl_runtime_c__uint8__Sequence electrode_placement;
  rosidl_runtime_c__uint8__Sequence electrode_type;
  uint8_t measuring_technique;
  uint8_t current_form;
  healthcare_msgs__msg__FilterBase filters;
} healthcare_msgs__msg__EDAInfo;

// Struct for a sequence of healthcare_msgs__msg__EDAInfo.
typedef struct healthcare_msgs__msg__EDAInfo__Sequence
{
  healthcare_msgs__msg__EDAInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} healthcare_msgs__msg__EDAInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__STRUCT_H_
