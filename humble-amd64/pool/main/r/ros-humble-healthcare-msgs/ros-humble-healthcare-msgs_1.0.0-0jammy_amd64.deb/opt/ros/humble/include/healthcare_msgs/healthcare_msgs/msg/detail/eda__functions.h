// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from healthcare_msgs:msg/EDA.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA__FUNCTIONS_H_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "healthcare_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "healthcare_msgs/msg/detail/eda__struct.h"

/// Initialize msg/EDA message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * healthcare_msgs__msg__EDA
 * )) before or use
 * healthcare_msgs__msg__EDA__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EDA__init(healthcare_msgs__msg__EDA * msg);

/// Finalize msg/EDA message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EDA__fini(healthcare_msgs__msg__EDA * msg);

/// Create msg/EDA message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * healthcare_msgs__msg__EDA__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__EDA *
healthcare_msgs__msg__EDA__create();

/// Destroy msg/EDA message.
/**
 * It calls
 * healthcare_msgs__msg__EDA__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EDA__destroy(healthcare_msgs__msg__EDA * msg);

/// Check for msg/EDA message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EDA__are_equal(const healthcare_msgs__msg__EDA * lhs, const healthcare_msgs__msg__EDA * rhs);

/// Copy a msg/EDA message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EDA__copy(
  const healthcare_msgs__msg__EDA * input,
  healthcare_msgs__msg__EDA * output);

/// Initialize array of msg/EDA messages.
/**
 * It allocates the memory for the number of elements and calls
 * healthcare_msgs__msg__EDA__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EDA__Sequence__init(healthcare_msgs__msg__EDA__Sequence * array, size_t size);

/// Finalize array of msg/EDA messages.
/**
 * It calls
 * healthcare_msgs__msg__EDA__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EDA__Sequence__fini(healthcare_msgs__msg__EDA__Sequence * array);

/// Create array of msg/EDA messages.
/**
 * It allocates the memory for the array and calls
 * healthcare_msgs__msg__EDA__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
healthcare_msgs__msg__EDA__Sequence *
healthcare_msgs__msg__EDA__Sequence__create(size_t size);

/// Destroy array of msg/EDA messages.
/**
 * It calls
 * healthcare_msgs__msg__EDA__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
void
healthcare_msgs__msg__EDA__Sequence__destroy(healthcare_msgs__msg__EDA__Sequence * array);

/// Check for msg/EDA message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EDA__Sequence__are_equal(const healthcare_msgs__msg__EDA__Sequence * lhs, const healthcare_msgs__msg__EDA__Sequence * rhs);

/// Copy an array of msg/EDA messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_healthcare_msgs
bool
healthcare_msgs__msg__EDA__Sequence__copy(
  const healthcare_msgs__msg__EDA__Sequence * input,
  healthcare_msgs__msg__EDA__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA__FUNCTIONS_H_
