// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/HighPassFilter.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HIGH_PASS_FILTER__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__HIGH_PASS_FILTER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/high_pass_filter__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_HighPassFilter_zero_phase
{
public:
  explicit Init_HighPassFilter_zero_phase(::healthcare_msgs::msg::HighPassFilter & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::HighPassFilter zero_phase(::healthcare_msgs::msg::HighPassFilter::_zero_phase_type arg)
  {
    msg_.zero_phase = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::HighPassFilter msg_;
};

class Init_HighPassFilter_sampling_rate
{
public:
  explicit Init_HighPassFilter_sampling_rate(::healthcare_msgs::msg::HighPassFilter & msg)
  : msg_(msg)
  {}
  Init_HighPassFilter_zero_phase sampling_rate(::healthcare_msgs::msg::HighPassFilter::_sampling_rate_type arg)
  {
    msg_.sampling_rate = std::move(arg);
    return Init_HighPassFilter_zero_phase(msg_);
  }

private:
  ::healthcare_msgs::msg::HighPassFilter msg_;
};

class Init_HighPassFilter_order
{
public:
  explicit Init_HighPassFilter_order(::healthcare_msgs::msg::HighPassFilter & msg)
  : msg_(msg)
  {}
  Init_HighPassFilter_sampling_rate order(::healthcare_msgs::msg::HighPassFilter::_order_type arg)
  {
    msg_.order = std::move(arg);
    return Init_HighPassFilter_sampling_rate(msg_);
  }

private:
  ::healthcare_msgs::msg::HighPassFilter msg_;
};

class Init_HighPassFilter_cutoff_frequency
{
public:
  explicit Init_HighPassFilter_cutoff_frequency(::healthcare_msgs::msg::HighPassFilter & msg)
  : msg_(msg)
  {}
  Init_HighPassFilter_order cutoff_frequency(::healthcare_msgs::msg::HighPassFilter::_cutoff_frequency_type arg)
  {
    msg_.cutoff_frequency = std::move(arg);
    return Init_HighPassFilter_order(msg_);
  }

private:
  ::healthcare_msgs::msg::HighPassFilter msg_;
};

class Init_HighPassFilter_header
{
public:
  Init_HighPassFilter_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HighPassFilter_cutoff_frequency header(::healthcare_msgs::msg::HighPassFilter::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_HighPassFilter_cutoff_frequency(msg_);
  }

private:
  ::healthcare_msgs::msg::HighPassFilter msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::HighPassFilter>()
{
  return healthcare_msgs::msg::builder::Init_HighPassFilter_header();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HIGH_PASS_FILTER__BUILDER_HPP_
