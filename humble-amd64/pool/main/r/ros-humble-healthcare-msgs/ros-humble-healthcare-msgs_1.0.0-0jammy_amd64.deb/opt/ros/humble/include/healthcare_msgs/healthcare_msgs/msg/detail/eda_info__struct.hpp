// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from healthcare_msgs:msg/EDAInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__STRUCT_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__struct.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__healthcare_msgs__msg__EDAInfo __attribute__((deprecated))
#else
# define DEPRECATED__healthcare_msgs__msg__EDAInfo __declspec(deprecated)
#endif

namespace healthcare_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct EDAInfo_
{
  using Type = EDAInfo_<ContainerAllocator>;

  explicit EDAInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_init),
    filters(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->measuring_technique = 0;
      this->current_form = 0;
    }
  }

  explicit EDAInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : device_info(_alloc, _init),
    filters(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->measuring_technique = 0;
      this->current_form = 0;
    }
  }

  // field types and members
  using _device_info_type =
    healthcare_msgs::msg::DeviceInfo_<ContainerAllocator>;
  _device_info_type device_info;
  using _electrode_placement_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_placement_type electrode_placement;
  using _electrode_type_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _electrode_type_type electrode_type;
  using _measuring_technique_type =
    uint8_t;
  _measuring_technique_type measuring_technique;
  using _current_form_type =
    uint8_t;
  _current_form_type current_form;
  using _filters_type =
    healthcare_msgs::msg::FilterBase_<ContainerAllocator>;
  _filters_type filters;

  // setters for named parameter idiom
  Type & set__device_info(
    const healthcare_msgs::msg::DeviceInfo_<ContainerAllocator> & _arg)
  {
    this->device_info = _arg;
    return *this;
  }
  Type & set__electrode_placement(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_placement = _arg;
    return *this;
  }
  Type & set__electrode_type(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->electrode_type = _arg;
    return *this;
  }
  Type & set__measuring_technique(
    const uint8_t & _arg)
  {
    this->measuring_technique = _arg;
    return *this;
  }
  Type & set__current_form(
    const uint8_t & _arg)
  {
    this->current_form = _arg;
    return *this;
  }
  Type & set__filters(
    const healthcare_msgs::msg::FilterBase_<ContainerAllocator> & _arg)
  {
    this->filters = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t PLACEMENT_UNKNOWN =
    0u;
  static constexpr uint8_t PLACEMENT_PALM =
    1u;
  static constexpr uint8_t PLACEMENT_FINGERTIP =
    2u;
  static constexpr uint8_t PLACEMENT_WRIST =
    3u;
  static constexpr uint8_t PLACEMENT_FOREARM =
    4u;
  static constexpr uint8_t PLACEMENT_SOLE =
    5u;
  static constexpr uint8_t PLACEMENT_SHOULDER =
    6u;
  static constexpr uint8_t PLACEMENT_CUSTOM =
    255u;
  static constexpr uint8_t ELECTRODE_TYPE_UNKNOWN =
    0u;
  static constexpr uint8_t ELECTRODE_TYPE_SURFACE =
    1u;
  static constexpr uint8_t ELECTRODE_TYPE_INTRACUTANEOUS =
    2u;
  static constexpr uint8_t ELECTRODE_TYPE_CUSTOM =
    255u;
  static constexpr uint8_t TECHNIQUE_UNKNOWN =
    0u;
  static constexpr uint8_t TECHNIQUE_ENDOSOMATIC =
    1u;
  static constexpr uint8_t TECHNIQUE_EXOSOMATIC =
    2u;
  static constexpr uint8_t TECHNIQUE_CUSTOM =
    255u;
  static constexpr uint8_t CURRENT_UNKNOWN =
    0u;
  static constexpr uint8_t CURRENT_DC =
    1u;
  static constexpr uint8_t CURRENT_AC =
    2u;

  // pointer types
  using RawPtr =
    healthcare_msgs::msg::EDAInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const healthcare_msgs::msg::EDAInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EDAInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      healthcare_msgs::msg::EDAInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__healthcare_msgs__msg__EDAInfo
    std::shared_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__healthcare_msgs__msg__EDAInfo
    std::shared_ptr<healthcare_msgs::msg::EDAInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EDAInfo_ & other) const
  {
    if (this->device_info != other.device_info) {
      return false;
    }
    if (this->electrode_placement != other.electrode_placement) {
      return false;
    }
    if (this->electrode_type != other.electrode_type) {
      return false;
    }
    if (this->measuring_technique != other.measuring_technique) {
      return false;
    }
    if (this->current_form != other.current_form) {
      return false;
    }
    if (this->filters != other.filters) {
      return false;
    }
    return true;
  }
  bool operator!=(const EDAInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EDAInfo_

// alias to use template instance with default allocator
using EDAInfo =
  healthcare_msgs::msg::EDAInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_PALM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_FINGERTIP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_WRIST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_FOREARM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_SOLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_SHOULDER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::PLACEMENT_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::ELECTRODE_TYPE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::ELECTRODE_TYPE_SURFACE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::ELECTRODE_TYPE_INTRACUTANEOUS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::ELECTRODE_TYPE_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::TECHNIQUE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::TECHNIQUE_ENDOSOMATIC;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::TECHNIQUE_EXOSOMATIC;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::TECHNIQUE_CUSTOM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::CURRENT_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::CURRENT_DC;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t EDAInfo_<ContainerAllocator>::CURRENT_AC;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__EDA_INFO__STRUCT_HPP_
