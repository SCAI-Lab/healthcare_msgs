// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from healthcare_msgs:msg/BrainDecodingGeneralInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__BUILDER_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "healthcare_msgs/msg/detail/brain_decoding_general_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace healthcare_msgs
{

namespace msg
{

namespace builder
{

class Init_BrainDecodingGeneralInfo_selected_features
{
public:
  explicit Init_BrainDecodingGeneralInfo_selected_features(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo selected_features(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_selected_features_type arg)
  {
    msg_.selected_features = std::move(arg);
    return std::move(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_selected_preprocessing
{
public:
  explicit Init_BrainDecodingGeneralInfo_selected_preprocessing(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingGeneralInfo_selected_features selected_preprocessing(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_selected_preprocessing_type arg)
  {
    msg_.selected_preprocessing = std::move(arg);
    return Init_BrainDecodingGeneralInfo_selected_features(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_model_version
{
public:
  explicit Init_BrainDecodingGeneralInfo_model_version(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingGeneralInfo_selected_preprocessing model_version(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_model_version_type arg)
  {
    msg_.model_version = std::move(arg);
    return Init_BrainDecodingGeneralInfo_selected_preprocessing(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_classifier_model_name
{
public:
  explicit Init_BrainDecodingGeneralInfo_classifier_model_name(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingGeneralInfo_model_version classifier_model_name(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_classifier_model_name_type arg)
  {
    msg_.classifier_model_name = std::move(arg);
    return Init_BrainDecodingGeneralInfo_model_version(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_num_windows_per_output
{
public:
  explicit Init_BrainDecodingGeneralInfo_num_windows_per_output(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingGeneralInfo_classifier_model_name num_windows_per_output(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_num_windows_per_output_type arg)
  {
    msg_.num_windows_per_output = std::move(arg);
    return Init_BrainDecodingGeneralInfo_classifier_model_name(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_output_method
{
public:
  explicit Init_BrainDecodingGeneralInfo_output_method(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingGeneralInfo_num_windows_per_output output_method(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_output_method_type arg)
  {
    msg_.output_method = std::move(arg);
    return Init_BrainDecodingGeneralInfo_num_windows_per_output(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_window_overlap
{
public:
  explicit Init_BrainDecodingGeneralInfo_window_overlap(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingGeneralInfo_output_method window_overlap(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_window_overlap_type arg)
  {
    msg_.window_overlap = std::move(arg);
    return Init_BrainDecodingGeneralInfo_output_method(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_window_size
{
public:
  explicit Init_BrainDecodingGeneralInfo_window_size(::healthcare_msgs::msg::BrainDecodingGeneralInfo & msg)
  : msg_(msg)
  {}
  Init_BrainDecodingGeneralInfo_window_overlap window_size(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_window_size_type arg)
  {
    msg_.window_size = std::move(arg);
    return Init_BrainDecodingGeneralInfo_window_overlap(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

class Init_BrainDecodingGeneralInfo_windowing_function
{
public:
  Init_BrainDecodingGeneralInfo_windowing_function()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BrainDecodingGeneralInfo_window_size windowing_function(::healthcare_msgs::msg::BrainDecodingGeneralInfo::_windowing_function_type arg)
  {
    msg_.windowing_function = std::move(arg);
    return Init_BrainDecodingGeneralInfo_window_size(msg_);
  }

private:
  ::healthcare_msgs::msg::BrainDecodingGeneralInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::healthcare_msgs::msg::BrainDecodingGeneralInfo>()
{
  return healthcare_msgs::msg::builder::Init_BrainDecodingGeneralInfo_windowing_function();
}

}  // namespace healthcare_msgs

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__BRAIN_DECODING_GENERAL_INFO__BUILDER_HPP_
