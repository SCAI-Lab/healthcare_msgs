// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from healthcare_msgs:msg/HeartRateVariabilityInfo.idl
// generated code does not contain a copyright notice

#ifndef HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__TRAITS_HPP_
#define HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "healthcare_msgs/msg/detail/heart_rate_variability_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'device_info'
#include "healthcare_msgs/msg/detail/device_info__traits.hpp"
// Member 'filters'
#include "healthcare_msgs/msg/detail/filter_base__traits.hpp"

namespace healthcare_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const HeartRateVariabilityInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: device_info
  {
    out << "device_info: ";
    to_flow_style_yaml(msg.device_info, out);
    out << ", ";
  }

  // member: unit
  {
    out << "unit: ";
    rosidl_generator_traits::value_to_yaml(msg.unit, out);
    out << ", ";
  }

  // member: measurement_method
  {
    out << "measurement_method: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_method, out);
    out << ", ";
  }

  // member: sensor_placement
  {
    if (msg.sensor_placement.size() == 0) {
      out << "sensor_placement: []";
    } else {
      out << "sensor_placement: [";
      size_t pending_items = msg.sensor_placement.size();
      for (auto item : msg.sensor_placement) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: hrv_domain
  {
    out << "hrv_domain: ";
    rosidl_generator_traits::value_to_yaml(msg.hrv_domain, out);
    out << ", ";
  }

  // member: filters
  {
    out << "filters: ";
    to_flow_style_yaml(msg.filters, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HeartRateVariabilityInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: device_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_info:\n";
    to_block_style_yaml(msg.device_info, out, indentation + 2);
  }

  // member: unit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "unit: ";
    rosidl_generator_traits::value_to_yaml(msg.unit, out);
    out << "\n";
  }

  // member: measurement_method
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_method: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_method, out);
    out << "\n";
  }

  // member: sensor_placement
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.sensor_placement.size() == 0) {
      out << "sensor_placement: []\n";
    } else {
      out << "sensor_placement:\n";
      for (auto item : msg.sensor_placement) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: hrv_domain
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hrv_domain: ";
    rosidl_generator_traits::value_to_yaml(msg.hrv_domain, out);
    out << "\n";
  }

  // member: filters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filters:\n";
    to_block_style_yaml(msg.filters, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HeartRateVariabilityInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace healthcare_msgs

namespace rosidl_generator_traits
{

[[deprecated("use healthcare_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const healthcare_msgs::msg::HeartRateVariabilityInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  healthcare_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use healthcare_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const healthcare_msgs::msg::HeartRateVariabilityInfo & msg)
{
  return healthcare_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<healthcare_msgs::msg::HeartRateVariabilityInfo>()
{
  return "healthcare_msgs::msg::HeartRateVariabilityInfo";
}

template<>
inline const char * name<healthcare_msgs::msg::HeartRateVariabilityInfo>()
{
  return "healthcare_msgs/msg/HeartRateVariabilityInfo";
}

template<>
struct has_fixed_size<healthcare_msgs::msg::HeartRateVariabilityInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<healthcare_msgs::msg::HeartRateVariabilityInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<healthcare_msgs::msg::HeartRateVariabilityInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HEALTHCARE_MSGS__MSG__DETAIL__HEART_RATE_VARIABILITY_INFO__TRAITS_HPP_
